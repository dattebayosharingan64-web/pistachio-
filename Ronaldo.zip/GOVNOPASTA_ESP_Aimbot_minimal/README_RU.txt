GOVNOPASTA — ESP + AIMBOT MINIMAL SOURCE

Состав: ESP, Aimbot, меню, конфигурация, ImGui/Metal, IL2CPP/player SDK и необходимые hook/runtime файлы.
Удалены: Silent Aim, BunnyHop, No Recoil, Third Person и связанные исходники/пункты меню.

Сборка: откройте каталог проекта в Theos и выполните make package.

ВАЖНО: это подготовленный исходный архив, а не проверенный релиз. В этой среде не выполнялась компиляция Theos/iOS. Игровые RVA/offsets сохранены из исходного проекта и не подтверждены по текущему дампу. Перед сборкой проверьте их для своей версии игры.
