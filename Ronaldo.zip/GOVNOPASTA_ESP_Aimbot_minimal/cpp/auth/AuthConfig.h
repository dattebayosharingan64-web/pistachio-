#ifndef AUTHCONFIG_H
#define AUTHCONFIG_H

// ⚠️ ВАЖНО: Измени эти значения перед компиляцией!

// Vercel HTTPS → прокси на VPS (см. vercel-proxy/)
// Напрямую VPS (если IP открыт): @"http://138.124.18.118:3001/api/auth"
#define API_URL @"https://12312sd-mf.vercel.app/api/auth"

// Секретный ключ API (должен совпадать с API_SECRET в .env файле)
#define API_SECRET @"7480"

// Таймаут запроса в секундах
#define REQUEST_TIMEOUT 10.0

// Пинг сервера (онлайн-статус в боте), секунды
#define HEARTBEAT_INTERVAL 3.0

// Включить отладочные логи (0 = выкл, 1 = вкл)
#define DEBUG_AUTH 1

#endif
