#ifndef AUTHMANAGER_H
#define AUTHMANAGER_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

FOUNDATION_EXPORT NSString *const AuthSessionRevokedNotification;

@interface AuthManager : NSObject

+ (instancetype)sharedInstance;

// Проверка авторизации
- (BOOL)isAuthorized;

// Показать алерт авторизации
- (void)showAuthAlert:(UIViewController *)viewController completion:(void (^)(BOOL success))completion;

// Получить HWID устройства
- (NSString *)getDeviceHWID;

// Получить информацию об устройстве
- (NSDictionary *)getDeviceInfo;

// Сохранить ключ
- (void)saveKey:(NSString *)key;

// Получить сохраненный ключ
- (NSString *)getSavedKey;

// Очистить авторизацию
- (void)clearAuth;

// Фоновый пинг (онлайн в боте)
- (void)startHeartbeat;
- (void)stopHeartbeat;

// Последняя ошибка (бан / истёк)
- (NSString *)lastAuthErrorMessage;
- (BOOL)isAccountBanned;

// Показать причину отзыва доступа
- (void)showAccessRevokedAlert:(UIViewController *)viewController;
- (void)showBannedAlert:(UIViewController *)viewController completion:(void (^)(BOOL success))completion;

@end

#endif
