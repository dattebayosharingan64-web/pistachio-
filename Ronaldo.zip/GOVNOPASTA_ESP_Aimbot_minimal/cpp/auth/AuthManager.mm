#import "AuthManager.h"
#import "AuthConfig.h"
#import <Security/Security.h>
#import <sys/utsname.h>

static NSString *const kKeychainService = @"com.imguibase.auth";
static NSString *const kKeychainAccount = @"license_key";
static NSString *const kLegacyDefaultsKey = @"auth_key";
NSString *const AuthSessionRevokedNotification = @"AuthSessionRevoked";

@interface AuthManager()
@property (nonatomic, strong) NSString *currentKey;
@property (nonatomic, assign) BOOL authorized;
@property (nonatomic, strong) NSTimer *heartbeatTimer;
@property (nonatomic, copy) NSString *lastAuthErrorMessage;
@property (nonatomic, copy) NSString *lastAuthErrorCode;
@end

@implementation AuthManager

+ (instancetype)sharedInstance {
    static AuthManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[AuthManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _authorized = NO;
        [self migrateKeyFromUserDefaultsIfNeeded];
        _currentKey = [self getSavedKey];

        if (_currentKey) {
            [self verifyKeyWithServer:_currentKey silent:YES completion:^(BOOL success, NSString *message) {
                if (success) {
                    self.authorized = YES;
                    [self startHeartbeat];
                } else {
                    self.lastAuthErrorMessage = message;
                    self.authorized = NO;
                    [self stopHeartbeat];
                    self.currentKey = [self getSavedKey];
                }
            }];
        }
    }
    return self;
}

- (BOOL)isAuthorized {
    return self.authorized;
}

- (BOOL)isAccountBanned {
    return [self.lastAuthErrorCode isEqualToString:@"banned"];
}

- (void)applyAuthErrorFromJSON:(NSDictionary *)json {
    if (!json) return;
    if ([json[@"success"] boolValue]) {
        self.lastAuthErrorMessage = nil;
        self.lastAuthErrorCode = nil;
        return;
    }
    if (json[@"message"]) self.lastAuthErrorMessage = json[@"message"];
    if (json[@"code"]) self.lastAuthErrorCode = json[@"code"];
}

#pragma mark - UI

- (void)showBannedAlert:(UIViewController *)viewController completion:(void (^)(BOOL success))completion {
    NSString *msg = self.lastAuthErrorMessage ?: @"Твой аккаунт забанен";
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:@"Аккаунт забанен"
        message:[NSString stringWithFormat:@"%@\n\nОбратись к администратору в Telegram.", msg]
        preferredStyle:UIAlertControllerStyleAlert];

    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (completion) completion(NO);
    }]];

    [viewController presentViewController:alert animated:YES completion:nil];
}

- (void)showAuthAlert:(UIViewController *)viewController completion:(void (^)(BOOL success))completion {
    if ([self isAccountBanned]) {
        [self showBannedAlert:viewController completion:completion];
        return;
    }
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:@"Ключ"
        message:nil
        preferredStyle:UIAlertControllerStyleAlert];

    NSString *savedKey = self.currentKey ?: [self getSavedKey];

    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"XXXXXXXXXXXXXXXX";
        textField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        textField.autocorrectionType = UITextAutocorrectionTypeNo;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        if (savedKey.length > 0) {
            textField.text = savedKey;
        }
    }];

    [alert addAction:[UIAlertAction actionWithTitle:@"Отмена" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        if (completion) completion(NO);
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UITextField *keyField = alert.textFields.firstObject;
        NSString *key = [[keyField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];

        if (key.length == 0) {
            if (completion) completion(NO);
            return;
        }

        UIAlertController *loading = [UIAlertController alertControllerWithTitle:nil message:@"…" preferredStyle:UIAlertControllerStyleAlert];
        [viewController presentViewController:loading animated:YES completion:nil];

        [self verifyKeyWithServer:key silent:NO completion:^(BOOL success, NSString *message) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [loading dismissViewControllerAnimated:YES completion:^{
                    if (success) {
                        self.currentKey = key;
                        self.authorized = YES;
                        self.lastAuthErrorMessage = nil;
                        [self saveKey:key];
                        [self startHeartbeat];
                        if (completion) completion(YES);
                    } else {
                        if ([self isAccountBanned]) {
                            [self showBannedAlert:viewController completion:completion];
                        } else {
                            self.lastAuthErrorMessage = message;
                            UIAlertController *err = [UIAlertController alertControllerWithTitle:@"Нет доступа" message:message ?: @"Неверный ключ" preferredStyle:UIAlertControllerStyleAlert];
                            [err addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                if (completion) completion(NO);
                            }]];
                            [viewController presentViewController:err animated:YES completion:nil];
                        }
                    }
                }];
            });
        }];
    }]];

    [viewController presentViewController:alert animated:YES completion:nil];
}

- (void)showAccessRevokedAlert:(UIViewController *)viewController {
    if ([self isAccountBanned]) {
        [self showBannedAlert:viewController completion:^(BOOL success) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                exit(0);
            });
        }];
        return;
    }

    NSString *msg = self.lastAuthErrorMessage ?: @"Доступ закрыт";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Нет доступа" message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            exit(0);
        });
    }]];
    [viewController presentViewController:alert animated:YES completion:nil];
}

#pragma mark - API

- (void)verifyKeyWithServer:(NSString *)key completion:(void (^)(BOOL success))completion {
    [self verifyKeyWithServer:key silent:NO completion:^(BOOL success, NSString *message) {
        if (completion) completion(success);
    }];
}

- (void)verifyKeyWithServer:(NSString *)key silent:(BOOL)silent completion:(void (^)(BOOL success, NSString *message))completion {
    [self postJSONToPath:@"verify" body:@{
        @"keyCode": key,
        @"hwid": [self getDeviceHWID],
        @"deviceInfo": [self getDeviceInfo],
        @"silent": @(silent),
    } completion:^(BOOL success, NSDictionary *json) {
        [self applyAuthErrorFromJSON:json];
        if (completion) completion(success, json[@"message"]);
    }];
}

- (void)sendHeartbeat {
    if (!self.authorized || !self.currentKey) return;

    [self postJSONToPath:@"ping" body:@{
        @"keyCode": self.currentKey,
        @"hwid": [self getDeviceHWID],
    } completion:^(BOOL success, NSDictionary *json) {
        if (!success) {
            NSString *message = json[@"message"] ?: @"Доступ закрыт";
            NSString *code = json[@"code"];
            BOOL revokeKey = [code isEqualToString:@"banned"];

            dispatch_async(dispatch_get_main_queue(), ^{
                self.lastAuthErrorMessage = message;
                self.lastAuthErrorCode = code;
                self.authorized = NO;
                [self stopHeartbeat];
                if (revokeKey) {
                    [self clearAuth];
                } else {
                    self.currentKey = [self getSavedKey];
                }
                [[NSNotificationCenter defaultCenter] postNotificationName:AuthSessionRevokedNotification object:nil userInfo:@{ @"message": message, @"code": code ?: @"" }];
            });
        }
    }];
}

- (void)postJSONToPath:(NSString *)path body:(NSDictionary *)body completion:(void (^)(BOOL success, NSDictionary *json))completion {
    NSString *urlString = [NSString stringWithFormat:@"%@/%@", API_URL, path];
    NSURL *url = [NSURL URLWithString:urlString];

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:API_SECRET forHTTPHeaderField:@"X-API-Secret"];
    [request setTimeoutInterval:REQUEST_TIMEOUT];

    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:body options:0 error:&error];
    if (error || !jsonData) {
        if (completion) completion(NO, nil);
        return;
    }
    [request setHTTPBody:jsonData];

    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *netError) {
            NSDictionary *json = nil;
            if (data.length) {
                json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            }

            if (netError) {
                if (completion) completion(NO, json);
                return;
            }

            NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
            if (httpResponse.statusCode != 200) {
                if (completion) completion(NO, json);
                return;
            }

            BOOL success = [json[@"success"] boolValue];

            #if DEBUG_AUTH
            NSLog(@"[AUTH] %@ → %d %@", path, success, json[@"message"]);
            #endif

            if (completion) completion(success, json);
        }];

    [task resume];
}

#pragma mark - Heartbeat

- (void)startHeartbeat {
    [self stopHeartbeat];
    [self sendHeartbeat];

    self.heartbeatTimer = [NSTimer scheduledTimerWithTimeInterval:HEARTBEAT_INTERVAL
        repeats:YES
        block:^(NSTimer *timer) {
            [self sendHeartbeat];
        }];
    [[NSRunLoop mainRunLoop] addTimer:self.heartbeatTimer forMode:NSRunLoopCommonModes];
}

- (void)stopHeartbeat {
    [self.heartbeatTimer invalidate];
    self.heartbeatTimer = nil;
}

#pragma mark - Device

- (NSString *)getDeviceHWID {
    return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}

- (NSDictionary *)getDeviceInfo {
    UIDevice *device = [UIDevice currentDevice];
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceModel = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];

    return @{
        @"deviceName": device.name,
        @"deviceModel": deviceModel,
        @"iosVersion": device.systemVersion,
        @"systemName": device.systemName,
    };
}

#pragma mark - Keychain

- (void)migrateKeyFromUserDefaultsIfNeeded {
    NSString *legacy = [[NSUserDefaults standardUserDefaults] stringForKey:kLegacyDefaultsKey];
    if (!legacy.length) return;
    if ([self getSavedKey]) return;

    [self saveKey:legacy];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kLegacyDefaultsKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableDictionary *)keychainBaseQuery {
    return [@{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService,
        (__bridge id)kSecAttrAccount: kKeychainAccount,
    } mutableCopy];
}

- (void)saveKey:(NSString *)key {
    NSMutableDictionary *query = [self keychainBaseQuery];
    SecItemDelete((__bridge CFDictionaryRef)query);

    query[(__bridge id)kSecValueData] = [key dataUsingEncoding:NSUTF8StringEncoding];
    query[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;

    SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

- (NSString *)getSavedKey {
    NSMutableDictionary *query = [self keychainBaseQuery];
    query[(__bridge id)kSecReturnData] = @YES;
    query[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;

    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || !result) return nil;

    NSData *data = (__bridge_transfer NSData *)result;
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

- (void)clearAuth {
    self.authorized = NO;
    self.currentKey = nil;
    [self stopHeartbeat];

    NSMutableDictionary *query = [self keychainBaseQuery];
    SecItemDelete((__bridge CFDictionaryRef)query);

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kLegacyDefaultsKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
