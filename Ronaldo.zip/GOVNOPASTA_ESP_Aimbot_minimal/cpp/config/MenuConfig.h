#pragma once

#import <Foundation/Foundation.h>
#import "../interface/rendering/objective/ImGuiDrawView.h"

@interface ImGuiDrawView (MenuConfig)

+ (int)configSlotCount;
+ (void)saveSettingsToSlot:(int)slot;
+ (void)loadSettingsFromSlot:(int)slot;
+ (BOOL)hasSettingsInSlot:(int)slot;
+ (void)deleteSettingsInSlot:(int)slot;

+ (NSString*)displayNameForSlot:(int)slot;
+ (void)setDisplayNameForSlot:(int)slot name:(NSString*)name;

@end
