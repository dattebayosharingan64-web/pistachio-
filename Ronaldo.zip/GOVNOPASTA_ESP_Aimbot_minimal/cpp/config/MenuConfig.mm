#import "MenuConfig.h"
#include "../includes.hpp"

static NSString* SlotKey(int slot) {
    return [NSString stringWithFormat:@"config_slot_%d", slot];
}

static NSString* SlotNameKey(int slot) {
    return [NSString stringWithFormat:@"config_slot_label_%d", slot];
}

static void SetBool(NSMutableDictionary* d, NSString* key, bool v) {
    d[key] = @(v);
}

static void SetInt(NSMutableDictionary* d, NSString* key, int v) {
    d[key] = @(v);
}

static void SetFloat(NSMutableDictionary* d, NSString* key, float v) {
    d[key] = @(v);
}

static void SetVec4(NSMutableDictionary* d, NSString* prefix, const ImVec4& v) {
    d[[prefix stringByAppendingString:@"_r"]] = @(v.x);
    d[[prefix stringByAppendingString:@"_g"]] = @(v.y);
    d[[prefix stringByAppendingString:@"_b"]] = @(v.z);
    d[[prefix stringByAppendingString:@"_a"]] = @(v.w);
}

static bool LoadBool(NSDictionary* c, NSString* key, bool def) {
    if (c[key] == nil) return def;
    return [c[key] boolValue];
}

static int LoadInt(NSDictionary* c, NSString* key, int def) {
    if (c[key] == nil) return def;
    return [c[key] intValue];
}

static float LoadFloat(NSDictionary* c, NSString* key, float def) {
    if (c[key] == nil) return def;
    return [c[key] floatValue];
}

static void LoadVec4(NSDictionary* c, NSString* prefix, ImVec4& v) {
    NSString* r = [prefix stringByAppendingString:@"_r"];
    if (c[r] == nil) return;
    v.x = [c[r] floatValue];
    v.y = [c[[prefix stringByAppendingString:@"_g"]] floatValue];
    v.z = [c[[prefix stringByAppendingString:@"_b"]] floatValue];
    v.w = [c[[prefix stringByAppendingString:@"_a"]] floatValue];
}

@implementation ImGuiDrawView (MenuConfig)

+ (int)configSlotCount {
    return 5;
}

+ (BOOL)hasSettingsInSlot:(int)slot {
    if (slot < 0 || slot >= [self configSlotCount]) return NO;
    NSDictionary* cfg = [[NSUserDefaults standardUserDefaults] objectForKey:SlotKey(slot)];
    return cfg != nil && cfg.count > 0;
}

+ (void)deleteSettingsInSlot:(int)slot {
    if (slot < 0 || slot >= [self configSlotCount]) return;
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:SlotKey(slot)];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (NSString*)displayNameForSlot:(int)slot {
    if (slot < 0 || slot >= [self configSlotCount]) return @"Slot";
    NSString* name = [[NSUserDefaults standardUserDefaults] stringForKey:SlotNameKey(slot)];
    if (name.length == 0) {
        return [NSString stringWithFormat:@"Slot %d", slot + 1];
    }
    return name;
}

+ (void)setDisplayNameForSlot:(int)slot name:(NSString*)name {
    if (slot < 0 || slot >= [self configSlotCount]) return;

    NSString* trimmed = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmed.length == 0) {
        trimmed = [NSString stringWithFormat:@"Slot %d", slot + 1];
    }
    if (trimmed.length > 32) {
        trimmed = [trimmed substringToIndex:32];
    }

    [[NSUserDefaults standardUserDefaults] setObject:trimmed forKey:SlotNameKey(slot)];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)saveSettingsToSlot:(int)slot {
    if (slot < 0 || slot >= [self configSlotCount]) return;

    NSMutableDictionary* c = [NSMutableDictionary dictionary];

    SetBool(c, @"esp_enabled", ESP::settings.enabled);
    SetBool(c, @"esp_show_box", ESP::settings.showBox);
    SetBool(c, @"esp_show_line", ESP::settings.showLine);
    SetBool(c, @"esp_show_distance", ESP::settings.showDistance);
    SetBool(c, @"esp_show_health", ESP::settings.showHealth);
    SetBool(c, @"esp_show_armor", ESP::settings.showArmor);
    SetBool(c, @"esp_show_name", ESP::settings.showName);
    SetBool(c, @"esp_show_skeleton", ESP::settings.showSkeleton);
    SetBool(c, @"esp_show_outline", ESP::settings.showOutline);
    SetBool(c, @"esp_show_offscreen", ESP::settings.showOffscreen);
    SetBool(c, @"esp_team_check", ESP::settings.teamCheck);
    SetInt(c, @"esp_box_type", ESP::settings.boxType);
    SetFloat(c, @"esp_max_distance", ESP::settings.maxDistance);
    SetInt(c, @"esp_line_type", ESP::settings.lineType);
    SetInt(c, @"esp_line_width", ESP::settings.lineWidth);

    SetVec4(c, @"esp_box_visible", ESP::settings.boxVisibleColor);
    SetVec4(c, @"esp_box_invisible", ESP::settings.boxInvisibleColor);
    SetVec4(c, @"esp_skel_visible", ESP::settings.skelVisibleColor);
    SetVec4(c, @"esp_skel_invisible", ESP::settings.skelInvisibleColor);
    SetVec4(c, @"esp_health_min", ESP::settings.healthMinColor);
    SetVec4(c, @"esp_health_max", ESP::settings.healthMaxColor);
    SetVec4(c, @"esp_armor_min", ESP::settings.armorMinColor);
    SetVec4(c, @"esp_armor_max", ESP::settings.armorMaxColor);
    SetBool(c, @"aimbot_enable", hooks::Aimbot.Enable);
    SetBool(c, @"aimbot_visible_check", hooks::Aimbot.VisibleCheck);
    SetBool(c, @"aimbot_team_check", hooks::Aimbot.TeamCheck);
    SetBool(c, @"aimbot_fov_check", hooks::Aimbot.FOVCheck);
    SetInt(c, @"aimbot_fov", hooks::Aimbot.FOV);
    SetFloat(c, @"aimbot_smooth", hooks::Aimbot.Smooth);
    SetInt(c, @"aimbot_bone", hooks::Aimbot.TargetBone);
    SetFloat(c, @"aimbot_color_r", hooks::Aimbot.ColorR);
    SetFloat(c, @"aimbot_color_g", hooks::Aimbot.ColorG);
    SetFloat(c, @"aimbot_color_b", hooks::Aimbot.ColorB);
    SetFloat(c, @"aimbot_color_a", hooks::Aimbot.ColorA);

    [[NSUserDefaults standardUserDefaults] setObject:c forKey:SlotKey(slot)];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"[CONFIG] Saved slot %d", slot + 1);
}

+ (void)loadSettingsFromSlot:(int)slot {
    if (slot < 0 || slot >= [self configSlotCount]) return;

    NSDictionary* c = [[NSUserDefaults standardUserDefaults] objectForKey:SlotKey(slot)];
    if (!c) {
        NSLog(@"[CONFIG] Slot %d empty", slot + 1);
        return;
    }

    ESP::settings.enabled = LoadBool(c, @"esp_enabled", ESP::settings.enabled);
    ESP::settings.showBox = LoadBool(c, @"esp_show_box", ESP::settings.showBox);
    ESP::settings.showLine = LoadBool(c, @"esp_show_line", ESP::settings.showLine);
    ESP::settings.showDistance = LoadBool(c, @"esp_show_distance", ESP::settings.showDistance);
    ESP::settings.showHealth = LoadBool(c, @"esp_show_health", ESP::settings.showHealth);
    ESP::settings.showArmor = LoadBool(c, @"esp_show_armor", ESP::settings.showArmor);
    ESP::settings.showName = LoadBool(c, @"esp_show_name", ESP::settings.showName);
    ESP::settings.showSkeleton = LoadBool(c, @"esp_show_skeleton", ESP::settings.showSkeleton);
    ESP::settings.showOutline = LoadBool(c, @"esp_show_outline", ESP::settings.showOutline);
    ESP::settings.showOffscreen = LoadBool(c, @"esp_show_offscreen", ESP::settings.showOffscreen);
    ESP::settings.teamCheck = LoadBool(c, @"esp_team_check", ESP::settings.teamCheck);
    ESP::settings.boxType = LoadInt(c, @"esp_box_type", ESP::settings.boxType);
    ESP::settings.maxDistance = LoadFloat(c, @"esp_max_distance", ESP::settings.maxDistance);
    ESP::settings.lineType = LoadInt(c, @"esp_line_type", ESP::settings.lineType);
    ESP::settings.lineWidth = LoadInt(c, @"esp_line_width", ESP::settings.lineWidth);

    LoadVec4(c, @"esp_box_visible", ESP::settings.boxVisibleColor);
    LoadVec4(c, @"esp_box_invisible", ESP::settings.boxInvisibleColor);
    LoadVec4(c, @"esp_skel_visible", ESP::settings.skelVisibleColor);
    LoadVec4(c, @"esp_skel_invisible", ESP::settings.skelInvisibleColor);
    LoadVec4(c, @"esp_health_min", ESP::settings.healthMinColor);
    LoadVec4(c, @"esp_health_max", ESP::settings.healthMaxColor);
    LoadVec4(c, @"esp_armor_min", ESP::settings.armorMinColor);
    LoadVec4(c, @"esp_armor_max", ESP::settings.armorMaxColor);

    hooks::Aimbot.Enable = LoadBool(c, @"aimbot_enable", hooks::Aimbot.Enable);
    hooks::Aimbot.VisibleCheck = LoadBool(c, @"aimbot_visible_check", hooks::Aimbot.VisibleCheck);
    hooks::Aimbot.TeamCheck = LoadBool(c, @"aimbot_team_check", hooks::Aimbot.TeamCheck);
    hooks::Aimbot.FOVCheck = LoadBool(c, @"aimbot_fov_check", hooks::Aimbot.FOVCheck);
    hooks::Aimbot.FOV = LoadInt(c, @"aimbot_fov", hooks::Aimbot.FOV);
    hooks::Aimbot.Smooth = LoadFloat(c, @"aimbot_smooth", hooks::Aimbot.Smooth);
    hooks::Aimbot.TargetBone = LoadInt(c, @"aimbot_bone", hooks::Aimbot.TargetBone);
    hooks::Aimbot.ColorR = LoadFloat(c, @"aimbot_color_r", hooks::Aimbot.ColorR);
    hooks::Aimbot.ColorG = LoadFloat(c, @"aimbot_color_g", hooks::Aimbot.ColorG);
    hooks::Aimbot.ColorB = LoadFloat(c, @"aimbot_color_b", hooks::Aimbot.ColorB);
    hooks::Aimbot.ColorA = LoadFloat(c, @"aimbot_color_a", hooks::Aimbot.ColorA);


    NSLog(@"[CONFIG] Loaded slot %d", slot + 1);
}

@end
