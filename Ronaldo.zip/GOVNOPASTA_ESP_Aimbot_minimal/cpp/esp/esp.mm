#include "esp.h"
#include "../hooks/aimbot.hpp"
#import <Foundation/Foundation.h>
#import "../interface/rendering/imgui/imgui.h"
#import "../interface/rendering/imgui/imgui_internal.h"
#include <cmath>
#include <string>

namespace ESP {
    
    Settings settings;
    
    void Initialize() {
        try {
            NSLog(@"[ESP] ESP System initialized");
            os_log(OS_LOG_DEFAULT, "[ESP] ESP System initialized");
        } catch (...) {
            NSLog(@"[ESP] EXCEPTION in Initialize");
        }
    }
    
    // World to Screen - правильная реализация из 555
    ImVec2 WorldToScreen(Vector3 worldPos, bool& isValid) {
        isValid = false;
        
        // Check function pointers before calling them; hooks may not be initialized yet.
        if (!hooks::get_camera || !hooks::WorldToViewpoint) {
            return ImVec2(0.0f, 0.0f);
        }

        void* mainCamera = hooks::get_camera();
        if (!mainCamera) {
            return ImVec2(0.0f, 0.0f);
        }

        const Vector3 viewPoint = hooks::WorldToViewpoint(mainCamera, worldPos, 2);
        if (!std::isfinite(viewPoint.x) || !std::isfinite(viewPoint.y) ||
            !std::isfinite(viewPoint.z) || viewPoint.z <= 0.0f) {
            return ImVec2(0.0f, 0.0f);
        }

        const ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        if (!std::isfinite(displaySize.x) || !std::isfinite(displaySize.y) ||
            displaySize.x <= 0.0f || displaySize.y <= 0.0f) {
            return ImVec2(0.0f, 0.0f);
        }

        const float screenX = viewPoint.x * displaySize.x;
        const float screenY = displaySize.y - (viewPoint.y * displaySize.y);
        if (!std::isfinite(screenX) || !std::isfinite(screenY)) {
            return ImVec2(0.0f, 0.0f);
        }

        isValid = true;
        return ImVec2(screenX, screenY);
    }
    
    // Текст с outline - улучшенная версия из antisocial
    void AddOutlinedText(ImDrawList* drawlist, ImFont* font, float fontSize, const ImVec2& pos, ImVec4 color, const char* text) {
        ImU32 outlineCol = IM_COL32(0, 0, 0, (int)(200 * color.w));
        ImU32 textCol = ImGui::ColorConvertFloat4ToU32(color);
        
        // Outline
        drawlist->AddText(font, fontSize, ImVec2(pos.x + 1, pos.y + 1), outlineCol, text);
        drawlist->AddText(font, fontSize, ImVec2(pos.x - 1, pos.y - 1), outlineCol, text);
        drawlist->AddText(font, fontSize, ImVec2(pos.x + 1, pos.y - 1), outlineCol, text);
        drawlist->AddText(font, fontSize, ImVec2(pos.x - 1, pos.y + 1), outlineCol, text);
        
        // Main text
        drawlist->AddText(font, fontSize, pos, textCol, text);
    }
    
    // Текст с тенью - из antisocial
    void AddShadowText(ImDrawList* drawlist, ImFont* font, float fontSize, const ImVec2& pos, ImVec4 color, const char* text) {
        ImU32 shadowCol = IM_COL32(0, 0, 0, (int)(150 * color.w));
        ImU32 textCol = ImGui::ColorConvertFloat4ToU32(color);
        
        // Shadow
        drawlist->AddText(font, fontSize, ImVec2(pos.x + 2, pos.y + 2), shadowCol, text);
        
        // Main text
        drawlist->AddText(font, fontSize, pos, textCol, text);
    }
    
    // Старая функция для совместимости
    void AddText(bool shadow, bool outline, const ImVec2& pos, ImVec4 color, const char* value, ImDrawList* drawlist = ImGui::GetBackgroundDrawList()) {
        const static std::vector<ImVec2> text_offsets {
            {1, 1}, {-1, -1}, {0, 1}, {0, -1},
            {1, 1}, {-1, -1}, {-1, 1}, {1, -1},
            {1, 0}, {-1, 0}, {0, 1}, {0, -1}
        };
        
        ImU32 col = ImGui::ColorConvertFloat4ToU32(color);
        
        if(outline) {
            for(auto text_offset: text_offsets) {
                drawlist->AddText(ImVec2(pos.x + text_offset.x, pos.y + text_offset.y), 
                                 IM_COL32(0, 0, 0, (int)(color.w * 255)), value);
            }
        }
        if (shadow) {
            drawlist->AddText(ImVec2(pos.x + 2, pos.y + 2), 
                             IM_COL32(5, 5, 5, (int)(color.w * 255)), value);
        }
        drawlist->AddText(pos, col, value);
    }
    
    // Градиент для rect - из antisocial
    void AddGradientRect(ImDrawList* drawlist, const ImVec2& min, const ImVec2& max, ImVec4 colorStart, ImVec4 colorEnd) {
        int vertStartIdx = drawlist->VtxBuffer.Size;
        drawlist->AddRectFilled(min, max, IM_COL32(255, 255, 255, 255));
        int vertEndIdx = drawlist->VtxBuffer.Size;
        
        ImGui::ShadeVertsLinearColorGradientKeepAlpha(drawlist, vertStartIdx, vertEndIdx, 
                                                      min, max, 
                                                      ImGui::ColorConvertFloat4ToU32(colorStart),
                                                      ImGui::ColorConvertFloat4ToU32(colorEnd));
    }
    
    // Вспомогательная функция для offscreen - из antisocial
    ImVec2 CosTanHorizontal(float angle, float range, float x, float y, int length) {
        float ourAngle = angle + 45.0f;
        float yaw = ourAngle * (M_PI / 180.0f);
        
        float viewCosinus = cosf(yaw);
        float viewSinus = sinf(yaw);
        
        float x2 = range * (-viewCosinus) + range * viewSinus;
        float y2 = range * (-viewCosinus) - range * viewSinus;
        
        int screenX = (int)(x + (x2 / range * length));
        int screenY = (int)(y + (y2 / range * length));
        
        return ImVec2((float)screenX, (float)screenY);
    }
    
    // Offscreen indicator - 1 В 1 ИЗ ANTISOCIAL С EULER ANGLES
    void DrawOffscreenIndicator(void* player, ImVec4 color, float alpha = 1.0f) {
        if (!player || !hooks::localPlayer) return;
        
        // Проверяем что локальный игрок жив
        void* localPhoton = hooks::get_photon(hooks::localPlayer);
        if (!localPhoton) return;
        
        int localHealth = hooks::GetPlayerHealth(localPhoton);
        if (localHealth <= 0) return;
        
        Vector3 playerPos = hooks::GetPlayerLocation(player);
        Vector3 localPos = hooks::GetPlayerLocation(hooks::localPlayer);
        
        ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        
        // World to screen для позиции игрока (с поднятием на 1.0f как в antisocial)
        bool isValid = false;
        ImVec2 w2sCenter = WorldToScreen(Vector3(playerPos.x, playerPos.y + 1.0f, playerPos.z), isValid);
        
        // КЛЮЧЕВАЯ ПРОВЕРКА: рисуем ТОЛЬКО если игрок ЗА экраном или не валиден
        if ((w2sCenter.x >= 0 && w2sCenter.x <= displaySize.x) && 
            (w2sCenter.y >= 0 && w2sCenter.y <= displaySize.y) && isValid) {
            return; // Игрок НА экране - не рисуем
        }
        
        ImVec2 center = ImVec2(displaySize.x / 2.0f, displaySize.y / 2.0f);
        
        // Получаем euler angles камеры через AimingData локального игрока
        Vector3 eulerAngles = Vector3(0, 0, 0);
        
        // Получаем AimController из локального игрока (offset 0x90)
        void* aimController = *(void**)((uintptr_t)hooks::localPlayer + 0x90);
        if (aimController) {
            // Получаем AimingData из AimController (offset 0x90)
            void* aimingData = *(void**)((uintptr_t)aimController + 0x90);
            if (aimingData) {
                // Получаем curEulerAngles из AimingData (offset 0x24)
                eulerAngles = *(Vector3*)((uintptr_t)aimingData + 0x24);
            }
        }
        
        // Вычисляем направление (как в antisocial)
        float dx = localPos.x - playerPos.x;
        float dz = localPos.z - playerPos.z;
        float length = sqrtf(dx * dx + dz * dz);
        
        if (length < 0.01f) return;
        
        // Нормализуем вектор направления
        ImVec2 direction = ImVec2(dx / length, dz / length);
        
        // Вычисляем угол (1 В 1 ИЗ ANTISOCIAL с euler_angles.y)
        float angle = atan2f(direction.x, direction.y) * 57.29578f - 180.0f - eulerAngles.y;
        
        int distanceDivided = 0; // Как в antisocial
        
        // Вычисляем позиции треугольника (1 в 1 из antisocial)
        ImVec2 pos0 = CosTanHorizontal(angle, 10.0f, center.x, center.y, 60 + distanceDivided);
        ImVec2 pos1 = CosTanHorizontal(angle + 5.0f - distanceDivided / 2.0f, 10.0f, center.x, center.y, 50 + distanceDivided);
        ImVec2 pos2 = CosTanHorizontal(angle - 5.0f - distanceDivided / 2.0f, 10.0f, center.x, center.y, 50 + distanceDivided);
        ImVec2 pos3 = CosTanHorizontal(angle, 10.0f, center.x, center.y, 52 + distanceDivided);
        ImVec2 posCenter = CosTanHorizontal(angle, 10.0f, center.x, center.y, 55 + distanceDivided);
        
        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        
        // Применяем alpha из параметра
        ImVec4 colorWithAlpha = color;
        colorWithAlpha.w *= alpha;
        ImU32 col = ImGui::ColorConvertFloat4ToU32(colorWithAlpha);
        
        // Рисуем точку в центре (как в antisocial - AddShadowCircle)
        draw->AddCircleFilled(posCenter, 2.0f, IM_COL32(0, 0, 0, (int)(100 * alpha)));
        draw->AddCircleFilled(posCenter, 1.0f, ImColor(255, 255, 255, (int)(255 * alpha)));
        
        // Рисуем треугольник (как в antisocial - AddTriangleCutout)
        // Сначала тень
        draw->AddTriangleFilled(
            ImVec2(pos0.x + 1, pos0.y + 1),
            ImVec2(pos1.x + 1, pos1.y + 1),
            ImVec2(pos2.x + 1, pos2.y + 1),
            IM_COL32(0, 0, 0, (int)(150 * alpha))
        );
        
        // Основной треугольник
        draw->AddTriangleFilled(pos0, pos1, pos2, ImColor(255, 255, 255, (int)(255 * alpha)));
        
        // Обводка
        draw->AddTriangle(pos0, pos1, pos2, IM_COL32(0, 0, 0, (int)(200 * alpha)), 1.5f);
    }
    
    // Corner Box - из antisocial
    void DrawCornerBox(ImDrawList* draw, const ImVec2& min, const ImVec2& max, ImVec4 color, float cornerLength = 10.0f) {
        ImU32 col = ImGui::ColorConvertFloat4ToU32(color);
        
        float width = max.x - min.x;
        float height = max.y - min.y;
        float length = std::min(cornerLength, std::min(width, height) * 0.3f);
        
        // Черные обводки для контраста
        ImU32 outlineCol = IM_COL32(0, 0, 0, 200);
        
        // Top-left corner
        draw->AddLine(ImVec2(min.x - 1, min.y - 1), ImVec2(min.x + length - 1, min.y - 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(min.x - 1, min.y - 1), ImVec2(min.x - 1, min.y + length - 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(min.x, min.y), ImVec2(min.x + length, min.y), col, 2.0f);
        draw->AddLine(ImVec2(min.x, min.y), ImVec2(min.x, min.y + length), col, 2.0f);
        
        // Top-right corner
        draw->AddLine(ImVec2(max.x - length + 1, min.y - 1), ImVec2(max.x + 1, min.y - 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(max.x + 1, min.y - 1), ImVec2(max.x + 1, min.y + length - 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(max.x - length, min.y), ImVec2(max.x, min.y), col, 2.0f);
        draw->AddLine(ImVec2(max.x, min.y), ImVec2(max.x, min.y + length), col, 2.0f);
        
        // Bottom-left corner
        draw->AddLine(ImVec2(min.x - 1, max.y - length + 1), ImVec2(min.x - 1, max.y + 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(min.x - 1, max.y + 1), ImVec2(min.x + length - 1, max.y + 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(min.x, max.y - length), ImVec2(min.x, max.y), col, 2.0f);
        draw->AddLine(ImVec2(min.x, max.y), ImVec2(min.x + length, max.y), col, 2.0f);
        
        // Bottom-right corner
        draw->AddLine(ImVec2(max.x + 1, max.y - length + 1), ImVec2(max.x + 1, max.y + 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(max.x - length + 1, max.y + 1), ImVec2(max.x + 1, max.y + 1), outlineCol, 3.0f);
        draw->AddLine(ImVec2(max.x, max.y - length), ImVec2(max.x, max.y), col, 2.0f);
        draw->AddLine(ImVec2(max.x - length, max.y), ImVec2(max.x, max.y), col, 2.0f);
    }
    
    // Snaplines - из antisocial
    void DrawSnapline(const ImVec2& from, const ImVec2& to, ImVec4 color, float thickness = 1.0f) {
        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        ImU32 col = ImGui::ColorConvertFloat4ToU32(color);
        
        // Тень для линии
        draw->AddLine(ImVec2(from.x + 1, from.y + 1), ImVec2(to.x + 1, to.y + 1), 
                     IM_COL32(0, 0, 0, (int)(150 * color.w)), thickness);
        
        // Основная линия
        draw->AddLine(from, to, col, thickness);
    }
    
    // Скелет - точная копия из lst с правильными смещениями
    void DrawSkeleton(void* player, ImVec4 color) {
        if (!player || !hooks::GetBipedMap(player)) return;
        
        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        
        // Получаем все кости - как в lst
        auto getBone = [](void* player, uint64_t offset) -> void* {
            void* bipedMap = hooks::GetBipedMap(player);
            if (!bipedMap) return nullptr;
            return *(void**)((uint64_t)bipedMap + offset);
        };
        
        // Все кости с ОБНОВЛЕННЫМИ смещениями из dump.cs (dump leo)
        // ИЗМЕНЕНИЯ: добавлен Spine (0x28), все смещения сдвинуты на +0x8
        void* headBone = getBone(player, ENCRYPTOFFSET(0x18));        // Head - не изменилось
        void* neckBone = getBone(player, ENCRYPTOFFSET(0x20));        // Neck - не изменилось
        void* spine2Bone = getBone(player, ENCRYPTOFFSET(0x38));      // Spine2 - было 0x30
        void* spine1Bone = getBone(player, ENCRYPTOFFSET(0x30));      // Spine1 - было 0x28
        void* hipBone = getBone(player, ENCRYPTOFFSET(0x80));         // Hip - было 0x78
        
        void* leftShoulderBone = getBone(player, ENCRYPTOFFSET(0x40));    // LeftShoulder - было 0x38
        void* rightShoulderBone = getBone(player, ENCRYPTOFFSET(0x60));   // RightShoulder - было 0x58
        void* leftUpperArmBone = getBone(player, ENCRYPTOFFSET(0x48));    // LeftUpperarm - было 0x40
        void* rightUpperArmBone = getBone(player, ENCRYPTOFFSET(0x68));   // RightUpperarm - было 0x60
        void* leftForearmBone = getBone(player, ENCRYPTOFFSET(0x50));     // LeftForearm - было 0x48
        void* rightForearmBone = getBone(player, ENCRYPTOFFSET(0x70));    // RightForearm - было 0x68
        void* leftHandBone = getBone(player, ENCRYPTOFFSET(0x58));        // LeftHand - было 0x50
        void* rightHandBone = getBone(player, ENCRYPTOFFSET(0x78));       // RightHand - было 0x70
        
        void* leftThighBone = getBone(player, ENCRYPTOFFSET(0x88));       // LeftUpLeg - было 0x80
        void* rightThighBone = getBone(player, ENCRYPTOFFSET(0xA8));      // RightUpLeg - было 0x98
        void* leftCalfBone = getBone(player, ENCRYPTOFFSET(0x90));        // LeftLeg - было 0x88
        void* rightCalfBone = getBone(player, ENCRYPTOFFSET(0xB0));       // RightLeg - было 0xA0
        void* leftFootBone = getBone(player, ENCRYPTOFFSET(0x98));        // LeftFoot - было 0x90
        void* rightFootBone = getBone(player, ENCRYPTOFFSET(0xB8));       // RightFoot - было 0xA8
        
        if (!headBone || !neckBone || !hipBone) return;
        
        // Конвертируем в screen координаты
        bool valid = true;
        bool checker;
        
        ImVec2 head = hooks::world2screen_c(hooks::get_position(headBone), checker); if (!checker) valid = false;
        ImVec2 headUp = head; // Для круга
        ImVec2 neck = hooks::world2screen_c(hooks::get_position(neckBone), checker); if (!checker) valid = false;
        ImVec2 spine2 = hooks::world2screen_c(hooks::get_position(spine2Bone), checker); if (!checker) valid = false;
        ImVec2 spine1 = hooks::world2screen_c(hooks::get_position(spine1Bone), checker); if (!checker) valid = false;
        ImVec2 hip = hooks::world2screen_c(hooks::get_position(hipBone), checker); if (!checker) valid = false;
        
        ImVec2 leftShoulder = hooks::world2screen_c(hooks::get_position(leftShoulderBone), checker); if (!checker) valid = false;
        ImVec2 rightShoulder = hooks::world2screen_c(hooks::get_position(rightShoulderBone), checker); if (!checker) valid = false;
        ImVec2 leftUpper = hooks::world2screen_c(hooks::get_position(leftUpperArmBone), checker); if (!checker) valid = false;
        ImVec2 rightUpper = hooks::world2screen_c(hooks::get_position(rightUpperArmBone), checker); if (!checker) valid = false;
        ImVec2 leftFore = hooks::world2screen_c(hooks::get_position(leftForearmBone), checker); if (!checker) valid = false;
        ImVec2 rightFore = hooks::world2screen_c(hooks::get_position(rightForearmBone), checker); if (!checker) valid = false;
        ImVec2 leftHand = hooks::world2screen_c(hooks::get_position(leftHandBone), checker); if (!checker) valid = false;
        ImVec2 rightHand = hooks::world2screen_c(hooks::get_position(rightHandBone), checker); if (!checker) valid = false;
        
        ImVec2 leftThigh = hooks::world2screen_c(hooks::get_position(leftThighBone), checker); if (!checker) valid = false;
        ImVec2 rightThigh = hooks::world2screen_c(hooks::get_position(rightThighBone), checker); if (!checker) valid = false;
        ImVec2 leftCalf = hooks::world2screen_c(hooks::get_position(leftCalfBone), checker); if (!checker) valid = false;
        ImVec2 rightCalf = hooks::world2screen_c(hooks::get_position(rightCalfBone), checker); if (!checker) valid = false;
        ImVec2 leftFoot = hooks::world2screen_c(hooks::get_position(leftFootBone), checker); if (!checker) valid = false;
        ImVec2 rightFoot = hooks::world2screen_c(hooks::get_position(rightFootBone), checker); if (!checker) valid = false;
        
        if (!valid) return;
        
        ImU32 col = ImGui::ColorConvertFloat4ToU32(color);
        
        // Голова (круг) - как в lst
        float headRadius = fabsf(head.y - headUp.y) * 0.4f;
        if (headRadius > 0) {
            draw->AddCircle(ImVec2(head.x, head.y - headRadius), headRadius, col, 100, 1);
        }
        
        // Позвоночник
        draw->AddLine(neck, head, col, 1);
        draw->AddLine(spine2, neck, col, 1);
        draw->AddLine(spine1, spine2, col, 1);
        draw->AddLine(hip, spine1, col, 1);
        
        // Плечи
        draw->AddLine(leftShoulder, neck, col, 1);
        draw->AddLine(rightShoulder, neck, col, 1);
        
        // Левая рука
        draw->AddLine(leftUpper, leftShoulder, col, 1);
        draw->AddLine(leftFore, leftUpper, col, 1);
        draw->AddLine(leftHand, leftFore, col, 1);
        
        // Правая рука
        draw->AddLine(rightUpper, rightShoulder, col, 1);
        draw->AddLine(rightFore, rightUpper, col, 1);
        draw->AddLine(rightHand, rightFore, col, 1);
        
        // Левая нога
        draw->AddLine(leftThigh, hip, col, 1);
        draw->AddLine(leftCalf, leftThigh, col, 1);
        draw->AddLine(leftFoot, leftCalf, col, 1);
        
        // Правая нога
        draw->AddLine(rightThigh, hip, col, 1);
        draw->AddLine(rightCalf, rightThigh, col, 1);
        draw->AddLine(rightFoot, rightCalf, col, 1);
    }
    

    
    // Индикатор цели Aimbot
    void DrawAimbotTarget() {
        // Проверяем что Aimbot включен и есть валидная цель
        if (!hooks::Aimbot.Enable || !hooks::Aimbot.TargetPlayer || !hooks::Aimbot.CanAim) return;
        
        // Проверяем что цель жива
        void* photon = hooks::get_photon(hooks::Aimbot.TargetPlayer);
        if (!photon) return;
        
        int health = hooks::GetPlayerHealth(photon);
        if (health <= 0) return;
        
        // Проверяем видимость цели - если visible check включен
        if (hooks::Aimbot.VisibleCheck) {
            bool isVisible = hooks::IsPlayerVisible(hooks::Aimbot.TargetPlayer);
            if (!isVisible) return;
        }
        
        // Получаем целевую позицию
        Vector3 targetPos = hooks::Aimbot.TargetPosition;
        
        // Конвертируем в screen координаты
        bool isValid = false;
        ImVec2 screenPos = WorldToScreen(targetPos, isValid);
        
        if (!isValid) return;
        
        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        
        // Цвет индикатора - используем цвет FOV круга
        ImVec4 color = ImVec4(hooks::Aimbot.ColorR, hooks::Aimbot.ColorG, 
                             hooks::Aimbot.ColorB, hooks::Aimbot.ColorA);
        ImU32 col = ImGui::ColorConvertFloat4ToU32(color);
        
        // Рисуем круг на целевой кости
        float radius = 6.0f;
        draw->AddCircleFilled(screenPos, radius + 2, IM_COL32(0, 0, 0, 150)); // Тень
        draw->AddCircleFilled(screenPos, radius, col);
        draw->AddCircle(screenPos, radius, IM_COL32(255, 255, 255, 200), 32, 2.0f);
        
        // Рисуем крестик в центре
        float crossSize = 4.0f;
        
        // Горизонтальная линия
        draw->AddLine(ImVec2(screenPos.x - crossSize, screenPos.y), 
                     ImVec2(screenPos.x + crossSize, screenPos.y), 
                     IM_COL32(0, 0, 0, 200), 3.0f); // Тень
        draw->AddLine(ImVec2(screenPos.x - crossSize, screenPos.y), 
                     ImVec2(screenPos.x + crossSize, screenPos.y), 
                     IM_COL32(255, 255, 255, 255), 2.0f);
        
        // Вертикальная линия
        draw->AddLine(ImVec2(screenPos.x, screenPos.y - crossSize), 
                     ImVec2(screenPos.x, screenPos.y + crossSize), 
                     IM_COL32(0, 0, 0, 200), 3.0f); // Тень
        draw->AddLine(ImVec2(screenPos.x, screenPos.y - crossSize), 
                     ImVec2(screenPos.x, screenPos.y + crossSize), 
                     IM_COL32(255, 255, 255, 255), 2.0f);
    }
    
    // Основная функция рисования ESP - полностью из lst
    void DrawESP() {
        try {
            if (!settings.enabled) {
                return;
            }
            
            if (!hooks::get_camera || !hooks::localPlayer) {
                return;
            }
            
            ImVec2 displaySize = ImGui::GetIO().DisplaySize;
            ImDrawList* draw = ImGui::GetBackgroundDrawList();
            
            // Рисуем FOV круг для Aimbot
            if (hooks::Aimbot.Enable && hooks::Aimbot.FOVCheck) {
                ImVec4 aimbotColor = ImVec4(hooks::Aimbot.ColorR, hooks::Aimbot.ColorG, 
                                           hooks::Aimbot.ColorB, hooks::Aimbot.ColorA);
                draw->AddCircle(
                    ImVec2(displaySize.x / 2.0f, displaySize.y / 2.0f),
                    (float)hooks::Aimbot.FOV * (displaySize.x / 593.0f),
                    ImGui::GetColorU32(aimbotColor),
                    hooks::Aimbot.FOV * 8,
                    2.0f
                );
            }
            

            
            hooks::clearPlayers();
            
            Vector3 localPos = hooks::GetPlayerLocation(hooks::localPlayer);
            
            for (void* player : hooks::players) {
                if (!player) continue;
                
                void* photon = hooks::get_photon(player);
                if (!photon) continue;
                
                // Проверка команды
                int playerTeam = hooks::GetPlayerTeam(photon);
                if (settings.teamCheck && playerTeam == hooks::localTeam) {
                    continue;
                }
                
                // Получаем данные игрока
                Vector3 playerPos = hooks::GetPlayerLocation(player);
                int health = hooks::GetPlayerHealth(photon);
                int armor = hooks::GetPlayerArmor(photon);
                bool isVisible = hooks::IsPlayerVisible(player);
                
                // Дистанция
                float dx = playerPos.x - localPos.x;
                float dy = playerPos.y - localPos.y;
                float dz = playerPos.z - localPos.z;
                float distance = sqrtf(dx * dx + dy * dy + dz * dz);
                
                if (distance > settings.maxDistance) {
                    continue;
                }
                
                // World to Screen для верха и низа - как в lst
                bool topValid, bottomValid;
                ImVec2 top = hooks::world2screen_i(Vector3(playerPos.x, playerPos.y + 1.9f, playerPos.z));
                ImVec2 bottom = hooks::world2screen_i(Vector3(playerPos.x, playerPos.y - 0.15f, playerPos.z));
                
                // Цвета (определяем заранее для offscreen indicator)
                ImVec4 boxColor = isVisible ? settings.boxVisibleColor : settings.boxInvisibleColor;
                
                // Проверка валидности через world2screen_c
                bool checker;
                hooks::world2screen_c(playerPos, checker);
                
                // Если игрок за экраном - рисуем offscreen indicator
                if (!checker) {
                    if (settings.showOffscreen) {
                        DrawOffscreenIndicator(player, boxColor);
                    }
                    continue;
                }
                
                // Вычисляем rect как в lst
                float topFixed = top.x;
                float bottomFixed = bottom.x;
                if (top.x > bottom.x) {
                    topFixed = bottom.x;
                    bottomFixed = top.x;
                }
                
                float positionCalc = fabsf((top.y - bottom.y) * (0.0092f / 0.019f) / 2);
                ImVec2 rectMin = ImVec2(topFixed - positionCalc, top.y);
                ImVec2 rectMax = ImVec2(bottomFixed + positionCalc, bottom.y);
                
                // Остальные цвета
                ImVec4 skelColor = isVisible ? settings.skelVisibleColor : settings.skelInvisibleColor;
                ImVec4 hpColor = colorLerp(settings.healthMinColor, settings.healthMaxColor, (float)health / 100.0f);
                ImVec4 armorColor = colorLerp(settings.armorMinColor, settings.armorMaxColor, (float)armor / 100.0f);
                
                ImDrawList* draw = ImGui::GetBackgroundDrawList();
                
                // Рисуем бокс - улучшенная версия из antisocial с градиентами
                if (settings.showBox) {
                    if (settings.boxType == 0) {
                        // Full box с градиентом
                        ImU32 col = ImGui::ColorConvertFloat4ToU32(boxColor);
                        
                        // Черные обводки для контраста
                        draw->AddRect(ImVec2(rectMin.x + 1, rectMin.y + 1), 
                                     ImVec2(rectMax.x - 1, rectMax.y - 1), 
                                     IM_COL32(0, 0, 0, 200), 0.0f, 0, 1.0f);
                        draw->AddRect(ImVec2(rectMin.x - 1, rectMin.y - 1), 
                                     ImVec2(rectMax.x + 1, rectMax.y + 1), 
                                     IM_COL32(0, 0, 0, 200), 0.0f, 0, 1.0f);
                        
                        // Основной бокс с градиентом
                        int vertStartIdx = draw->VtxBuffer.Size;
                        draw->AddRect(rectMin, rectMax, col, 0.0f, 0, 2.0f);
                        int vertEndIdx = draw->VtxBuffer.Size;
                        
                        // Применяем градиент от верха к низу
                        ImVec4 boxColorEnd = boxColor;
                        boxColorEnd.w *= 0.6f; // Делаем низ более прозрачным
                        ImGui::ShadeVertsLinearColorGradientKeepAlpha(draw, vertStartIdx, vertEndIdx,
                                                                      rectMin, rectMax,
                                                                      ImGui::ColorConvertFloat4ToU32(boxColor),
                                                                      ImGui::ColorConvertFloat4ToU32(boxColorEnd));
                    } else {
                        // Corner box
                        DrawCornerBox(draw, rectMin, rectMax, boxColor);
                    }
                }
                
                // Health bar - улучшенная версия из antisocial с градиентами и отступом
                if (settings.showHealth) {
                    float health_pos = rectMin.x - 7; // Увеличен отступ от бокса
                    float health_length = lerp(rectMax.y, rectMin.y - 1.5f, (float)health / 100.0f);
                    
                    // Background с закругленными углами
                    draw->AddRectFilled(ImVec2(health_pos - 1, rectMin.y - 1.5f),
                                       ImVec2(health_pos + 1, rectMax.y + 1.5f),
                                       IM_COL32(0, 0, 0, 165), 1.0f);
                    
                    // Health bar с градиентом
                    int vertStartIdx = draw->VtxBuffer.Size;
                    draw->AddRectFilled(ImVec2(health_pos, rectMax.y), 
                                       ImVec2(health_pos + 2, health_length), 
                                       ImGui::ColorConvertFloat4ToU32(hpColor), 1.0f);
                    int vertEndIdx = draw->VtxBuffer.Size;
                    
                    // Применяем вертикальный градиент
                    ImVec4 hpColorDark = hpColor;
                    hpColorDark.x *= 0.7f;
                    hpColorDark.y *= 0.7f;
                    hpColorDark.z *= 0.7f;
                    ImGui::ShadeVertsLinearColorGradientKeepAlpha(draw, vertStartIdx, vertEndIdx,
                                                                  ImVec2(health_pos, health_length),
                                                                  ImVec2(health_pos, rectMax.y),
                                                                  ImGui::ColorConvertFloat4ToU32(hpColor),
                                                                  ImGui::ColorConvertFloat4ToU32(hpColorDark));
                    
                    // Outline
                    draw->AddRect(ImVec2(health_pos - 2, rectMin.y - 2.5f), 
                                 ImVec2(health_pos + 3, rectMax.y + 1.5f), 
                                 IM_COL32(0, 0, 0, 200), 1.0f, 0, 1.0f);
                    
                    // Health text
                    if (health < 90 || health > 100) {
                        std::string healthText = std::to_string(health);
                        ImVec2 textSize = ImGui::CalcTextSize(healthText.c_str());
                        float textX = health_pos - textSize.x / 2 - 1;
                        float textY = health_length - textSize.y / 2;
                        AddOutlinedText(draw, ImGui::GetFont(), ImGui::GetFontSize(),
                                       ImVec2(textX, textY), ImVec4(1, 1, 1, 1), healthText.c_str());
                    }
                }
                
                // Armor bar - улучшенная версия из antisocial с градиентами и отступом
                if (settings.showArmor && armor > 0) {
                    float armor_pos = rectMax.x + 7; // Увеличен отступ от бокса
                    float armor_length = lerp(rectMax.y, rectMin.y - 1.5f, (float)armor / 100.0f);
                    
                    // Background с закругленными углами
                    draw->AddRectFilled(ImVec2(armor_pos - 1, rectMin.y - 1.5f),
                                       ImVec2(armor_pos + 1, rectMax.y + 1.5f),
                                       IM_COL32(0, 0, 0, 165), 1.0f);
                    
                    // Armor bar с градиентом
                    int vertStartIdx = draw->VtxBuffer.Size;
                    draw->AddRectFilled(ImVec2(armor_pos - 2, rectMax.y), 
                                       ImVec2(armor_pos, armor_length), 
                                       ImGui::ColorConvertFloat4ToU32(armorColor), 1.0f);
                    int vertEndIdx = draw->VtxBuffer.Size;
                    
                    // Применяем вертикальный градиент
                    ImVec4 armorColorDark = armorColor;
                    armorColorDark.x *= 0.7f;
                    armorColorDark.y *= 0.7f;
                    armorColorDark.z *= 0.7f;
                    ImGui::ShadeVertsLinearColorGradientKeepAlpha(draw, vertStartIdx, vertEndIdx,
                                                                  ImVec2(armor_pos, armor_length),
                                                                  ImVec2(armor_pos, rectMax.y),
                                                                  ImGui::ColorConvertFloat4ToU32(armorColor),
                                                                  ImGui::ColorConvertFloat4ToU32(armorColorDark));
                    
                    // Outline
                    draw->AddRect(ImVec2(armor_pos - 3, rectMin.y - 2.5f), 
                                 ImVec2(armor_pos + 2, rectMax.y + 1.5f), 
                                 IM_COL32(0, 0, 0, 200), 1.0f, 0, 1.0f);
                    
                    // Armor text
                    if (armor < 90 || armor > 100) {
                        std::string armorText = std::to_string(armor);
                        ImVec2 textSize = ImGui::CalcTextSize(armorText.c_str());
                        float textX = armor_pos - textSize.x / 2 + 1;
                        float textY = armor_length - textSize.y / 2;
                        AddOutlinedText(draw, ImGui::GetFont(), ImGui::GetFontSize(),
                                       ImVec2(textX, textY), ImVec4(1, 1, 1, 1), armorText.c_str());
                    }
                }
                
                // Lines - улучшенная версия из antisocial с тенями
                if (settings.showLine) {
                    ImVec4 lineColor = boxColor;
                    lineColor.w *= 0.8f; // Немного прозрачнее
                    float centerX = rectMin.x + (rectMax.x - rectMin.x) / 2;
                    
                    ImVec2 lineStart, lineEnd;
                    
                    if (settings.lineType == 0) { // Сверху
                        lineStart = ImVec2(displaySize.x / 2, 0);
                        lineEnd = ImVec2(centerX, rectMin.y);
                    } else if (settings.lineType == 1) { // От центра
                        lineStart = ImVec2(displaySize.x / 2, displaySize.y / 2);
                        lineEnd = ImVec2(centerX, rectMin.y);
                    } else if (settings.lineType == 2) { // Снизу
                        lineStart = ImVec2(displaySize.x / 2, displaySize.y);
                        lineEnd = ImVec2(centerX, rectMax.y);
                    }
                    
                    // Рисуем snapline с тенью
                    DrawSnapline(lineStart, lineEnd, lineColor, settings.lineWidth);
                }
                
                // Skeleton - как в lst
                if (settings.showSkeleton) {
                    DrawSkeleton(player, skelColor);
                }
                
                // Distance - как в lst с правильным форматированием
                if (settings.showDistance) {
                    int finalDist = static_cast<int>(distance);
                    std::string distText = std::to_string(finalDist) + "m";
                    float centerX = rectMin.x + (rectMax.x - rectMin.x) / 2;
                    ImVec2 textSize = ImGui::CalcTextSize(distText.c_str());
                    AddText(false, false, ImVec2(centerX - textSize.x / 2, rectMax.y + 6), 
                           ImVec4(1, 1, 1, 1), distText.c_str(), draw);
                }
                
                // Nickname - как в lst
                if (settings.showName) {
                    if (hooks::GetNickName) {
                        monoString* nameStr = hooks::GetNickName(photon);
                        if (nameStr && nameStr->getChars()) {
                            float centerX = rectMin.x + (rectMax.x - rectMin.x) / 2;
                            ImVec2 textSize = ImGui::CalcTextSize(nameStr->getChars());
                            AddText(false, false, ImVec2(centerX - textSize.x / 2, rectMin.y - 20), 
                                   ImVec4(1, 1, 1, 1), nameStr->getChars(), draw);
                        }
                    }
                }
            }
            
            
            // Рисуем индикатор цели Aimbot поверх всего
            DrawAimbotTarget();
            
        } catch (const std::exception& e) {
            NSLog(@"[ESP] EXCEPTION in DrawESP: %s", e.what());
        } catch (...) {
            NSLog(@"[ESP] UNKNOWN EXCEPTION in DrawESP");
        }
    }
}
