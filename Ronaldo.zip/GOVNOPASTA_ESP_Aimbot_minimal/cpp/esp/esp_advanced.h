#pragma once

#include "../interface/rendering/imgui/imgui.h"
#include "../hooks/structures.hpp"
#include <string>
#include <vector>
#include <unordered_map>

namespace ESP {

// Структуры для анимации (упрощенная версия из antisocial)
template<typename T>
struct Animator {
    T current;
    T target;
    float speed = 0.1f;
    
    Animator() : current(T()), target(T()) {}
    explicit Animator(T val) : current(val), target(val) {}
    
    void update(T new_target) {
        target = new_target;
        // Простая линейная интерполяция
        if constexpr (std::is_same_v<T, float>) {
            current += (target - current) * speed;
        } else if constexpr (std::is_same_v<T, ImVec4>) {
            current.x += (target.x - current.x) * speed;
            current.y += (target.y - current.y) * speed;
            current.z += (target.z - current.z) * speed;
            current.w += (target.w - current.w) * speed;
        }
    }
    
    T get() const { return current; }
    void set(T val) { current = val; target = val; }
};

// Параметры анимации для каждого игрока
struct PlayerESPParams {
    Animator<float> health;
    Animator<float> health_alpha;
    Animator<float> health_value;
    Animator<float> ammo;
    Animator<float> ammo_alpha;
    Animator<float> ammo_value;
    Animator<float> alpha;
    Animator<float> weapon;
    Animator<float> nickname;
    
    Animator<ImVec4> health_min_color;
    Animator<ImVec4> health_max_color;
    Animator<ImVec4> ammo_min_color;
    Animator<ImVec4> ammo_max_color;
    Animator<ImVec4> rect_start_color;
    Animator<ImVec4> rect_end_color;
    Animator<ImVec4> nickname_color;
    Animator<ImVec4> weapon_color;
    
    int prev_weapon_id = 0;
};

// Гранаты игрока
struct PlayerGrenades {
    bool he;
    bool smoke;
    bool flash;
};

// Флаги ESP
struct ESPFlag {
    std::string text;
    ImVec4 color;
};

// Данные игрока для ESP
struct PlayerESPData {
    void* player;
    Vector3 position;
    ImRect bounds;
    std::string uuid;
    bool untouchable;
    int health;
    int armor;
    short clip;
    short max_clip;
    int weapon_id;
    std::string nickname;
    PlayerGrenades grenades;
    float distance;
    bool visible;
};

// Класс для рендеринга ESP игрока
class PlayerESPRenderer {
public:
    PlayerESPRenderer(const PlayerESPData& data, ImDrawList* drawList = ImGui::GetBackgroundDrawList());
    
    void RenderBox();
    void RenderHealthBar();
    void RenderArmorBar();
    void RenderAmmoBar(bool available);
    void RenderWeapon();
    void RenderNickname();
    void RenderDistance();
    void RenderFlags(const std::vector<ESPFlag>& flags);
    void RenderSkeleton();
    void RenderSnaplines();
    void RenderOffscreen();
    
    static std::unordered_map<std::string, PlayerESPParams> s_params;
    
private:
    PlayerESPData m_data;
    ImDrawList* m_drawList;
    
    // Вспомогательные функции
    void AddOutlinedText(const ImVec2& pos, const ImVec4& color, const char* text);
    void AddShadowText(const ImVec2& pos, const ImVec4& color, const char* text);
    ImVec4 LerpColor(const ImVec4& a, const ImVec4& b, float t);
    ImVec4 ToGrayscale(const ImVec4& color);
    ImVec4 AlphaInterpolate(const ImVec4& color, float alpha);
};

// Функции для рисования
void DrawAdvancedESP();

} // namespace ESP
