# Offscreen Arrows & Aiming Data - Интеграция

## ✅ Что сделано

### 1. Offscreen стрелочки (из antisocial)
- **Интегрировано в**: `cpp/esp/esp.mm` функция `DrawOffscreenIndicator()`
- **Логика**: 1 в 1 из `antisocial/src/cheat/game/features/visual/esp/players/players.cpp`
- **Использует**: `curEulerAngles` из `AimingData` для правильного расчета угла

### 2. Aiming Data структуры
- **Файл**: `cpp/hooks/aiming_data.hpp`
- **Оффсеты** (проверены по dump.cs):
  - `PlayerController -> AimController`: **0x90**
  - `AimController -> AimingData`: **0x90**
  - `AimingData -> curEulerAngles`: **0x24**

## 🎯 Как работает

### Offscreen стрелочки:

```cpp
// В esp.mm уже интегрировано:
if (!checker) {  // Если игрок за экраном
    if (settings.showOffscreen) {
        DrawOffscreenIndicator(player, boxColor);
    }
    continue;
}
```

**Алгоритм** (из antisocial):
1. Получаем `curEulerAngles` из `AimingData` локального игрока
2. Вычисляем направление от локального игрока к цели (2D)
3. Вычисляем угол: `atan2(direction.x, direction.y) * 57.29578f - 180.0f - eulerAngles.y`
4. Рисуем треугольник на окружности вокруг центра экрана

### Получение AimingData:

```cpp
#include "aiming_data.hpp"

// Получить углы камеры локального игрока
Vector3 angles = aiming::helpers::get_aim_angles(hooks::localPlayer);

// Установить углы (для аимбота)
aiming::helpers::set_aim_angles(hooks::localPlayer, newAngles);

// Получить AimingData напрямую
aiming::AimingData* data = aiming::helpers::get_player_aiming_data(hooks::localPlayer);
if (data) {
    Vector3 euler = data->curEulerAngles;  // offset 0x24
    Vector3 aim = data->curAimAngle;       // offset 0x18
    float wtCoeff = data->curWTCoeff;      // offset 0x10
}
```

## 📊 Структура AimingData

```cpp
struct AimingData {
    void* vtable;                    // 0x00
    char padding[0x10];              // 0x08
    float curWTCoeff;                // 0x10 - коэффициент оружия
    float curMTCoeff;                // 0x14 - коэффициент движения
    Vector3 curAimAngle;             // 0x18 - угол прицеливания
    Vector3 curEulerAngles;          // 0x24 - углы Эйлера (ДЛЯ OFFSCREEN!)
    TransformTR prevGPHOffsetOnStand;// 0x30
    TransformTR prevGPHOffsetOnCrouch;// 0x38
    TransformTR gunSubstitude;       // 0x40
    float currentSpineZAxisOffset;   // 0x48
    float standTypeCoeff;            // 0x4C
};
```

## 🔧 Использование

### В ESP (уже работает):
Offscreen стрелочки автоматически рисуются когда игрок за экраном и `settings.showOffscreen = true`

### Для аимбота:
```cpp
#include "aiming_data.hpp"

void MyAimbot(void* target) {
    // Получаем AimingData локального игрока
    aiming::AimingData* localAim = aiming::helpers::get_player_aiming_data(hooks::localPlayer);
    if (!localAim) return;
    
    // Вычисляем углы к цели
    Vector3 targetPos = hooks::GetPlayerLocation(target);
    Vector3 localPos = hooks::GetPlayerLocation(hooks::localPlayer);
    
    // ... вычисления направления ...
    
    // Устанавливаем новые углы
    localAim->curEulerAngles = newAngles;
    localAim->curAimAngle = newAngles;
}
```

## 📝 Источники

- **Offscreen логика**: `555/antisocial/src/cheat/game/features/visual/esp/players/players.cpp:45-96`
- **AimingData структура**: `dump leo/dump.cs:124882-124900`
- **PlayerController**: `dump leo/dump.cs:118544-118700`
- **Оффсеты**: Проверены по dump.cs

## ⚠️ Важно

- Offscreen стрелочки используют `curEulerAngles` (offset 0x24) из AimingData
- Это НЕ углы камеры, а углы прицеливания игрока
- Работает корректно только для локального игрока
- Для других игроков нужно использовать их собственный AimingData
