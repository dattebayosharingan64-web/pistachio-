# ✅ OFFSCREEN СТРЕЛОЧКИ - ПОЛНАЯ ИНТЕГРАЦИЯ

## 🎯 Статус: ГОТОВО И РАБОТАЕТ

### ✅ Что интегрировано:

#### 1. **ESP Рисовка** (`cpp/esp/esp.mm`)
```cpp
// Строка 513-516
if (!checker) {  // Если игрок за экраном
    if (settings.showOffscreen) {
        DrawOffscreenIndicator(player, boxColor);
    }
    continue;
}
```
- ✅ Offscreen стрелочки рисуются автоматически
- ✅ Используют правильные углы из AimingData
- ✅ Логика 1 в 1 из antisocial

#### 2. **Настройки** (`cpp/esp/esp.h`)
```cpp
// Строка 23
bool showOffscreen = true;  // Включено по умолчанию
```
- ✅ Настройка добавлена в структуру Settings
- ✅ По умолчанию включена

#### 3. **Меню** (`cpp/main.mm`)
```cpp
// Строка 164
ImGui::Checkbox("Show Offscreen Indicators", &ESP::settings.showOffscreen);
```
- ✅ Чекбокс в меню ESP
- ✅ Можно включать/выключать в реальном времени

#### 4. **Aiming Data** (`cpp/hooks/aiming_data.hpp`)
```cpp
// Оффсеты проверены по dump.cs:
PlayerController -> AimController: 0x90
AimController -> AimingData: 0x90
AimingData -> curEulerAngles: 0x24
```
- ✅ Структуры из dump.cs
- ✅ Helper функции для работы
- ✅ Все оффсеты задокументированы

## 🔧 Как работает:

### Алгоритм (из antisocial):
1. **Проверка видимости**: Если `world2screen_c()` возвращает `false` - игрок за экраном
2. **Получение углов**: Берем `curEulerAngles` из `AimingData` локального игрока
3. **Вычисление направления**: 
   ```cpp
   float dx = localPos.x - playerPos.x;
   float dz = localPos.z - playerPos.z;
   ImVec2 direction = normalize(dx, dz);
   ```
4. **Вычисление угла**:
   ```cpp
   float angle = atan2(direction.x, direction.y) * 57.29578f - 180.0f - eulerAngles.y;
   ```
5. **Отрисовка**: Треугольник + точка на окружности вокруг центра экрана

### Получение углов камеры:
```cpp
// В DrawOffscreenIndicator (строка 145-152)
void* aimController = *(void**)((uintptr_t)hooks::localPlayer + 0x90);
if (aimController) {
    void* aimingData = *(void**)((uintptr_t)aimController + 0x90);
    if (aimingData) {
        eulerAngles = *(Vector3*)((uintptr_t)aimingData + 0x24);
    }
}
```

## 📊 Что рисуется:

```
        ╱╲          <- Треугольник (белый)
       ╱  ╲
      ╱____╲
        •           <- Точка в центре
```

- **Треугольник**: Указывает направление к игроку
- **Точка**: Центр индикатора
- **Тень**: Черная обводка для контраста
- **Цвет**: Берется из `boxColor` (зеленый если видим, красный если нет)
- **Позиция**: На окружности радиусом 60px от центра экрана

## 🎮 Использование:

### В игре:
1. Открой меню (Insert)
2. Вкладка "ESP Settings"
3. Включи "Show Offscreen Indicators" (уже включено по умолчанию)
4. Враги за экраном будут показаны стрелочками

### Настройка цветов:
- Стрелочки используют те же цвета что и боксы:
  - **Зеленый** = враг видим (через стену)
  - **Красный** = враг не видим

## 📝 Файлы:

| Файл | Что там |
|------|---------|
| `cpp/esp/esp.mm` | Функция `DrawOffscreenIndicator()` - рисовка стрелочек |
| `cpp/esp/esp.h` | Настройка `showOffscreen` |
| `cpp/main.mm` | Чекбокс в меню |
| `cpp/hooks/aiming_data.hpp` | Структуры AimingData + helper функции |
| `cpp/hooks/offsets.hpp` | Объявления функций |

## ⚙️ Технические детали:

### Оффсеты (из dump.cs):
```cpp
PlayerController + 0x90 = AimController*
AimController + 0x90 = AimingData*
AimingData + 0x10 = float curWTCoeff
AimingData + 0x14 = float curMTCoeff
AimingData + 0x18 = Vector3 curAimAngle
AimingData + 0x24 = Vector3 curEulerAngles  // ← ИСПОЛЬЗУЕТСЯ ДЛЯ OFFSCREEN
AimingData + 0x30 = TransformTR prevGPHOffsetOnStand
AimingData + 0x48 = float currentSpineZAxisOffset
AimingData + 0x4C = float standTypeCoeff
```

### Функция CosTanHorizontal:
```cpp
// Вычисляет позицию на окружности
ImVec2 CosTanHorizontal(float angle, float range, float x, float y, int length) {
    float ourAngle = angle + 45.0f;
    float yaw = ourAngle * (M_PI / 180.0f);
    float viewCosinus = cosf(yaw);
    float viewSinus = sinf(yaw);
    float x2 = range * (-viewCosinus) + range * viewSinus;
    float y2 = range * (-viewCosinus) - range * viewSinus;
    return ImVec2(x + (x2 / range * length), y + (y2 / range * length));
}
```

## 🔍 Отладка:

Если стрелочки не работают:
1. Проверь что `settings.showOffscreen = true`
2. Проверь что враги действительно за экраном
3. Проверь что локальный игрок жив
4. Проверь что `hooks::localPlayer` не null
5. Проверь логи на ошибки

## 🎉 Итог:

✅ Offscreen стрелочки **ПОЛНОСТЬЮ ИНТЕГРИРОВАНЫ**
✅ Работают **В РИСОВКЕ**
✅ Есть **В МЕНЮ**
✅ Используют **ПРАВИЛЬНЫЕ УГЛЫ** из AimingData
✅ Логика **1 В 1 ИЗ ANTISOCIAL**

**Всё готово к использованию!**
