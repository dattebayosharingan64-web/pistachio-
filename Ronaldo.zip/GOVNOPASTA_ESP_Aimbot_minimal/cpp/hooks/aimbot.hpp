#ifndef AIMBOT_HPP
#define AIMBOT_HPP

#include "structures.hpp"
#include "offsets.hpp"

namespace hooks {
    
    // Настройки аимбота
    struct AimbotSettings {
        bool Enable = false;
        bool VisibleCheck = true;
        bool TeamCheck = true;
        bool FOVCheck = true;
        int FOV = 90;
        float Smooth = 0.1f; // 0 = instant, > 0 = smooth (меньше = плавнее)
        
        // Bone selection (0 = Head, 1 = Spine2, 2 = Spine1, 3 = Hip, 4 = Hands)
        int TargetBone = 0;
        
        // Визуализация
        float ColorR = 1.0f;
        float ColorG = 0.5f;
        float ColorB = 0.0f;
        float ColorA = 1.0f;
        
        // Внутренние переменные
        void* TargetPlayer = nullptr;
        void* TargetBonePtr = nullptr;
        Vector3 TargetPosition;
        bool CanAim = false;
    };
    
    extern AimbotSettings Aimbot;
    
    // Функции аимбота
    void* SelectTargetBone(void* player);
    float CalculateAngleToBone(void* bone, const Vector3& viewPosition);
    void ExecuteAimbot();
    Vector3 CalculateAimAngles(const Vector3& from, const Vector3& to);
    void ApplyAimAngles(const Vector3& angles, float smooth);
}

#endif // AIMBOT_HPP
