#include "aimbot.hpp"
#include "player.hpp"
#include "offsets.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace hooks {

AimbotSettings Aimbot;

namespace {
constexpr uintptr_t kMinReadableAddress = 0x1000;
constexpr float kMinVectorLength = 1.0e-5f;

bool IsReadablePointer(const void* pointer) {
    return reinterpret_cast<uintptr_t>(pointer) >= kMinReadableAddress;
}

bool IsFiniteVector(const Vector3& value) {
    return std::isfinite(value.x) && std::isfinite(value.y) && std::isfinite(value.z);
}

float NormalizeAngle(float angle) {
    if (!std::isfinite(angle)) return 0.0f;
    angle = std::fmod(angle + 180.0f, 360.0f);
    if (angle < 0.0f) angle += 360.0f;
    return angle - 180.0f;
}

float LerpAngle(float current, float target, float amount) {
    const float delta = NormalizeAngle(target - current);
    return NormalizeAngle(current + delta * amount);
}

void ResetTarget() {
    Aimbot.TargetPlayer = nullptr;
    Aimbot.TargetBonePtr = nullptr;
    Aimbot.TargetPosition = Vector3();
    Aimbot.CanAim = false;
}

void* ReadBonePointer(void* bipedMap, uintptr_t offset) {
    if (!IsReadablePointer(bipedMap)) return nullptr;
    void* bone = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(bipedMap) + offset);
    return IsReadablePointer(bone) ? bone : nullptr;
}
} // namespace

Vector3 CalculateAimAngles(const Vector3& from, const Vector3& to) {
    const Vector3 direction = to - from;
    if (!IsFiniteVector(direction)) return Vector3();

    const float horizontalLength = std::sqrt(direction.x * direction.x + direction.z * direction.z);
    const float length = std::sqrt(horizontalLength * horizontalLength + direction.y * direction.y);
    if (!std::isfinite(length) || length < kMinVectorLength) return Vector3();

    // Unity-style Euler angles: X is pitch, Y is yaw, Z is roll.
    const float pitch = -std::atan2(direction.y, horizontalLength) * Rad2Deg;
    const float yaw = std::atan2(direction.x, direction.z) * Rad2Deg;
    return Vector3(NormalizeAngle(pitch), NormalizeAngle(yaw), 0.0f);
}

float CalculateAngleToBone(void* bone, const Vector3& viewPosition) {
    if (!IsReadablePointer(bone) || !IsFiniteVector(viewPosition) ||
        !get_camera || !get_transform || !get_position || !get_forward) {
        return 999.0f;
    }

    void* camera = get_camera();
    if (!IsReadablePointer(camera)) return 999.0f;

    void* cameraTransform = get_transform(camera);
    if (!IsReadablePointer(cameraTransform)) return 999.0f;

    const Vector3 bonePosition = get_position(bone);
    const Vector3 cameraForward = get_forward(cameraTransform);
    if (!IsFiniteVector(bonePosition) || !IsFiniteVector(cameraForward)) return 999.0f;

    const Vector3 direction = Vector3::Normalize(bonePosition - viewPosition);
    if (Vector3::Magnitude(direction) < kMinVectorLength ||
        Vector3::Magnitude(cameraForward) < kMinVectorLength) {
        return 999.0f;
    }

    const float angle = Vector3::Angle(direction, cameraForward);
    return std::isfinite(angle) ? angle : 999.0f;
}

void* SelectTargetBone(void* player) {
    if (!IsReadablePointer(player) || !GetBipedMap) return nullptr;

    void* bipedMap = GetBipedMap(player);
    if (!IsReadablePointer(bipedMap)) return nullptr;

    // Offsets are retained from the supplied source; current metadata does not
    // contain field-offset records that would validate or replace them.
    switch (Aimbot.TargetBone) {
        case 0: return ReadBonePointer(bipedMap, 0x18); // Head
        case 1: return ReadBonePointer(bipedMap, 0x38); // Spine2
        case 2: return ReadBonePointer(bipedMap, 0x30); // Spine1
        case 3: return ReadBonePointer(bipedMap, 0x80); // Hip
        case 4: {
            void* leftHand = ReadBonePointer(bipedMap, 0x58);
            void* rightHand = ReadBonePointer(bipedMap, 0x78);
            return leftHand ? leftHand : rightHand;
        }
        default: return ReadBonePointer(bipedMap, 0x18);
    }
}

void ApplyAimAngles(const Vector3& targetAngles, float smooth) {
    if (!IsReadablePointer(localPlayer) || !IsFiniteVector(targetAngles)) return;

    // These two object offsets are inherited from the project. They have not
    // been confirmed by the supplied string-only metadata extract.
    void* aimController = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(localPlayer) + 0x90);
    if (!IsReadablePointer(aimController)) return;

    void* aimingData = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(aimController) + 0x90);
    if (!IsReadablePointer(aimingData)) return;

    auto* currentAim = reinterpret_cast<Vector3*>(reinterpret_cast<uintptr_t>(aimingData) + 0x18);
    auto* currentEuler = reinterpret_cast<Vector3*>(reinterpret_cast<uintptr_t>(aimingData) + 0x24);
    if (!IsFiniteVector(*currentAim) || !IsFiniteVector(*currentEuler)) return;

    const float amount = std::clamp(std::isfinite(smooth) ? smooth : 0.0f, 0.0f, 1.0f);
    if (amount <= 0.0f) {
        *currentAim = targetAngles;
        *currentEuler = targetAngles;
        return;
    }

    const Vector3 result(
        LerpAngle(currentAim->x, targetAngles.x, amount),
        LerpAngle(currentAim->y, targetAngles.y, amount),
        LerpAngle(currentAim->z, targetAngles.z, amount));
    *currentAim = result;
    *currentEuler = result;
}

void ExecuteAimbot() {
    if (!Aimbot.Enable || !IsReadablePointer(localPlayer) ||
        !get_camera || !get_transform || !get_position || !get_forward ||
        !GetPlayerHealth || !GetPlayerTeam || !GetBipedMap) {
        ResetTarget();
        return;
    }

    void* camera = get_camera();
    if (!IsReadablePointer(camera)) {
        ResetTarget();
        return;
    }

    void* cameraTransform = get_transform(camera);
    if (!IsReadablePointer(cameraTransform)) {
        ResetTarget();
        return;
    }

    const Vector3 viewPosition = get_position(cameraTransform);
    if (!IsFiniteVector(viewPosition)) {
        ResetTarget();
        return;
    }

    void* bestTarget = nullptr;
    void* bestBone = nullptr;
    float bestAngle = 999.0f;

    for (void* player : players) {
        if (!IsReadablePointer(player) || player == localPlayer) continue;

        void* photon = get_photon(player);
        if (!IsReadablePointer(photon)) continue;

        if (Aimbot.TeamCheck && GetPlayerTeam(photon) == localTeam) continue;
        if (GetPlayerHealth(photon) <= 0) continue;

        void* bone = SelectTargetBone(player);
        if (!IsReadablePointer(bone)) continue;

        if (Aimbot.VisibleCheck && !IsPlayerVisible(player)) continue;

        const float angle = CalculateAngleToBone(bone, viewPosition);
        if (!std::isfinite(angle) || angle >= bestAngle) continue;

        const float fovLimit = std::clamp(static_cast<float>(Aimbot.FOV), 1.0f, 180.0f);
        if (Aimbot.FOVCheck && angle > fovLimit) continue;

        bestAngle = angle;
        bestTarget = player;
        bestBone = bone;
    }

    if (!IsReadablePointer(bestTarget) || !IsReadablePointer(bestBone)) {
        ResetTarget();
        return;
    }

    const Vector3 targetPosition = get_position(bestBone);
    if (!IsFiniteVector(targetPosition)) {
        ResetTarget();
        return;
    }

    Aimbot.TargetPlayer = bestTarget;
    Aimbot.TargetBonePtr = bestBone;
    Aimbot.TargetPosition = targetPosition;
    Aimbot.CanAim = true;

    const Vector3 targetAngles = CalculateAimAngles(viewPosition, targetPosition);
    if (IsFiniteVector(targetAngles)) ApplyAimAngles(targetAngles, Aimbot.Smooth);
}

} // namespace hooks
