#ifndef AIMING_DATA_HPP
#define AIMING_DATA_HPP

#include "structures.hpp"

// ============================================================================
// AIMING DATA STRUCTURES - ИЗ DUMP.CS
// ============================================================================
// Все оффсеты проверены по dump leo/dump.cs
// PlayerController -> AimController: 0x90
// AimController -> AimingData: 0x90
// AimingData -> curEulerAngles: 0x24

namespace aiming {

// Структура TransformTR (Transform Translation + Rotation)
struct TransformTR {
    Vector3 position;    // 0x00
    Quaternion rotation; // 0x0C
};

// Основная структура AimingData из dump.cs
// Namespace: Axlebolt.Standoff.Player.Aim
// public class AimingData : MessageBase // TypeDefIndex: 3291
struct AimingData {
    // Базовый класс MessageBase (обычно пустой или с vtable)
    void* vtable;                           // 0x00
    char padding[0x10];                     // 0x08 - padding до первого поля
    
    // Поля AimingData (ПРОВЕРЕНО ПО DUMP.CS)
    float curWTCoeff;                       // 0x10 - Текущий коэффициент оружия (Weapon Transform)
    float curMTCoeff;                       // 0x14 - Текущий коэффициент движения (Movement Transform)
    Vector3 curAimAngle;                    // 0x18 - Текущий угол прицеливания
    Vector3 curEulerAngles;                 // 0x24 - ГЛАВНОЕ! Текущие углы Эйлера (yaw, pitch, roll)
    TransformTR prevGPHOffsetOnStand;       // 0x30 - Предыдущее смещение оружия стоя
    TransformTR prevGPHOffsetOnCrouch;      // 0x38 - Предыдущее смещение оружия в приседе
    TransformTR gunSubstitude;              // 0x40 - Замена оружия (для анимации)
    float currentSpineZAxisOffset;          // 0x48 - Текущее смещение позвоночника по оси Z
    float standTypeCoeff;                   // 0x4C - Коэффициент типа стойки (стоя/присед)
};

// Режимы прицеливания из GunController
// public enum GunController.AimingMode // TypeDefIndex: 3574
enum class AimingMode : int {
    Aiming = 0,              // Прицеливание активно
    AimingReload = 1,        // Прицеливание во время перезарядки
    NotAiming = 2,           // Не прицеливается
    StartingAiming = 3,      // Начало прицеливания
    FinishingAiming = 4      // Завершение прицеливания
};

// ============================================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ РАБОТЫ С ПРИЦЕЛИВАНИЕМ
// ============================================================================

namespace helpers {
    
    // Получить AimController из PlayerController
    // Offset: 0x90 (проверено по dump.cs)
    inline void* get_aim_controller(void* player_controller) {
        if (!player_controller) return nullptr;
        return *(void**)((uintptr_t)player_controller + 0x90);
    }
    
    // Получить AimingData из AimController
    // Offset: 0x90 (проверено по dump.cs)
    inline AimingData* get_aiming_data(void* aim_controller) {
        if (!aim_controller) return nullptr;
        return (AimingData*)*(void**)((uintptr_t)aim_controller + 0x90);
    }
    
    // Получить AimingData напрямую из PlayerController
    inline AimingData* get_player_aiming_data(void* player_controller) {
        void* aim_controller = get_aim_controller(player_controller);
        return get_aiming_data(aim_controller);
    }
    
    // Получение текущих углов прицеливания (для offscreen стрелочек)
    // Offset: 0x24 в AimingData
    inline Vector3 get_aim_angles(void* player_controller) {
        AimingData* data = get_player_aiming_data(player_controller);
        if (!data) return Vector3{0, 0, 0};
        return data->curEulerAngles;
    }
    
    // Получение текущего угла прицеливания (только направление)
    inline Vector3 get_aim_direction(void* player_controller) {
        AimingData* data = get_player_aiming_data(player_controller);
        if (!data) return Vector3{0, 0, 0};
        return data->curAimAngle;
    }
    
    // Установка углов прицеливания (для аимбота)
    inline void set_aim_angles(void* player_controller, const Vector3& angles) {
        AimingData* data = get_player_aiming_data(player_controller);
        if (!data) return;
        data->curEulerAngles = angles;
        data->curAimAngle = angles;
    }
    
    // Проверка валидности данных прицеливания
    inline bool is_valid_aim_data(AimingData* data) {
        return data != nullptr && data->vtable != nullptr;
    }
}

} // namespace aiming

#endif // AIMING_DATA_HPP
