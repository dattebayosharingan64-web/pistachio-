#ifndef HOOKS_HPP
#define HOOKS_HPP

#include "structures.hpp"
#include "offsets.hpp"
#include "player.hpp"
#import <os/log.h>

namespace hooks {
    extern void (*old_Player_Update)(void* instance);
    void Player_Update(void* instance);
    void initialize();
}

#endif // HOOKS_HPP
