#include "hooks.hpp"
#include "aimbot.hpp"
#include "static_hook.h"
#import <Foundation/Foundation.h>

namespace hooks {
    void (*old_Player_Update)(void* instance) = nullptr;

    void Player_Update(void* player) {
        @try {
            if (player) {
                void* photonView = get_view(player);
                if (photonView) {
                    void* owner = get_owner(photonView);
                    if (owner) {
                        const bool isLocal = *reinterpret_cast<bool*>(
                            reinterpret_cast<uintptr_t>(owner) + ENCRYPTOFFSET(0x28));
                        void* photon = get_photon(player);
                        if (photon) {
                            if (!isLocal && !playerFind(player)) players.push_back(player);
                            clearPlayers();
                        }
                        if (isLocal) {
                            localPlayer = player;
                            localTeam = GetPlayerTeam ? GetPlayerTeam(owner) : 0;
                            ExecuteAimbot();
                        }
                    }
                }
            }
        } @catch (NSException* exception) {
            NSLog(@"[ESP/AIM] Player_Update exception: %@", exception);
        }

        if (old_Player_Update) old_Player_Update(player);
    }

    void initialize() {
        try {
            HOOK(ENCRYPTOFFSET(0x1AB3448), Player_Update, old_Player_Update);

            GetNickName = (monoString* (*)(void*))getRealOffset(ENCRYPTOFFSET(0x18B7E10));
            get_owner = (void* (*)(void*))getRealOffset(ENCRYPTOFFSET(0x18B7D64));
            isOwnerActive = (bool (*)(void*))getRealOffset(ENCRYPTOFFSET(0x18B7D74));

            GetPlayerTeam = (int (*)(void*))getRealOffset(ENCRYPTOFFSET(0x1D37BCC));
            GetPlayerArmor = (int (*)(void*))getRealOffset(ENCRYPTOFFSET(0x1AAE978));
            GetPlayerHealth = (int (*)(void*))getRealOffset(ENCRYPTOFFSET(0x1AAE7E8));

            get_position = (Vector3 (*)(void*))getRealOffset(ENCRYPTOFFSET(0x318F044));
            get_forward = (Vector3 (*)(void*))getRealOffset(ENCRYPTOFFSET(0x318F62C));
            get_transform = (void* (*)(void*))getRealOffset(ENCRYPTOFFSET(0x3184A78));
            get_camera = (void* (*)())getRealOffset(ENCRYPTOFFSET(0x315FE6C));
            WorldToViewpoint = (Vector3 (*)(void*, Vector3, int))getRealOffset(ENCRYPTOFFSET(0x315F8EC));
            get_eulerAngles = (Vector3 (*)(void*))getRealOffset(ENCRYPTOFFSET(0x318F2F4));

            Linecast228 = (bool (*)(Vector3, Vector3, int))getRealOffset(ENCRYPTOFFSET(0x31D6A68));
            get_width = (int (*)())getRealOffset(ENCRYPTOFFSET(0x316741C));
            get_height = (int (*)())getRealOffset(ENCRYPTOFFSET(0x3167450));
            GetBipedMap = (void* (*)(void*))getRealOffset(ENCRYPTOFFSET(0x1AAF458));

            get_gameObject = (void* (*)(void*))getRealOffset(ENCRYPTOFFSET(0x3184A6C));
            GetComponentsInChildren = (monoArray<void**>* (*)(void*, void*, bool))getRealOffset(ENCRYPTOFFSET(0x3184B88));
            GetComponent = (void* (*)(void*, void*))getRealOffset(ENCRYPTOFFSET(0x3184AF4));
            FindObjectsOfType = (monoArray<void*>* (*)(void*))getRealOffset(ENCRYPTOFFSET(0x3183F50));
            GetType = (void* (*)(const char*))getRealOffset(ENCRYPTOFFSET(0x31D8E3C));
            CreateString = (void* (*)(const char*))getRealOffset(ENCRYPTOFFSET(0x31D8A20));
            get_isVisible = (bool (*)(void*))getRealOffset(ENCRYPTOFFSET(0x3166D48));

            NSLog(@"[HOOK] ESP/Aimbot initialized");
        } catch (...) {
            NSLog(@"[HOOK] ESP/Aimbot initialization failed");
        }
    }
}
