#include "offsets.hpp"

namespace hooks {
    
    // PhotonView методы
    monoString* (*GetNickName)(void*) = nullptr;
    void* (*get_owner)(void*) = nullptr;
    bool (*isOwnerActive)(void*) = nullptr;
    
    // Player stats
    int (*GetPlayerTeam)(void*) = nullptr;
    int (*GetPlayerArmor)(void*) = nullptr;
    int (*GetPlayerHealth)(void*) = nullptr;
    
    // Transform & Camera
    Vector3 (*get_position)(void*) = nullptr;
    void (*set_position)(void*, Vector3) = nullptr;
    Vector3 (*get_forward)(void*) = nullptr;
    void* (*get_transform)(void*) = nullptr;
    void* (*get_camera)() = nullptr;
    Vector3 (*WorldToViewpoint)(void*, Vector3, int) = nullptr;
    Vector3 (*get_eulerAngles)(void*) = nullptr;
    
    // Physics
    bool (*Linecast228)(Vector3, Vector3, int) = nullptr;
    
    // Screen
    int (*get_width)() = nullptr;
    int (*get_height)() = nullptr;
    
    // Player specific
    void* (*GetBipedMap)(void*) = nullptr;
    void (*SetVisible)(void*, bool) = nullptr;
    void (*SetEnabled)(void*, bool) = nullptr;
    
    // GameObject & Component
    void* (*get_gameObject)(void*) = nullptr;
    monoArray<void**>* (*GetComponentsInChildren)(void*, void*, bool) = nullptr;
    void* (*GetComponent)(void*, void*) = nullptr;
    
    // Object
    monoArray<void*>* (*FindObjectsOfType)(void*) = nullptr;
    void* (*GetType)(const char*) = nullptr;
    
    // String
    void* (*CreateString)(const char*) = nullptr;
    
    // Renderer
    bool (*get_isVisible)(void*) = nullptr;
}
