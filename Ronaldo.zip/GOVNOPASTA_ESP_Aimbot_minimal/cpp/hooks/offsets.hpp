#ifndef OFFSETS_HPP
#define OFFSETS_HPP

#include "structures.hpp"
#include "memutils.hpp"

// Макрос для шифрования оффсетов
#define ENCRYPTOFFSET(x) x

namespace hooks {
    
    // PhotonView методы
    extern monoString* (*GetNickName)(void*);
    extern void* (*get_owner)(void*);
    extern bool (*isOwnerActive)(void*);
    
    // Player stats
    extern int (*GetPlayerTeam)(void*);
    extern int (*GetPlayerArmor)(void*);
    extern int (*GetPlayerHealth)(void*);
    
    // Transform & Camera
    extern Vector3 (*get_position)(void*);
    extern void (*set_position)(void*, Vector3);
    extern Vector3 (*get_forward)(void*);
    extern void* (*get_transform)(void*);
    extern void* (*get_camera)();
    extern Vector3 (*WorldToViewpoint)(void*, Vector3, int);
    extern Vector3 (*get_eulerAngles)(void*); // Для offscreen indicators
    
    // Aiming & Camera Control
    extern void* (*GetAimController)(void*); // Получить AimController из PlayerController (offset 0x90)
    extern void* (*GetAimingData)(void*); // Получить AimingData из AimController (offset 0x90)
    extern Vector3 (*GetAimingAngles)(void*); // Получить curEulerAngles из AimingData
    
    // Physics
    extern bool (*Linecast228)(Vector3, Vector3, int);
    
    // Screen
    extern int (*get_width)();
    extern int (*get_height)();
    
    // Player specific
    extern void* (*GetBipedMap)(void*);
    extern void (*SetVisible)(void*, bool);
    extern void (*SetEnabled)(void*, bool);
    
    // GameObject & Component
    extern void* (*get_gameObject)(void*);
    extern monoArray<void**>* (*GetComponentsInChildren)(void*, void*, bool);
    extern void* (*GetComponent)(void*, void*);
    
    // Object
    extern monoArray<void*>* (*FindObjectsOfType)(void*);
    extern void* (*GetType)(const char*);
    
    // String
    extern void* (*CreateString)(const char*);
    
    // Renderer
    extern bool (*get_isVisible)(void*);
}

#endif // OFFSETS_HPP
