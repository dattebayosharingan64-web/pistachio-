#ifndef PLAYER_HPP
#define PLAYER_HPP

#include "structures.hpp"
#include "offsets.hpp"
#import <vector>

// Forward declaration для ImVec2
struct ImVec2;

namespace hooks {
    
    // Player management
    extern void* localPlayer;
    extern int localTeam;
    extern std::vector<void*> players;
    
    void clearPlayers();
    bool playerFind(void* pl);
    
    // Helper functions
    void* get_photon(void* player);
    void* GetPhoton(void* player);
    void* get_view(void* player);
    
    // World to screen
    ImVec2 world2screen_i(Vector3 pos);
    ImVec2 world2screen_c(Vector3 pos, bool &checker);
    
    // Player location & bones
    Vector3 GetPlayerLocation(void* player);
    void* get_head(void* player);
    void* get_neck(void* player);
    void* get_hip(void* player);
    
    Vector3 GetPlayerHead(void* player);
    Vector3 GetPlayerNeck(void* player);
    Vector3 GetPlayerHip(void* player);
    Vector3 GetPlayerleftLowerArm(void* player);
    Vector3 GetPlayerLeftHand(void* player);
    Vector3 GetPlayerRightHand(void* player);
    Vector3 GetPlayerleftUpperArm(void* player);
    Vector3 GetPlayerrightLowerArm(void* player);
    Vector3 GetPlayerrightUpperArm(void* player);
    Vector3 GetPlayerleftLowerLeg(void* player);
    Vector3 GetPlayerleftUpperLeg(void* player);
    Vector3 GetPlayerrightLowerLeg(void* player);
    Vector3 GetPlayerrightUpperLeg(void* player);
    
    // Visibility check
    bool IsPlayerVisible(void* player);
}

#endif // PLAYER_HPP
