#include "player.hpp"
#import <Foundation/Foundation.h>
#import <os/log.h>
#import "../interface/rendering/imgui/imgui.h"

namespace hooks {
    
    void* localPlayer = nullptr;
    int localTeam = 0;
    std::vector<void*> players;
    
    void* get_photon(void *player) {
        return *(void **)((uint64_t) player + ENCRYPTOFFSET(0x108));
    }

    void* GetPhoton(void *player) {
        return *(void **)((uint64_t) player + ENCRYPTOFFSET(0x108));
    }

    void* get_view(void *player) {
        return *(void **)((uint64_t) player + ENCRYPTOFFSET(0xF8));
    }

    ImVec2 world2screen_i(Vector3 pos) { 
        auto cam = get_camera();    
        if (!cam) return {0,0};    

        Vector3 worldPoint = WorldToViewpoint(cam,pos, 2);   
        Vector3 location; 

        int ScreenWidth = ImGui::GetIO().DisplaySize.x; 
        int ScreenHeight = ImGui::GetIO().DisplaySize.y; 

        location.x = ScreenWidth * worldPoint.x; 
        location.y = ScreenHeight - worldPoint.y * ScreenHeight; 
        location.z = worldPoint.z; 

        return {location.x, location.y}; 
    } 

    ImVec2 world2screen_c(Vector3 pos, bool &checker) { 
        auto cam = get_camera();    
        if (!cam) return {0,0};    
       
        Vector3 worldPoint = WorldToViewpoint(cam,pos, 2);   
        Vector3 location; 
     
        int ScreenWidth = ImGui::GetIO().DisplaySize.x; 
        int ScreenHeight = ImGui::GetIO().DisplaySize.y; 
     
        location.x = ScreenWidth * worldPoint.x; 
        location.y = ScreenHeight - worldPoint.y * ScreenHeight; 
        location.z = worldPoint.z; 
     
        checker = location.z > 1; 
     
        return {location.x, location.y}; 
    }

    void clearPlayers() {
        if (!players.empty()) {
            std::vector<void*> pls;
            for (int i = 0; i < players.size(); i++) {
                if (players[i] != NULL && get_photon(players[i]) !=NULL && GetPlayerHealth(get_photon(players[i])) > 0) {
                    pls.push_back(players[i]);
                }
            }
            players = pls;
        }
    }

    bool playerFind(void *pl) {
        if (pl != NULL) {
            for (int i = 0; i < players.size(); i++) {
                if (pl == players[i]) return true;
            }
        }
        return false;
    }

    Vector3 GetPlayerLocation(void *player) {
        Vector3 location;
        location = get_position(get_transform(player));
        return location;
    }

    // BIPED MAP BONE OFFSETS
    void *get_head(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return nullptr;
        return *(void **)((uint64_t) bipedMap + 0x18);
    }
    
    void *get_neck(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return nullptr;
        return *(void **)((uint64_t) bipedMap + 0x20);
    }
    
    void *get_hip(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return nullptr;
        return *(void **)((uint64_t) bipedMap + 0x80);
    }

    Vector3 GetPlayerHead(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x18);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerNeck(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x20);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerHip(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x80);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerleftLowerArm(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x50);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerLeftHand(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x58);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerRightHand(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x78);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerleftUpperArm(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x48);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerrightLowerArm(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x70);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerrightUpperArm(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x68);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerleftLowerLeg(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x90);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerleftUpperLeg(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0x88);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerrightLowerLeg(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0xB0);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }
    
    Vector3 GetPlayerrightUpperLeg(void *player) {
        void *bipedMap = GetBipedMap(player);
        if (!bipedMap) return Vector3(0,0,0);
        void *bone = *(void **) ((uint64_t) bipedMap + 0xA8);
        if (!bone) return Vector3(0,0,0);
        return get_position(bone);
    }

    bool IsPlayerVisible(void* player) {
        if (get_camera()) {
            Vector3 CameraPos         = get_position(get_transform(get_camera()));

            bool CanSeeHead           = !Linecast228(CameraPos,GetPlayerHead          (player),16384);
            bool CanSeeHip            = !Linecast228(CameraPos,GetPlayerHip           (player),16384);
            bool CanSeeLeftLowerArm   = !Linecast228(CameraPos,GetPlayerleftLowerArm  (player),16384);
            bool CanSeeRightLowerArm  = !Linecast228(CameraPos,GetPlayerrightLowerArm (player),16384);
            bool CanSeeLeftLowerLeg   = !Linecast228(CameraPos,GetPlayerleftLowerLeg  (player),16384);
            bool CanSeeRightLowerLeg  = !Linecast228(CameraPos,GetPlayerrightLowerLeg (player),16384);

            return
            CanSeeHead            ||
            CanSeeHip             ||
            CanSeeLeftLowerArm    ||
            CanSeeRightLowerArm   ||
            CanSeeLeftLowerLeg    ||
            CanSeeRightLowerLeg    ;
        }
        return false;
    }
}
