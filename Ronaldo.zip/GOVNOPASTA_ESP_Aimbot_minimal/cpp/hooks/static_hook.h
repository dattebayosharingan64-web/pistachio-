#ifndef STATIC_HOOK_H
#define STATIC_HOOK_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <mach-o/dyld.h>
#include "../../dobby_defines.h"

// Static Inline Hook Patch - создаёт пропатченный бинарник
NSString* StaticInlineHookPatch(const char* machoPath, uint64_t vaddr, char* patch);

// Static Inline Hook Function - устанавливает хук в runtime
void* StaticInlineHookFunction(const char* machoPath, uint64_t vaddr, void* replace);

// Active/Deactive Code Patch
BOOL ActiveCodePatch(const char* machoPath, uint64_t vaddr, char* patch);
BOOL DeactiveCodePatch(const char* machoPath, uint64_t vaddr, char* patch);

// Helper functions
void* find_module_by_path(const char* machoPath);
StaticInlineHookBlock* find_hook_block(void* base, uint64_t vaddr);

// Макрос для хуков (Dobby + Static Inline Hook)
#define HOOK(x, y, z) \
do { \
    NSString* result_##y = StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework", x, nullptr); \
    if (result_##y) { \
        NSLog(@"[HOOK] Patch result for %s: %@", #y, result_##y); \
        \
        /* Показываем алерт если это первый запуск (нужен патчинг) */ \
        if ([result_##y containsString:@"Патч создан"] || [result_##y containsString:@"переподпиши"]) { \
            dispatch_async(dispatch_get_main_queue(), ^{ \
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"🔧 Static Hook Patch" \
                    message:result_##y \
                    preferredStyle:UIAlertControllerStyleAlert]; \
                [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]]; \
                UIViewController* rootVC = [UIApplication sharedApplication].keyWindow.rootViewController; \
                [rootVC presentViewController:alert animated:YES completion:nil]; \
            }); \
        } \
        \
        void* result = StaticInlineHookFunction("Frameworks/UnityFramework.framework/UnityFramework", x, (void *) y); \
        NSLog(@"[HOOK] Function hook result for %s: %p", #y, result); \
        *(void **) (&z) = (void*) result; \
    } \
} while(0)

#endif // STATIC_HOOK_H
