#import "static_hook.h"
#import <Foundation/Foundation.h>
#import <mach-o/dyld.h>
#import <mach-o/fat.h>
#import <mach-o/loader.h>
#import <mach/vm_page_size.h>
#import <libgen.h>

#define STATIC_HOOK_CODEPAGE_SIZE PAGE_SIZE
#define STATIC_HOOK_DATAPAGE_SIZE PAGE_SIZE

#ifdef DEBUG
#define log(...) NSLog(__VA_ARGS__)
#else
#define log(...)
#endif

// Convert virtual address to relative virtual address
uint64_t va2rva(struct mach_header_64* header, uint64_t va)
{
    uint64_t rva = va;
    uint64_t header_vaddr = -1;
    
    struct load_command* lc = (struct load_command*)((UInt64)header + sizeof(*header));
    for (int i = 0; i < header->ncmds; i++) {
        if (lc->cmd == LC_SEGMENT_64) {
            struct segment_command_64 * seg = (struct segment_command_64 *)lc;
            if(seg->fileoff==0 && seg->filesize>0) {
                if(header_vaddr != -1) {
                    log(@"multi header mapping! %s", seg->segname);
                    return 0;
                }
                header_vaddr = seg->vmaddr;
            }
        }
        lc = (struct load_command *) ((char *)lc + lc->cmdsize);
    }
    
    if(header_vaddr != -1) {
        rva -= header_vaddr;
    }
    
    return rva;
}

// Convert RVA to data pointer
void* rva2data(struct mach_header_64* header, uint64_t rva)
{
    uint64_t header_vaddr = -1;
    struct load_command* lc = (struct load_command*)((UInt64)header + sizeof(*header));
    
    for (int i = 0; i < header->ncmds; i++) {
        if (lc->cmd == LC_SEGMENT_64) {
            struct segment_command_64 * seg = (struct segment_command_64 *)lc;
            if(seg->fileoff==0 && seg->filesize>0) {
                if(header_vaddr != -1) {
                    log(@"multi header mapping! %s", seg->segname);
                    return NULL;
                }
                header_vaddr = seg->vmaddr;
            }
        }
        lc = (struct load_command *) ((char *)lc + lc->cmdsize);
    }
    
    if(header_vaddr != -1) {
        rva += header_vaddr;
    }
    
    lc = (struct load_command*)((UInt64)header + sizeof(*header));
    for (int i = 0; i < header->ncmds; i++) {
        if (lc->cmd == LC_SEGMENT_64) {
            struct segment_command_64 * seg = (struct segment_command_64 *) lc;
            uint64_t seg_vmaddr_start = seg->vmaddr;
            uint64_t seg_vmaddr_end   = seg_vmaddr_start + seg->vmsize;
            
            if ((uint64_t)rva >= seg_vmaddr_start && (uint64_t)rva < seg_vmaddr_end) {
                uint64_t offset = (uint64_t)rva - seg_vmaddr_start;
                if (offset > seg->filesize) {
                    return NULL;
                }
                return (void*)((uint64_t)header + seg->fileoff + offset);
            }
        }
        lc = (struct load_command *) ((char *)lc + lc->cmdsize);
    }
    
    return NULL;
}

// Load mach-o data from file
NSMutableData* load_macho_data(NSString* path)
{
    NSMutableData* macho = [NSMutableData dataWithContentsOfFile:path];
    if(!macho) return nil;
    
    UInt32 magic = *(uint32_t*)macho.mutableBytes;
    
    if(magic==FAT_CIGAM) {
        struct fat_header* fathdr = (struct fat_header*)macho.mutableBytes;
        struct fat_arch* archdr = (struct fat_arch*)((UInt64)fathdr + sizeof(*fathdr));
        
        if(NXSwapLong(fathdr->nfat_arch) != 1) {
            log(@"macho has too many arch!");
            return nil;
        }
        
        if(NXSwapLong(archdr->cputype) != CPU_TYPE_ARM64 || archdr->cpusubtype!=0) {
            log(@"macho arch not support!");
            return nil;
        }
        
        macho = [NSMutableData dataWithData:
                 [macho subdataWithRange:NSMakeRange(NXSwapLong(archdr->offset), NXSwapLong(archdr->size))]];
        
    } else if(magic==FAT_CIGAM_64) {
        struct fat_header* fathdr = (struct fat_header*)macho.mutableBytes;
        struct fat_arch_64* archdr = (struct fat_arch_64*)((UInt64)fathdr + sizeof(*fathdr));
        
        if(NXSwapLong(fathdr->nfat_arch) != 1) {
            log(@"macho has too many arch!");
            return nil;
        }
        
        if(NXSwapLong(archdr->cputype) != CPU_TYPE_ARM64 || archdr->cpusubtype!=0) {
            log(@"macho arch not support!");
            return nil;
        }
        
        macho = [NSMutableData dataWithData:
                 [macho subdataWithRange:NSMakeRange(NXSwapLong(archdr->offset), NXSwapLong(archdr->size))]];
        
    } else if(magic != MH_MAGIC_64) {
        log(@"macho arch not support!");
        return nil;
    }
    
    return macho;
}

// Add hook sections to mach-o
NSMutableData* add_hook_section(NSMutableData* macho)
{
    struct mach_header_64* header = (struct mach_header_64*)macho.mutableBytes;
    
    uint64_t vm_end = 0;
    uint64_t min_section_offset = 0;
    struct segment_command_64* linkedit_seg = NULL;
    
    struct load_command* lc = (struct load_command*)((UInt64)header + sizeof(*header));
    for (int i = 0; i < header->ncmds; i++) {
        if (lc->cmd == LC_SEGMENT_64) {
            struct segment_command_64 * seg = (struct segment_command_64 *) lc;
            
            if(strcmp(seg->segname,SEG_LINKEDIT)==0)
                linkedit_seg = seg;
            else if(seg->vmsize && vm_end<(seg->vmaddr+seg->vmsize))
                vm_end = seg->vmaddr+seg->vmsize;
            
            struct section_64* sec = (struct section_64*)((uint64_t)seg+sizeof(*seg));
            for(int j=0; j<seg->nsects; j++) {
                if(min_section_offset < sec[j].offset)
                    min_section_offset = sec[j].offset;
            }
        }
        lc = (struct load_command *) ((char *)lc + lc->cmdsize);
    }
    
    if(!min_section_offset || !vm_end || !linkedit_seg) {
        log(@"cannot parse macho file!");
        return nil;
    }
    
    NSRange linkedit_range = NSMakeRange(linkedit_seg->fileoff, linkedit_seg->filesize);
    NSData* linkedit_data = [macho subdataWithRange:linkedit_range];
    [macho replaceBytesInRange:linkedit_range withBytes:nil length:0];
    
    struct segment_command_64 text_seg = {
        .cmd = LC_SEGMENT_64,
        .cmdsize=sizeof(struct segment_command_64)+sizeof(struct section_64),
        .segname = {"__HOOK_TEXT"},
        .vmaddr = vm_end,
        .vmsize = STATIC_HOOK_CODEPAGE_SIZE,
        .fileoff = macho.length,
        .filesize = STATIC_HOOK_CODEPAGE_SIZE,
        .maxprot = VM_PROT_READ|VM_PROT_EXECUTE,
        .initprot = VM_PROT_READ|VM_PROT_EXECUTE,
        .nsects = 1,
        .flags = 0
    };
    
    struct section_64 text_sec;
    strncpy(text_sec.sectname, "__hook_text", 16);
    strncpy(text_sec.segname, "__HOOK_TEXT", 16);
    text_sec.addr = text_seg.vmaddr;
    text_sec.size = text_seg.vmsize;
    text_sec.offset = (uint32_t)text_seg.fileoff;
    text_sec.align = 0;
    text_sec.reloff = 0;
    text_sec.nreloc = 0;
    text_sec.flags = S_ATTR_PURE_INSTRUCTIONS|S_ATTR_SOME_INSTRUCTIONS;
    text_sec.reserved1 = 0;
    text_sec.reserved2 = 0;
    text_sec.reserved3 = 0;
    
    struct segment_command_64 data_seg = {
        .cmd = LC_SEGMENT_64,
        .cmdsize=sizeof(struct segment_command_64)+sizeof(struct section_64),
        .segname = {"__HOOK_DATA"},
        .vmaddr = text_seg.vmaddr+text_seg.vmsize,
        .vmsize = STATIC_HOOK_DATAPAGE_SIZE,
        .fileoff = text_seg.fileoff+text_seg.filesize,
        .filesize = STATIC_HOOK_DATAPAGE_SIZE,
        .maxprot = VM_PROT_READ|VM_PROT_WRITE,
        .initprot = VM_PROT_READ|VM_PROT_WRITE,
        .nsects = 1,
        .flags = 0
    };
    
    struct section_64 data_sec;
    strncpy(data_sec.sectname, "__hook_data", 16);
    strncpy(data_sec.segname, "__HOOK_DATA", 16);
    data_sec.addr = data_seg.vmaddr;
    data_sec.size = data_seg.vmsize;
    data_sec.offset = (uint32_t)data_seg.fileoff;
    data_sec.align = 0;
    data_sec.reloff = 0;
    data_sec.nreloc = 0;
    data_sec.flags = 0;
    data_sec.reserved1 = 0;
    data_sec.reserved2 = 0;
    data_sec.reserved3 = 0;
    
    uint64_t linkedit_cmd_offset = (uint64_t)linkedit_seg - ((uint64_t)header+sizeof(*header));
    unsigned char* cmds = (unsigned char*)malloc(header->sizeofcmds);
    memcpy(cmds, (unsigned char*)header+sizeof(*header), header->sizeofcmds);
    unsigned char* patch = (unsigned char*)header +sizeof(*header) + linkedit_cmd_offset;
    
    memcpy(patch, &text_seg, sizeof(text_seg));
    patch += sizeof(text_seg);
    memcpy(patch, &text_sec, sizeof(text_sec));
    patch += sizeof(text_sec);
    memcpy(patch, &data_seg, sizeof(data_seg));
    patch += sizeof(data_seg);
    memcpy(patch, &data_sec, sizeof(data_sec));
    patch += sizeof(data_sec);
    
    memcpy(patch, cmds+linkedit_cmd_offset, header->sizeofcmds-linkedit_cmd_offset);
    
    linkedit_seg = (struct segment_command_64*)patch;
    
    header->ncmds += 2;
    header->sizeofcmds += text_seg.cmdsize + data_seg.cmdsize;
    
    linkedit_seg->fileoff = macho.length+text_seg.filesize+data_seg.filesize;
    linkedit_seg->vmaddr = vm_end+text_seg.vmsize+data_seg.vmsize;
    
    // Fix load commands
    struct load_command *load_cmd = (struct load_command *)((uint64_t)header + sizeof(*header));
    for (int i = 0; i < header->ncmds; i++, load_cmd = (struct load_command *)((uint64_t)load_cmd + load_cmd->cmdsize)) {
        uint64_t fixoffset = text_seg.filesize+data_seg.filesize;
        
        switch (load_cmd->cmd) {
            case LC_DYLD_INFO:
            case LC_DYLD_INFO_ONLY: {
                struct dyld_info_command *tmp = (struct dyld_info_command *)load_cmd;
                tmp->rebase_off += fixoffset;
                tmp->bind_off += fixoffset;
                if (tmp->weak_bind_off) tmp->weak_bind_off += fixoffset;
                if (tmp->lazy_bind_off) tmp->lazy_bind_off += fixoffset;
                if (tmp->export_off) tmp->export_off += fixoffset;
            } break;
                
            case LC_SYMTAB: {
                struct symtab_command *tmp = (struct symtab_command *)load_cmd;
                if (tmp->symoff) tmp->symoff += fixoffset;
                if (tmp->stroff) tmp->stroff += fixoffset;
            } break;
                
            case LC_DYSYMTAB: {
                struct dysymtab_command *tmp = (struct dysymtab_command *)load_cmd;
                if (tmp->tocoff) tmp->tocoff += fixoffset;
                if (tmp->modtaboff) tmp->modtaboff += fixoffset;
                if (tmp->extrefsymoff) tmp->extrefsymoff += fixoffset;
                if (tmp->indirectsymoff) tmp->indirectsymoff += fixoffset;
                if (tmp->extreloff) tmp->extreloff += fixoffset;
                if (tmp->locreloff) tmp->locreloff += fixoffset;
            } break;
                
            case LC_FUNCTION_STARTS:
            case LC_DATA_IN_CODE:
            case LC_CODE_SIGNATURE:
            case LC_SEGMENT_SPLIT_INFO:
            case LC_DYLIB_CODE_SIGN_DRS:
            case LC_LINKER_OPTIMIZATION_HINT:
            case LC_DYLD_EXPORTS_TRIE:
            case LC_DYLD_CHAINED_FIXUPS: {
                struct linkedit_data_command *tmp = (struct linkedit_data_command *)load_cmd;
                if (tmp->dataoff) tmp->dataoff += fixoffset;
            } break;
        }
    }
    
    if(min_section_offset < (sizeof(struct mach_header_64)+header->sizeofcmds)) {
        log(@"macho header has no enough space!");
        return nil;
    }
    
    unsigned char* codepage = (unsigned char*)malloc(text_seg.vmsize);
    memset(codepage, 0xFF, text_seg.vmsize);
    [macho appendBytes:codepage length:text_seg.vmsize];
    free(codepage);
    
    unsigned char* datapage = (unsigned char*)malloc(data_seg.vmsize);
    memset(datapage, 0, data_seg.vmsize);
    [macho appendBytes:datapage length:data_seg.vmsize];
    free(datapage);
    
    [macho appendData:linkedit_data];
    free(cmds);
    
    return macho;
}

uint64_t calc_patch_hash(uint64_t vaddr, char* patch)
{
    if(!patch) return 0;
    return [[[NSString stringWithUTF8String:patch] lowercaseString] hash] ^ vaddr;
}

// Main patching function
NSString* StaticInlineHookPatch(const char* machoPath, uint64_t vaddr, char* patch)
{
    static NSMutableDictionary* gStaticInlineHookMachO = [[NSMutableDictionary alloc] init];
    
    NSString* path = [NSBundle.mainBundle.bundlePath stringByAppendingPathComponent:[NSString stringWithUTF8String:machoPath]];
    NSString* newPath = gStaticInlineHookMachO[path];
    
    NSMutableData* macho=nil;

    if(newPath) {
        macho = load_macho_data(newPath);
        if(!macho) {
            return [NSString stringWithFormat:@"[HOOK] Не могу найти пропатченный файл:\nDocuments/static-inline-hook/%s", machoPath];
        }
    } else {
        macho = load_macho_data(path);
        if(!macho) {
            return [NSString stringWithFormat:@"[HOOK] Не могу прочитать файл:\n.app/%s", machoPath];
        }
    }
    
    uint32_t cryptid = 0;
    struct mach_header_64* header = NULL;
    struct segment_command_64* text_seg = NULL;
    struct segment_command_64* data_seg = NULL;
    
    while(true) {
        header = (struct mach_header_64*)macho.mutableBytes;
        
        struct load_command* lc = (struct load_command*)((UInt64)header + sizeof(*header));
        for (int i = 0; i < header->ncmds; i++) {
            if (lc->cmd == LC_SEGMENT_64) {
                struct segment_command_64 * seg = (struct segment_command_64 *) lc;
                if(strcmp(seg->segname,"__HOOK_TEXT")==0)
                    text_seg = seg;
                if(strcmp(seg->segname,"__HOOK_DATA")==0)
                    data_seg = seg;
            }
            if(lc->cmd == LC_ENCRYPTION_INFO_64) {
                struct encryption_info_command_64* info = (struct encryption_info_command_64*)lc;
                if(cryptid==0) cryptid = info->cryptid;
            }
            lc = (struct load_command *) ((char *)lc + lc->cmdsize);
        }
        
        if(text_seg && data_seg) {
            break;
        }
        
        macho = add_hook_section(macho);
        if(!macho) {
            return @"[HOOK] Ошибка add_hook_section!";
        }
    }
    
    if(cryptid != 0) {
        return @"[HOOK] Приложение зашифровано! Нужен decrypted IPA!";
    }
    
    if(!text_seg || !data_seg) {
        return @"[HOOK] Не могу распарсить machO файл!";
    }
    
    uint64_t funcRVA = vaddr & ~(4-1);
    void *funcData = rva2data(header, funcRVA);
    
    if(!funcData) {
        return @"[HOOK] Неверный оффсет!";
    }
    
    uint64_t targetRVA = va2rva(header, text_seg->vmaddr);
    void* targetData = rva2data(header, targetRVA);
    uint64_t InstrumentBridgeRVA = targetRVA;
    
    uint64_t dataRVA = va2rva(header, data_seg->vmaddr);
    void* dataData = rva2data(header, dataRVA);
    
    StaticInlineHookBlock* hookBlock = (StaticInlineHookBlock*)dataData;
    StaticInlineHookBlock* hookBlockRVA = NULL;
    
    for(int i=0; i<STATIC_HOOK_CODEPAGE_SIZE/sizeof(StaticInlineHookBlock); i++) {
        if(hookBlock[i].hook_vaddr==funcRVA) {
            if(newPath) {
                return @"[HOOK] Оффсет уже пропатчен! Замените файл из Documents/static-inline-hook/ в IPA и переподпишите!";
            }
            return @"[HOOK] Оффсет уже пропатчен!";
        }
        
        if(hookBlock[i].hook_vaddr==0) {
            hookBlock = &hookBlock[i];
            hookBlockRVA = (StaticInlineHookBlock*)(dataRVA + i*sizeof(StaticInlineHookBlock));
            
            if(i == 0) {
                int codesize = dobby_create_instrument_bridge(targetData);
                targetRVA += codesize;
                *(uint64_t*)&targetData += codesize;
            } else {
                StaticInlineHookBlock* lastBlock = hookBlock - 1;
                targetRVA = lastBlock->code_vaddr + lastBlock->code_size;
                targetData = rva2data(header, targetRVA);
            }
            break;
        }
    }
    
    if(!hookBlockRVA) {
        return @"[HOOK] Лимит хуков исчерпан!";
    }
    
    if(!dobby_static_inline_hook(hookBlock, hookBlockRVA, funcRVA, funcData, targetRVA, targetData,
                                 InstrumentBridgeRVA, NULL, 0)) {
        return @"[HOOK] Не могу пропатчить оффсет!";
    }
    
    NSString* savePath = [NSString stringWithFormat:@"%@/Documents/static-inline-hook/%s", NSHomeDirectory(), machoPath];
    [NSFileManager.defaultManager createDirectoryAtPath:[NSString stringWithUTF8String:dirname((char*)savePath.UTF8String)] 
                                withIntermediateDirectories:YES attributes:nil error:nil];
    
    if(![macho writeToFile:savePath atomically:NO]) {
        return @"[HOOK] Не могу записать файл!";
    }
    
    gStaticInlineHookMachO[path] = savePath;
    return [NSString stringWithFormat:@"[HOOK] ✅ Патч создан!\n\nПропатченный файл сохранён в:\nDocuments/static-inline-hook/%s\n\n📋 ЧТО ДЕЛАТЬ ДАЛЬШЕ:\n1. Извлеки файл через iTunes/Finder\n2. Замени в IPA: Payload/Game.app/%s\n3. Переподпиши через Sideloadly/ESign\n4. Установи и запусти!", machoPath, machoPath];
}

// Find module by path
void* find_module_by_path(const char* machoPath)
{
    NSString* path = [NSBundle.mainBundle.bundlePath stringByAppendingPathComponent:[NSString stringWithUTF8String:machoPath]];
    
    for(int i=0; i< _dyld_image_count(); i++) {
        const char* fpath = _dyld_get_image_name(i);
        void* baseaddr = (void*)_dyld_get_image_header(i);
        
        if([path isEqualToString:[NSString stringWithUTF8String:fpath]])
            return baseaddr;
    }
    
    return NULL;
}

// Find hook block
StaticInlineHookBlock* find_hook_block(void* base, uint64_t vaddr)
{
    struct segment_command_64* text_seg = NULL;
    struct segment_command_64* data_seg = NULL;
    struct mach_header_64* header = (struct mach_header_64*)base;
    
    struct load_command* lc = (struct load_command*)((UInt64)header + sizeof(*header));
    for (int i = 0; i < header->ncmds; i++) {
        if (lc->cmd == LC_SEGMENT_64) {
            struct segment_command_64 * seg = (struct segment_command_64 *) lc;
            if(strcmp(seg->segname,"__HOOK_TEXT")==0)
                text_seg = seg;
            if(strcmp(seg->segname,"__HOOK_DATA")==0)
                data_seg = seg;
        }
        lc = (struct load_command *) ((char *)lc + lc->cmdsize);
    }
    
    if(!text_seg || !data_seg) {
        return NULL;
    }
    
    StaticInlineHookBlock* hookBlock = (StaticInlineHookBlock*)((uint64_t)header + va2rva(header, data_seg->vmaddr));
    for(int i=0; i<STATIC_HOOK_CODEPAGE_SIZE/sizeof(StaticInlineHookBlock); i++) {
        if(hookBlock[i].hook_vaddr == (uint64_t)vaddr) {
            return &hookBlock[i];
        }
    }
    
    return NULL;
}

// Hook function in runtime
void* StaticInlineHookFunction(const char* machoPath, uint64_t vaddr, void* replace)
{
    void* base = find_module_by_path(machoPath);
    if(!base) {
        NSLog(@"[HOOK] Cannot find module!");
        return NULL;
    }
    
    StaticInlineHookBlock* hookBlock = find_hook_block(base, vaddr);
    if(!hookBlock) {
        NSLog(@"[HOOK] Cannot find hook block for offset 0x%llX!", vaddr);
        return NULL;
    }
    
    hookBlock->target_replace = replace;
    return (void*)((uint64_t)base + hookBlock->original_vaddr);
}

// Active code patch
BOOL ActiveCodePatch(const char* machoPath, uint64_t vaddr, char* patch)
{
    void* base = find_module_by_path(machoPath);
    if(!base) {
        NSLog(@"[HOOK] %p cannot find module!", (void *)vaddr);
        return NO;
    }
    
    StaticInlineHookBlock* hookBlock = find_hook_block(base, vaddr&~3);
    if(!hookBlock) {
        NSLog(@"[HOOK] %p cannot find hook block!", (void *)vaddr);
        return NO;
    }
    
    if(hookBlock->patch_hash != calc_patch_hash(vaddr, patch)) {
        NSLog(@"[HOOK] %p code patch bytes changed!", (void *)vaddr);
        return NO;
    }
    
    hookBlock->target_replace = (void*)((uint64_t)base + hookBlock->patched_vaddr);
    return YES;
}

// Deactive code patch
BOOL DeactiveCodePatch(const char* machoPath, uint64_t vaddr, char* patch)
{
    void* base = find_module_by_path(machoPath);
    if(!base) {
        NSLog(@"[HOOK] %p cannot find module!", (void *)vaddr);
        return NO;
    }
    
    StaticInlineHookBlock* hookBlock = find_hook_block(base, vaddr&~3);
    if(!hookBlock) {
        NSLog(@"[HOOK] %p cannot find hook block!", (void *)vaddr);
        return NO;
    }
    
    if(hookBlock->patch_hash != calc_patch_hash(vaddr, patch)) {
        NSLog(@"[HOOK] %p code patch bytes changed!", (void *)vaddr);
        return NO;
    }
    
    hookBlock->target_replace = NULL;
    return YES;
}
