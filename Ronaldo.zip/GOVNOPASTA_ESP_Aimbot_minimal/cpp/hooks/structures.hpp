#ifndef STRUCTURES_HPP
#define STRUCTURES_HPP

#include <cstdint>
#include <string>
#include <cmath>

#define SMALL_FLOAT 0.0000000001
#define Rad2Deg (180.0f / M_PI)
#define Deg2Rad (M_PI / 180.0f)

// Forward declaration
struct Quaternion;

// Структура Vector3
struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
    
    // Operators
    Vector3 operator-(const Vector3& other) const {
        return Vector3(x - other.x, y - other.y, z - other.z);
    }
    
    Vector3 operator+(const Vector3& other) const {
        return Vector3(x + other.x, y + other.y, z + other.z);
    }
    
    Vector3 operator*(float scalar) const {
        return Vector3(x * scalar, y * scalar, z * scalar);
    }
    
    Vector3 operator/(float scalar) const {
        return Vector3(x / scalar, y / scalar, z / scalar);
    }
    
    // Static methods
    static float Dot(const Vector3& a, const Vector3& b) {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }
    
    static Vector3 Cross(const Vector3& a, const Vector3& b) {
        return Vector3(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x
        );
    }
    
    static float Magnitude(const Vector3& v) {
        return sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
    }
    
    static Vector3 Normalize(const Vector3& v) {
        float mag = Magnitude(v);
        if (mag < SMALL_FLOAT) return Vector3(0, 0, 0);
        return v / mag;
    }
    
    static float Angle(const Vector3& from, const Vector3& to) {
        float mag = Magnitude(from) * Magnitude(to);
        if (mag < SMALL_FLOAT) return 0.0f;
        float v = Dot(from, to) / mag;
        v = fmaxf(v, -1.0f);
        v = fminf(v, 1.0f);
        return acosf(v) * Rad2Deg;
    }
    
    static Vector3 Lerp(const Vector3& a, const Vector3& b, float t) {
        return Vector3(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t
        );
    }
    
    // Instance methods
    Vector3 Normalize() const {
        return Normalize(*this);
    }
    
    float Magnitude() const {
        return Magnitude(*this);
    }
};

// Структура Quaternion
struct Quaternion {
    float x, y, z, w;
    
    Quaternion() : x(0), y(0), z(0), w(1) {}
    Quaternion(float _x, float _y, float _z, float _w) : x(_x), y(_y), z(_z), w(_w) {}
    
    // LookRotation - создает кватернион, который смотрит в направлении forward
    static Quaternion LookRotation(const Vector3& forward) {
        return LookRotation(forward, Vector3(0, 1, 0));
    }
    
    static Quaternion LookRotation(const Vector3& forward, const Vector3& upwards) {
        Vector3 f = Vector3::Normalize(forward);
        Vector3 u = Vector3::Normalize(upwards);
        
        if (Vector3::Magnitude(f) < SMALL_FLOAT || Vector3::Magnitude(u) < SMALL_FLOAT)
            return Quaternion(0, 0, 0, 1);
        
        if (1.0f - fabsf(Vector3::Dot(f, u)) < SMALL_FLOAT)
            return Quaternion(0, 0, 0, 1);
        
        Vector3 right = Vector3::Normalize(Vector3::Cross(u, f));
        Vector3 up = Vector3::Cross(f, right);
        
        Quaternion quaternion;
        float radicand = right.x + up.y + f.z;
        
        if (radicand > 0) {
            quaternion.w = sqrtf(1.0f + radicand) * 0.5f;
            float recip = 1.0f / (4.0f * quaternion.w);
            quaternion.x = (up.z - f.y) * recip;
            quaternion.y = (f.x - right.z) * recip;
            quaternion.z = (right.y - up.x) * recip;
        }
        else if (right.x >= up.y && right.x >= f.z) {
            quaternion.x = sqrtf(1.0f + right.x - up.y - f.z) * 0.5f;
            float recip = 1.0f / (4.0f * quaternion.x);
            quaternion.w = (up.z - f.y) * recip;
            quaternion.z = (f.x + right.z) * recip;
            quaternion.y = (right.y + up.x) * recip;
        }
        else if (up.y > f.z) {
            quaternion.y = sqrtf(1.0f - right.x + up.y - f.z) * 0.5f;
            float recip = 1.0f / (4.0f * quaternion.y);
            quaternion.z = (up.z + f.y) * recip;
            quaternion.w = (f.x - right.z) * recip;
            quaternion.x = (right.y + up.x) * recip;
        }
        else {
            quaternion.z = sqrtf(1.0f - right.x - up.y + f.z) * 0.5f;
            float recip = 1.0f / (4.0f * quaternion.z);
            quaternion.y = (up.z + f.y) * recip;
            quaternion.x = (f.x + right.z) * recip;
            quaternion.w = (right.y - up.x) * recip;
        }
        
        return quaternion;
    }
    
    static Quaternion Normalize(const Quaternion& q) {
        float norm = sqrtf(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
        if (norm < SMALL_FLOAT) return Quaternion(0, 0, 0, 1);
        return Quaternion(q.x / norm, q.y / norm, q.z / norm, q.w / norm);
    }
};

// Структура Vector2
struct Vector2 {
    float x, y;
    Vector2() : x(0), y(0) {}
    Vector2(float _x, float _y) : x(_x), y(_y) {}
};

// Структура для списка объектов Unity
template<typename T>
struct monoList {
    void* unk0;
    void* unk1;
    void* items;
    int count;
    int version;
};

// Структура для массива Unity
template<typename T>
struct monoArray {
    void* klass;
    void* monitor;
    void* bounds;
    int max_length;
    void* vector[1];
    
    int getLength() {
        return max_length;
    }
    
    T getPointer() {
        return (T)vector;
    }
};

// Структура для Unity строки
struct monoString {
    void* klass;
    void* monitor;
    int length;
    char chars[1];
    
    char* getChars() {
        return chars;
    }
    
    std::string toString() {
        if (length <= 0) return "";
        
        try {
            // Unity использует UTF-16LE (Little Endian)
            std::string result;
            result.reserve(length);
            
            for (int i = 0; i < length; i++) {
                // Читаем 2 байта как char16_t
                char16_t wchar = reinterpret_cast<char16_t*>(chars)[i];
                
                // Конвертируем в ASCII (для кириллицы будет ?)
                if (wchar < 128) {
                    result += static_cast<char>(wchar);
                } else if (wchar >= 0x0410 && wchar <= 0x044F) {
                    // Кириллица - транслитерация не делаем, просто ?
                    result += '?';
                } else {
                    result += '?';
                }
            }
            
            return result;
        } catch (...) {
            return "";
        }
    }
};


#endif // STRUCTURES_HPP
