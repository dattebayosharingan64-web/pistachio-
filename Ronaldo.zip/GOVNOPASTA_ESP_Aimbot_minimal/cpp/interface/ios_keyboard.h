#pragma once

#import <UIKit/UIKit.h>
#include <string>
#include <functional>

namespace iOSKeyboard {
    using KeyboardCallback = std::function<void(const std::string&)>;

    void show(const char* placeholder, const char* initial_text, KeyboardCallback callback);
    bool is_active();
}
