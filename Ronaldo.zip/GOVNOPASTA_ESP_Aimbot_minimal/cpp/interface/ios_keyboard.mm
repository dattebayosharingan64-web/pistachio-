#import "ios_keyboard.h"

@interface KeyboardViewController : UIViewController <UITextFieldDelegate>
@property (nonatomic, strong) UITextField* textField;
@property (nonatomic, copy) void(^completionBlock)(NSString*);
@end

@implementation KeyboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.5];

    UIView* container = [[UIView alloc] initWithFrame:CGRectMake(20, 100, self.view.bounds.size.width - 40, 120)];
    container.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.95];
    container.layer.cornerRadius = 10;
    [self.view addSubview:container];

    self.textField = [[UITextField alloc] initWithFrame:CGRectMake(10, 10, container.bounds.size.width - 20, 40)];
    self.textField.backgroundColor = [UIColor colorWithWhite:0.2 alpha:1.0];
    self.textField.textColor = [UIColor whiteColor];
    self.textField.layer.cornerRadius = 5;
    self.textField.delegate = self;
    self.textField.returnKeyType = UIReturnKeyDone;
    self.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.textField.autocorrectionType = UITextAutocorrectionTypeNo;

    UIView* paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.textField.leftView = paddingView;
    self.textField.leftViewMode = UITextFieldViewModeAlways;

    [container addSubview:self.textField];

    UIButton* doneButton = [UIButton buttonWithType:UIButtonTypeSystem];
    doneButton.frame = CGRectMake(10, 60, container.bounds.size.width - 20, 44);
    [doneButton setTitle:@"Done" forState:UIControlStateNormal];
    [doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    doneButton.backgroundColor = [UIColor colorWithRed:0.0 green:0.5 blue:1.0 alpha:1.0];
    doneButton.layer.cornerRadius = 5;
    [doneButton addTarget:self action:@selector(donePressed) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:doneButton];

    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backgroundTapped)];
    [self.view addGestureRecognizer:tapGesture];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.textField becomeFirstResponder];
}

- (void)donePressed {
    if (self.completionBlock) {
        self.completionBlock(self.textField.text ?: @"");
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)backgroundTapped {
    [self donePressed];
}

- (BOOL)textFieldShouldReturn:(UITextField*)textField {
    [self donePressed];
    return YES;
}

@end

namespace iOSKeyboard {
    static KeyboardViewController* g_keyboardVC = nil;

    void show(const char* placeholder, const char* initial_text, KeyboardCallback callback) {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIWindow* window = [UIApplication sharedApplication].windows.firstObject;
            UIViewController* rootVC = window.rootViewController;
            if (!rootVC) return;

            g_keyboardVC = [[KeyboardViewController alloc] init];
            g_keyboardVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
            g_keyboardVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;

            g_keyboardVC.completionBlock = ^(NSString* text) {
                if (callback) {
                    callback(std::string([text UTF8String]));
                }
                g_keyboardVC = nil;
            };

            [rootVC presentViewController:g_keyboardVC animated:YES completion:^{
                if (placeholder) {
                    g_keyboardVC.textField.placeholder = [NSString stringWithUTF8String:placeholder];
                }
                if (initial_text) {
                    g_keyboardVC.textField.text = [NSString stringWithUTF8String:initial_text];
                }
            }];
        });
    }

    bool is_active() {
        return g_keyboardVC != nil;
    }
}
