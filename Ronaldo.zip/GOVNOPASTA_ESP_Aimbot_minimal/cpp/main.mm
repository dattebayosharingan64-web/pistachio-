#include "includes.hpp"
#import "auth/AuthManager.h"
#import "config/MenuConfig.h"
#import "interface/ios_keyboard.h"

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView



static bool MenDeal = true;

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    
    // Красивый серый стиль
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 5.0f;
    style.FrameRounding = 3.0f;
    style.ScrollbarRounding = 3.0f;
    style.GrabRounding = 2.0f;
    style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style.FramePadding = ImVec2(8, 4);
    style.ItemSpacing = ImVec2(8, 6);
    
    ImVec4* colors = style.Colors;
    colors[ImGuiCol_WindowBg] = ImVec4(0.13f, 0.14f, 0.15f, 0.95f);
    colors[ImGuiCol_Border] = ImVec4(0.25f, 0.25f, 0.27f, 0.50f);
    colors[ImGuiCol_FrameBg] = ImVec4(0.20f, 0.21f, 0.22f, 1.00f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.25f, 0.26f, 0.27f, 1.00f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.29f, 0.30f, 1.00f);
    colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.10f, 0.11f, 1.00f);
    colors[ImGuiCol_TitleBgActive] = ImVec4(0.15f, 0.15f, 0.16f, 1.00f);
    colors[ImGuiCol_CheckMark] = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
    colors[ImGuiCol_SliderGrab] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    colors[ImGuiCol_SliderGrabActive] = ImVec4(0.70f, 0.70f, 0.70f, 1.00f);
    colors[ImGuiCol_Button] = ImVec4(0.25f, 0.25f, 0.27f, 1.00f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.35f, 0.35f, 0.37f, 1.00f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.40f, 0.40f, 0.42f, 1.00f);
    colors[ImGuiCol_Header] = ImVec4(0.25f, 0.25f, 0.27f, 1.00f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(0.35f, 0.35f, 0.37f, 1.00f);
    colors[ImGuiCol_HeaderActive] = ImVec4(0.40f, 0.40f, 0.42f, 1.00f);
    colors[ImGuiCol_Separator] = ImVec4(0.25f, 0.25f, 0.27f, 0.50f);
    colors[ImGuiCol_Tab] = ImVec4(0.20f, 0.20f, 0.22f, 1.00f);
    colors[ImGuiCol_TabHovered] = ImVec4(0.35f, 0.35f, 0.37f, 1.00f);
    colors[ImGuiCol_TabActive] = ImVec4(0.28f, 0.28f, 0.30f, 1.00f);
    colors[ImGuiCol_Text] = ImVec4(0.90f, 0.90f, 0.90f, 1.00f);
    colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    
    ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF((void*)Honkai_compressed_data, Honkai_compressed_size, 45.0f, NULL, io.Fonts->GetGlyphRangesDefault());
    ImGui_ImplMetal_Init(_device);

    if ([ImGuiDrawView hasSettingsInSlot:0]) {
        [ImGuiDrawView loadSettingsFromSlot:0];
    }

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
 [super viewDidLoad];
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
        selector:@selector(onAuthSessionRevoked:)
        name:AuthSessionRevokedNotification
        object:nil];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self checkAuthorization];
    });
}

- (void)onAuthSessionRevoked:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        AuthManager *auth = [AuthManager sharedInstance];
        UIViewController *rootVC = [UIApplication sharedApplication].windows.firstObject.rootViewController;
        [auth showAccessRevokedAlert:rootVC];
    });
}

- (void)checkAuthorization {
    AuthManager *authManager = [AuthManager sharedInstance];
    
    if (![authManager isAuthorized]) {
        // Показываем алерт авторизации
        UIViewController *rootVC = [UIApplication sharedApplication].windows.firstObject.rootViewController;
        if ([authManager isAccountBanned]) {
            [authManager showBannedAlert:rootVC completion:^(BOOL success) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    exit(0);
                });
            }];
            return;
        }

        [authManager showAuthAlert:rootVC completion:^(BOOL success) {
            if (!success) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    exit(0);
                });
            } else {
                NSLog(@"[AUTH] Authorization successful!");
            }
        }];
    } else {
        NSLog(@"[AUTH] Already authorized");
    }
}

#pragma mark - Interaction
- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 120);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];

    static bool show_s0_active = false;
        
    [self.view setUserInteractionEnabled:(MenDeal ? YES : NO)];

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {

            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:@"imgui base"];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();
            
            ImFont* font = ImGui::GetFont();
            font->Scale = 15.f / font->FontSize;
            
            CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 360) / 2;
            CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 300) / 2;
            
            ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(400, 300), ImGuiCond_FirstUseEver); 
            
            if (MenDeal)
            {
                ImGui::SetNextWindowSize(ImVec2(500, 400), ImGuiCond_FirstUseEver);
                ImGui::Begin("@La1trexx Standleo", &MenDeal, ImGuiWindowFlags_NoCollapse);
                
                // Вкладки
                if (ImGui::BeginTabBar("MainTabs", ImGuiTabBarFlags_None)) {
                    
                    // Вкладка ESP
                    if (ImGui::BeginTabItem("ESP")) {
                        ImGui::Spacing();
                        ImGui::Checkbox("Enable ESP", &ESP::settings.enabled);
                        
                        ImGui::Separator();
                        ImGui::Text("Visual Elements:");
                        ImGui::Checkbox("Box", &ESP::settings.showBox);
                        if (ESP::settings.showBox) {
                            ImGui::SameLine();
                            const char* boxTypes[] = { "Full", "Corner" };
                            ImGui::SetNextItemWidth(100);
                            ImGui::Combo("##BoxType", &ESP::settings.boxType, boxTypes, IM_ARRAYSIZE(boxTypes));
                        }
                        ImGui::Checkbox("Skeleton", &ESP::settings.showSkeleton);
                        ImGui::Checkbox("Snapline", &ESP::settings.showLine);
                        ImGui::Checkbox("Distance", &ESP::settings.showDistance);
                        ImGui::Checkbox("Name", &ESP::settings.showName);
                        ImGui::Checkbox("Health Bar", &ESP::settings.showHealth);
                        ImGui::Checkbox("Armor Bar", &ESP::settings.showArmor);
                        ImGui::Checkbox("Offscreen Arrows", &ESP::settings.showOffscreen);
                        
                        ImGui::Separator();
                        ImGui::Text("Filters:");
                        ImGui::Checkbox("Team Check", &ESP::settings.teamCheck);
                        ImGui::SliderFloat("Max Distance", &ESP::settings.maxDistance, 50.0f, 500.0f, "%.0fm");
                        
                        if (ESP::settings.showLine) {
                            ImGui::Separator();
                            ImGui::Text("Snapline:");
                            const char* lineTypes[] = { "Top", "Center", "Bottom" };
                            ImGui::Combo("Position", &ESP::settings.lineType, lineTypes, IM_ARRAYSIZE(lineTypes));
                            ImGui::SliderInt("Width", &ESP::settings.lineWidth, 1, 5);
                        }
                        
                        ImGui::EndTabItem();
                    }
                    
                    // Вкладка Colors
                    if (ImGui::BeginTabItem("Colors")) {
                        ImGui::Spacing();
                        ImGui::Text("Box Colors:");
                        ImGui::ColorEdit4("Visible##Box", (float*)&ESP::settings.boxVisibleColor);
                        ImGui::ColorEdit4("Invisible##Box", (float*)&ESP::settings.boxInvisibleColor);
                        
                        ImGui::Separator();
                        ImGui::Text("Skeleton Colors:");
                        ImGui::ColorEdit4("Visible##Skel", (float*)&ESP::settings.skelVisibleColor);
                        ImGui::ColorEdit4("Invisible##Skel", (float*)&ESP::settings.skelInvisibleColor);
                        
                        ImGui::Separator();
                        ImGui::Text("Health Bar:");
                        ImGui::ColorEdit4("Low HP", (float*)&ESP::settings.healthMinColor);
                        ImGui::ColorEdit4("Full HP", (float*)&ESP::settings.healthMaxColor);
                        
                        ImGui::Separator();
                        ImGui::Text("Armor Bar:");
                        ImGui::ColorEdit4("Low Armor", (float*)&ESP::settings.armorMinColor);
                        ImGui::ColorEdit4("Full Armor", (float*)&ESP::settings.armorMaxColor);
                        
                        ImGui::EndTabItem();
                    }
                    
                    // Вкладка Aimbot
                    if (ImGui::BeginTabItem("Aimbot")) {
                        ImGui::Spacing();
                        
                        // Aimbot
                        ImGui::Checkbox("Aimbot", &hooks::Aimbot.Enable);
                        if (hooks::Aimbot.Enable) {
                            ImGui::Indent();
                            ImGui::Checkbox("Check Visibility##Aim", &hooks::Aimbot.VisibleCheck);
                            ImGui::Checkbox("Ignore Team", &hooks::Aimbot.TeamCheck);
                            ImGui::Checkbox("FOV Limit", &hooks::Aimbot.FOVCheck);
                            
                            if (hooks::Aimbot.FOVCheck) {
                                ImGui::SliderInt("FOV##Aim", &hooks::Aimbot.FOV, 10, 180);
                                
                                ImVec4 aimbotFovColor = ImVec4(hooks::Aimbot.ColorR, hooks::Aimbot.ColorG, 
                                                               hooks::Aimbot.ColorB, hooks::Aimbot.ColorA);
                                if (ImGui::ColorEdit4("FOV Color##Aim", (float*)&aimbotFovColor, ImGuiColorEditFlags_NoInputs)) {
                                    hooks::Aimbot.ColorR = aimbotFovColor.x;
                                    hooks::Aimbot.ColorG = aimbotFovColor.y;
                                    hooks::Aimbot.ColorB = aimbotFovColor.z;
                                    hooks::Aimbot.ColorA = aimbotFovColor.w;
                                }
                            }
                            
                            ImGui::SliderFloat("Smoothing", &hooks::Aimbot.Smooth, 0.0f, 1.0f, "%.2f");
                            
                            const char* aimBones[] = { "Head", "Chest", "Body", "Legs", "Hands" };
                            ImGui::Combo("Target##Aim", &hooks::Aimbot.TargetBone, aimBones, IM_ARRAYSIZE(aimBones));
                            
                            if (hooks::Aimbot.TargetPlayer) {
                                ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "Locked On");
                            }
                            ImGui::Unindent();
                        }
                        
                        ImGui::EndTabItem();
                    }
                    
                    // Config
                    if (ImGui::BeginTabItem("Config")) {
                        ImGui::Spacing();
                        ImGui::Text("Configuration");
                        ImGui::Separator();
                        ImGui::Spacing();

                        static int selected_slot = 0;

                        const int slot_count = [ImGuiDrawView configSlotCount];
                        static char combo_labels[5][48];
                        const char* combo_items[5];
                        for (int i = 0; i < slot_count; i++) {
                            NSString* dn = [ImGuiDrawView displayNameForSlot:i];
                            snprintf(combo_labels[i], sizeof(combo_labels[i]), "%s", [dn UTF8String]);
                            combo_items[i] = combo_labels[i];
                        }

                        ImGui::SetNextItemWidth(220);
                        ImGui::Combo("Profile", &selected_slot, combo_items, slot_count);

                        NSString* currentName = [ImGuiDrawView displayNameForSlot:selected_slot];
                        ImGui::Text("Name: %s", [currentName UTF8String]);

                        if (ImGui::Button("Rename", ImVec2(100, 28))) {
                            std::string initial = std::string([currentName UTF8String]);
                            int slot = selected_slot;
                            iOSKeyboard::show("Profile name", initial.c_str(), [slot](const std::string& text) {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    NSString* ns = [NSString stringWithUTF8String:text.c_str()];
                                    [ImGuiDrawView setDisplayNameForSlot:slot name:ns];
                                });
                            });
                        }

                        ImGui::Spacing();
                        bool hasCfg = [ImGuiDrawView hasSettingsInSlot:selected_slot];
                        if (hasCfg) {
                            ImGui::TextColored(ImVec4(0.3f, 1.0f, 0.4f, 1.0f), "Status: saved");
                        } else {
                            ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Status: empty");
                        }

                        ImGui::Spacing();
                        if (ImGui::Button("Save", ImVec2(100, 32))) {
                            [ImGuiDrawView saveSettingsToSlot:selected_slot];
                        }
                        ImGui::SameLine();
                        if (ImGui::Button("Load", ImVec2(100, 32))) {
                            [ImGuiDrawView loadSettingsFromSlot:selected_slot];
                        }
                        ImGui::SameLine();
                        if (ImGui::Button("Delete", ImVec2(100, 32))) {
                            [ImGuiDrawView deleteSettingsInSlot:selected_slot];
                        }

                        ImGui::Spacing();
                        ImGui::Separator();
                        ImGui::Spacing();
                        ImGui::BulletText("Slot 1 auto-loads on start");
                        ImGui::BulletText("Names stored in NSUserDefaults");

                        ImGui::EndTabItem();
                    }

                    // Вкладка Debug
                    if (ImGui::BeginTabItem("Debug")) {
                        ImGui::Spacing();
                        ImGui::Text("Unity Base: 0x%llX", (unsigned long long)base->unity_base);
                        ImGui::Text("Camera: %p", hooks::get_camera ? hooks::get_camera() : nullptr);
                        ImGui::Text("Screen: %dx%d", 
                            hooks::get_width ? hooks::get_width() : 0,
                            hooks::get_height ? hooks::get_height() : 0);
                        ImGui::Text("Local Player: %p", hooks::localPlayer);
                        ImGui::Text("Players Count: %zu", hooks::players.size());
                        
                        ImGui::Separator();
                        ImGui::EndTabItem();
                    }
                    
                    ImGui::EndTabBar();
                }
                
                ImGui::End();
            }
            
            // Рисуем ESP поверх всего
            ESP::DrawESP();


            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
          
            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
        }

        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

void start_thread()
{
    try {
        NSLog(@"[INIT] start_thread called");
        
        // Ждём 5 секунд чтобы Unity точно загрузился
        sleep(5);
        
        NSLog(@"[INIT] Creating c_base...");
        base = new c_base();
        NSLog(@"[INIT] c_base created, unity_base: %p", (void*)base->unity_base);
        
        // Проверяем что Unity загружен
        if (base->unity_base == 0) {
            NSLog(@"[INIT] ERROR: Unity not loaded! Aborting hook installation.");
            return;
        }
        
        NSLog(@"[INIT] Installing hooks...");
        hooks::initialize();
        NSLog(@"[INIT] Hooks installed");
        
        NSLog(@"[INIT] Initializing ESP...");
        ESP::Initialize();
        NSLog(@"[INIT] ESP initialized");
        
        NSLog(@"[INIT] Initialization complete!");
    } catch (const std::exception& e) {
        NSLog(@"[INIT] EXCEPTION in start_thread: %s", e.what());
    } catch (...) {
        NSLog(@"[INIT] UNKNOWN EXCEPTION in start_thread");
    }
}

void __attribute__((constructor)) initialize() {
    try {
        NSLog(@"[INIT] Constructor called, starting thread...");
        std::thread(start_thread).detach();
    } catch (...) {
        NSLog(@"[INIT] EXCEPTION in constructor");
    }
}


@end

