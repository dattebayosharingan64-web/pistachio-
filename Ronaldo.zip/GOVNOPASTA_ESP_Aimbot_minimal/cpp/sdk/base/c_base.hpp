//
// Created by Максим on 22.06.2025.
//

#ifndef C_BASE_HPP
#define C_BASE_HPP

#import <dlfcn.h>
#include <string.h>
#include <unistd.h>
#include <cstdint>

#include "../framework/c_framework.hpp"

class c_base {
public:
    uintptr_t unity_base;
    uintptr_t il2cpp_icall(const char* name);
    c_base();
};

inline c_base* base;

#endif //C_BASE_HPP
