//
// Created by Максим on 22.06.2025.
//

#include "c_framework.hpp"

c_framework *c_framework::find(const char *libraryName)
{

    c_framework* framework = nullptr;

    auto _dyld_image_count = (int(*)())dlsym(RTLD_DEFAULT, "_dyld_image_count");
    auto _dyld_get_image_name = (const char*(*)(int))dlsym(RTLD_DEFAULT, "_dyld_get_image_name");
    auto _dyld_get_image_header = (const mach_header*(*)(int))dlsym(RTLD_DEFAULT, "_dyld_get_image_header");

    if (!_dyld_image_count || !_dyld_get_image_name || !_dyld_get_image_header) {
        return 0;
    }

    int imageCount = _dyld_image_count();

    for (int i = 0; i < imageCount; i++) {
        const char *name = _dyld_get_image_name(i);
        const mach_header *header = _dyld_get_image_header(i);

        if (strstr(name, libraryName) != nullptr) {
            framework = new c_framework(name, reinterpret_cast<uintptr_t>(header));
            return framework;
        }
    }

    return framework;
}

