//
// Created by Максим on 22.06.2025.
//

#ifndef C_FRAMEWORK_H
#define C_FRAMEWORK_H

#import <mach-o/dyld.h>
#import <dlfcn.h>
#include <string.h>
#include <unistd.h>
#include <cstdint>

class c_framework {
public:
    const char* name;
    uintptr_t addr;
    c_framework(const char* n, uintptr_t a)
    {
        name = n;
        addr = a;
    }
    static c_framework* find(const char* name);
};

#endif //C_FRAMEWORK_H
