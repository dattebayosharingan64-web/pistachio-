#ifndef AUTHMANAGER_H
#define AUTHMANAGER_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

FOUNDATION_EXPORT NSString *const AuthSessionRevokedNotification;

@interface AuthManager : NSObject

+ (instancetype)sharedInstance;

- (BOOL)isAuthorized;
- (void)showAuthAlert:(UIViewController *)viewController completion:(void (^)(BOOL success))completion;
- (NSString *)getDeviceHWID;
- (NSDictionary *)getDeviceInfo;
- (void)saveKey:(NSString *)key;
- (NSString *)getSavedKey;
- (void)clearAuth;
- (void)startHeartbeat;
- (void)stopHeartbeat;
- (NSString *)lastAuthErrorMessage;
- (BOOL)isAccountBanned;
- (void)showAccessRevokedAlert:(UIViewController *)viewController;
- (void)showBannedAlert:(UIViewController *)viewController completion:(void (^)(BOOL success))completion;

@end

#endif
