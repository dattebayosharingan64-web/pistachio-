#ifndef BX_LOG_H
#define BX_LOG_H

#import <Foundation/Foundation.h>

#define BXLogInfo(fmt, ...)  NSLog(@"[BX] " fmt, ##__VA_ARGS__)
#define BXLogWarn(fmt, ...)  NSLog(@"[BX][WARN] " fmt, ##__VA_ARGS__)
#define BXLogError(fmt, ...) NSLog(@"[BX][ERR] " fmt, ##__VA_ARGS__)

#endif
