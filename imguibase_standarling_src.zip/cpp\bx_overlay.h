#ifndef BX_OVERLAY_H
#define BX_OVERLAY_H

#import <MetalKit/MetalKit.h>

extern MTKView * _Nullable g_overlayView;

#endif
