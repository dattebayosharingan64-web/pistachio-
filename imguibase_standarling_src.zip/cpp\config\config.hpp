#ifndef CONFIG_HPP
#define CONFIG_HPP

#include <string>

namespace Config {

    constexpr int kSlotCount = 5;

    void Init();

    bool SlotHasData(int slot);
    std::string SlotName(int slot);
    void SetSlotName(int slot, const std::string& name);

    void Save(int slot);
    void Load(int slot);
    void Delete(int slot);
    void ResetDefaults();
}

#endif // CONFIG_HPP
