#include "config.hpp"
#include "../esp/esp.h"
#include "../hooks/aimbot.hpp"
#include "../hooks/silentaim.hpp"
#include "../misc/misc.hpp"
#include "../esp/bullet_tracers.hpp"
#include "../features/visual_misc.hpp"
#include "../features/hit_logs.hpp"

#import <Foundation/Foundation.h>

namespace {

    NSString* SlotKey(int slot) {
        return [NSString stringWithFormat:@"lb_cfg_%d", slot];
    }

    NSString* NameKey(int slot) {
        return [NSString stringWithFormat:@"lb_cfg_name_%d", slot];
    }

    NSArray* ColorToArray(const ImVec4& c) {
        return @[ @(c.x), @(c.y), @(c.z), @(c.w) ];
    }

    ImVec4 ArrayToColor(id obj, const ImVec4& def) {
        if (![obj isKindOfClass:[NSArray class]]) return def;
        NSArray* a = (NSArray*)obj;
        if (a.count < 4) return def;
        return ImVec4([a[0] floatValue], [a[1] floatValue],
                      [a[2] floatValue], [a[3] floatValue]);
    }

    float NumF(NSDictionary* d, NSString* k, float def) {
        id v = d[k];
        return v ? [v floatValue] : def;
    }

    int NumI(NSDictionary* d, NSString* k, int def) {
        id v = d[k];
        return v ? [v intValue] : def;
    }

    bool NumB(NSDictionary* d, NSString* k, bool def) {
        id v = d[k];
        return v ? [v boolValue] : def;
    }
}

namespace Config {

    void Init() {
        // Nothing to prepare: settings live in NSUserDefaults.
    }

    bool SlotHasData(int slot) {
        if (slot < 0 || slot >= kSlotCount) return false;
        return [[NSUserDefaults standardUserDefaults] objectForKey:SlotKey(slot)] != nil;
    }

    std::string SlotName(int slot) {
        if (slot < 0 || slot >= kSlotCount) return "Slot";
        NSString* n = [[NSUserDefaults standardUserDefaults] stringForKey:NameKey(slot)];
        if (n.length == 0) {
            n = [NSString stringWithFormat:@"Slot %d", slot + 1];
        }
        return std::string(n.UTF8String ?: "");
    }

    void SetSlotName(int slot, const std::string& name) {
        if (slot < 0 || slot >= kSlotCount) return;
        NSUserDefaults* ud = [NSUserDefaults standardUserDefaults];
        [ud setObject:[NSString stringWithUTF8String:name.c_str()] forKey:NameKey(slot)];
        [ud synchronize];
    }

    void Save(int slot) {
        if (slot < 0 || slot >= kSlotCount) return;

        ESP::Settings& s = ESP::settings;
        hooks::AimbotSettings& a = hooks::Aimbot;

        NSDictionary* d = @{
            @"esp_enabled":      @(s.enabled),
            @"esp_box":          @(s.showBox),
            @"esp_line":         @(s.showLine),
            @"esp_distance":     @(s.showDistance),
            @"esp_health":       @(s.showHealth),
            @"esp_armor":        @(s.showArmor),
            @"esp_name":         @(s.showName),
            @"esp_skeleton":     @(s.showSkeleton),
            @"esp_outline":      @(s.showOutline),
            @"esp_offscreen":    @(s.showOffscreen),
            @"esp_team":         @(s.teamCheck),
            @"esp_box_type":     @(s.boxType),
            @"esp_max_dist":     @(s.maxDistance),
            @"esp_line_type":    @(s.lineType),
            @"esp_line_width":   @(s.lineWidth),
            @"esp_box_vis":      ColorToArray(s.boxVisibleColor),
            @"esp_box_inv":      ColorToArray(s.boxInvisibleColor),
            @"esp_skel_vis":     ColorToArray(s.skelVisibleColor),
            @"esp_skel_inv":     ColorToArray(s.skelInvisibleColor),
            @"esp_hp_min":       ColorToArray(s.healthMinColor),
            @"esp_hp_max":       ColorToArray(s.healthMaxColor),
            @"esp_armor_min":    ColorToArray(s.armorMinColor),
            @"esp_armor_max":    ColorToArray(s.armorMaxColor),

            @"aim_enable":       @(a.Enable),
            @"aim_visible":      @(a.VisibleCheck),
            @"aim_team":         @(a.TeamCheck),
            @"aim_fov_check":    @(a.FOVCheck),
            @"aim_fov":          @(a.FOV),
            @"aim_smooth":       @(a.Smooth),
            @"aim_bone":         @(a.TargetBone),
            @"aim_color":        @[ @(a.ColorR), @(a.ColorG), @(a.ColorB), @(a.ColorA) ],

            @"silent_enable":    @(hooks::Silent.Enable),
            @"silent_visible":   @(hooks::Silent.VisibleCheck),
            @"silent_fov_check": @(hooks::Silent.FOVCheck),
            @"silent_tp":        @(hooks::Silent.UseBulletTP),
            @"silent_fov":       @(hooks::Silent.FOV),
            @"silent_bone":      @(hooks::Silent.AimBone),

            @"misc_fov_enable":  @(Misc::settings.fovEnabled),
            @"misc_fov_value":   @(Misc::settings.fovValue),
            @"misc_fakelag":     @(Misc::settings.fakeLagEnabled),
            @"misc_fakelag_lock":    @(Misc::settings.fakeLagLock),
            @"misc_fakelag_release": @(Misc::settings.fakeLagRelease),
            @"misc_speed":       @(Misc::settings.speedEnabled),
            @"misc_speed_mult":  @(Misc::settings.speedMultiplier),
            @"misc_inf_ammo":    @(Misc::settings.infinityAmmoEnabled),
            @"misc_wallshot":    @(Misc::settings.wallshotEnabled),
            @"misc_norecoil":    @(Misc::settings.noRecoilEnabled),

            @"bhop_enable":      @(Misc::settings.bhopEnabled),
            @"bhop_force":       @(Misc::settings.bhopJumpForceMult),
            @"bhop_speed":       @(Misc::settings.bhopSpeedMult),
            @"bhop_air":         @(Misc::settings.bhopAirSpeedMult),
            @"fr_enable":        @(Misc::settings.fireRateEnabled),
            @"fr_mult":          @(Misc::settings.fireRateMult),

            @"tr_enable":        @(tracers::enabled),
            @"tr_thickness":     @(tracers::lineThickness),
            @"tr_fade":          @(tracers::fadeSpeed),
            @"tr_color":         ColorToArray(tracers::color),

            @"vm_hitmarkers":    @(VisualMisc::show_hit_markers),
            @"vm_dmgnumbers":    @(VisualMisc::show_damage_indicators),
            @"vm_crossinfo":     @(VisualMisc::show_crosshair_info),
            @"hl_enabled":       @(HitLogs::enabled)
        };

        NSUserDefaults* ud = [NSUserDefaults standardUserDefaults];
        [ud setObject:d forKey:SlotKey(slot)];
        [ud synchronize];
    }

    void Load(int slot) {
        if (slot < 0 || slot >= kSlotCount) return;

        NSDictionary* d = [[NSUserDefaults standardUserDefaults] dictionaryForKey:SlotKey(slot)];
        if (!d) return;

        ESP::Settings& s = ESP::settings;
        hooks::AimbotSettings& a = hooks::Aimbot;

        s.enabled       = NumB(d, @"esp_enabled", s.enabled);
        s.showBox       = NumB(d, @"esp_box", s.showBox);
        s.showLine      = NumB(d, @"esp_line", s.showLine);
        s.showDistance  = NumB(d, @"esp_distance", s.showDistance);
        s.showHealth    = NumB(d, @"esp_health", s.showHealth);
        s.showArmor     = NumB(d, @"esp_armor", s.showArmor);
        s.showName      = NumB(d, @"esp_name", s.showName);
        s.showSkeleton  = NumB(d, @"esp_skeleton", s.showSkeleton);
        s.showOutline   = NumB(d, @"esp_outline", s.showOutline);
        s.showOffscreen = NumB(d, @"esp_offscreen", s.showOffscreen);
        s.teamCheck     = NumB(d, @"esp_team", s.teamCheck);
        s.boxType       = NumI(d, @"esp_box_type", s.boxType);
        s.maxDistance   = NumF(d, @"esp_max_dist", s.maxDistance);
        s.lineType      = NumI(d, @"esp_line_type", s.lineType);
        s.lineWidth     = NumI(d, @"esp_line_width", s.lineWidth);

        s.boxVisibleColor   = ArrayToColor(d[@"esp_box_vis"], s.boxVisibleColor);
        s.boxInvisibleColor = ArrayToColor(d[@"esp_box_inv"], s.boxInvisibleColor);
        s.skelVisibleColor  = ArrayToColor(d[@"esp_skel_vis"], s.skelVisibleColor);
        s.skelInvisibleColor = ArrayToColor(d[@"esp_skel_inv"], s.skelInvisibleColor);
        s.healthMinColor    = ArrayToColor(d[@"esp_hp_min"], s.healthMinColor);
        s.healthMaxColor    = ArrayToColor(d[@"esp_hp_max"], s.healthMaxColor);
        s.armorMinColor     = ArrayToColor(d[@"esp_armor_min"], s.armorMinColor);
        s.armorMaxColor     = ArrayToColor(d[@"esp_armor_max"], s.armorMaxColor);

        a.Enable      = NumB(d, @"aim_enable", a.Enable);
        a.VisibleCheck = NumB(d, @"aim_visible", a.VisibleCheck);
        a.TeamCheck   = NumB(d, @"aim_team", a.TeamCheck);
        a.FOVCheck    = NumB(d, @"aim_fov_check", a.FOVCheck);
        a.FOV         = NumI(d, @"aim_fov", a.FOV);
        a.Smooth      = NumF(d, @"aim_smooth", a.Smooth);
        a.TargetBone  = NumI(d, @"aim_bone", a.TargetBone);

        NSArray* ac = d[@"aim_color"];
        if ([ac isKindOfClass:[NSArray class]] && ac.count >= 4) {
            a.ColorR = [ac[0] floatValue];
            a.ColorG = [ac[1] floatValue];
            a.ColorB = [ac[2] floatValue];
            a.ColorA = [ac[3] floatValue];
        }

        hooks::Silent.Enable      = NumB(d, @"silent_enable", hooks::Silent.Enable);
        hooks::Silent.VisibleCheck = NumB(d, @"silent_visible", hooks::Silent.VisibleCheck);
        hooks::Silent.FOVCheck    = NumB(d, @"silent_fov_check", hooks::Silent.FOVCheck);
        hooks::Silent.UseBulletTP = NumB(d, @"silent_tp", hooks::Silent.UseBulletTP);
        hooks::Silent.FOV         = NumI(d, @"silent_fov", hooks::Silent.FOV);
        hooks::Silent.AimBone     = NumI(d, @"silent_bone", hooks::Silent.AimBone);

        Misc::settings.fovEnabled      = NumB(d, @"misc_fov_enable", Misc::settings.fovEnabled);
        Misc::settings.fovValue        = NumF(d, @"misc_fov_value", Misc::settings.fovValue);
        Misc::settings.fakeLagEnabled  = NumB(d, @"misc_fakelag", Misc::settings.fakeLagEnabled);
        Misc::settings.fakeLagLock     = NumF(d, @"misc_fakelag_lock", Misc::settings.fakeLagLock);
        Misc::settings.fakeLagRelease  = NumF(d, @"misc_fakelag_release", Misc::settings.fakeLagRelease);
        Misc::settings.speedEnabled    = NumB(d, @"misc_speed", Misc::settings.speedEnabled);
        Misc::settings.speedMultiplier = NumF(d, @"misc_speed_mult", Misc::settings.speedMultiplier);
        Misc::settings.infinityAmmoEnabled = NumB(d, @"misc_inf_ammo", Misc::settings.infinityAmmoEnabled);
        Misc::settings.wallshotEnabled = NumB(d, @"misc_wallshot", Misc::settings.wallshotEnabled);
        Misc::settings.noRecoilEnabled = NumB(d, @"misc_norecoil", Misc::settings.noRecoilEnabled);

        Misc::settings.bhopEnabled       = NumB(d, @"bhop_enable", Misc::settings.bhopEnabled);
        Misc::settings.bhopJumpForceMult = NumF(d, @"bhop_force", Misc::settings.bhopJumpForceMult);
        Misc::settings.bhopSpeedMult     = NumF(d, @"bhop_speed", Misc::settings.bhopSpeedMult);
        Misc::settings.bhopAirSpeedMult  = NumF(d, @"bhop_air", Misc::settings.bhopAirSpeedMult);
        Misc::settings.fireRateEnabled   = NumB(d, @"fr_enable", Misc::settings.fireRateEnabled);
        Misc::settings.fireRateMult      = NumF(d, @"fr_mult", Misc::settings.fireRateMult);

        tracers::enabled       = NumB(d, @"tr_enable", tracers::enabled);
        tracers::lineThickness = NumF(d, @"tr_thickness", tracers::lineThickness);
        tracers::fadeSpeed     = NumF(d, @"tr_fade", tracers::fadeSpeed);
        tracers::color         = ArrayToColor(d[@"tr_color"], tracers::color);

        VisualMisc::show_hit_markers      = NumB(d, @"vm_hitmarkers", VisualMisc::show_hit_markers);
        VisualMisc::show_damage_indicators = NumB(d, @"vm_dmgnumbers", VisualMisc::show_damage_indicators);
        VisualMisc::show_crosshair_info   = NumB(d, @"vm_crossinfo", VisualMisc::show_crosshair_info);
        HitLogs::enabled                  = NumB(d, @"hl_enabled", HitLogs::enabled);
    }

    void Delete(int slot) {
        if (slot < 0 || slot >= kSlotCount) return;
        NSUserDefaults* ud = [NSUserDefaults standardUserDefaults];
        [ud removeObjectForKey:SlotKey(slot)];
        [ud synchronize];
    }

    void ResetDefaults() {
        ESP::settings = ESP::Settings();

        hooks::AimbotSettings& a = hooks::Aimbot;
        a.Enable = false;
        a.VisibleCheck = true;
        a.TeamCheck = true;
        a.FOVCheck = true;
        a.FOV = 90;
        a.Smooth = 0.3f;
        a.TargetBone = 0;
        a.ColorR = 1.0f;
        a.ColorG = 0.5f;
        a.ColorB = 0.0f;
        a.ColorA = 1.0f;

        hooks::Silent.Enable = false;
        hooks::Silent.VisibleCheck = true;
        hooks::Silent.FOVCheck = true;
        hooks::Silent.UseBulletTP = true;
        hooks::Silent.FOV = 100;
        hooks::Silent.AimBone = 0;

        Misc::settings.fovEnabled = false;
        Misc::settings.fovValue = 90.0f;
        Misc::settings.fakeLagEnabled = false;
        Misc::settings.fakeLagLock = 0.5f;
        Misc::settings.fakeLagRelease = 0.5f;
        Misc::settings.speedEnabled = false;
        Misc::settings.speedMultiplier = 1.0f;
        Misc::settings.infinityAmmoEnabled = false;
        Misc::settings.wallshotEnabled = false;
        Misc::settings.noRecoilEnabled = false;

        Misc::settings.bhopEnabled = false;
        Misc::settings.bhopJumpForceMult = 1.2f;
        Misc::settings.bhopSpeedMult = 1.0f;
        Misc::settings.bhopAirSpeedMult = 1.0f;

        Misc::settings.fireRateEnabled = false;
        Misc::settings.fireRateMult = 3.0f;

        tracers::enabled = false;
        tracers::lineThickness = 2.0f;
        tracers::fadeSpeed = 3.0f;
        tracers::color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);

        VisualMisc::show_hit_markers = true;
        VisualMisc::show_damage_indicators = true;
        VisualMisc::show_crosshair_info = true;
        HitLogs::enabled = true;
    }
}
