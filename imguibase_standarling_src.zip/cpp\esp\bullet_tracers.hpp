#ifndef BULLET_TRACERS_HPP
#define BULLET_TRACERS_HPP

// Ported from wwzavoz (GOVNOPASTA V2) esp/bullet_tracers
// 0.20.2 result type: HKDNKEPCLPE - start Vector3 at +0x20, end Vector3 at +0x2C.

#include "../hooks/structures.hpp"
#include "../interface/rendering/imgui/imgui.h"
#include <vector>

namespace tracers {

    struct Tracer {
        Vector3 start;
        Vector3 end;
        float alpha;
        ImVec4 color;

        Tracer(Vector3 s, Vector3 e, ImVec4 c) : start(s), end(e), alpha(255.0f), color(c) {}
    };

    extern std::vector<Tracer> tracerList;

    // Настройки (свои, независимые от ESP)
    extern bool enabled;
    extern float fadeSpeed;      // альфа уменьшается на это значение каждый кадр
    extern float lineThickness;
    extern ImVec4 color;         // цвет трейсеров

    void AddTracer(Vector3 start, Vector3 end);
    void UpdateTracers();
    void RenderTracers();
}

#endif // BULLET_TRACERS_HPP
