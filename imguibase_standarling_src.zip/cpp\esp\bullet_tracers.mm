#include "bullet_tracers.hpp"
#include "../hooks/hooks.hpp"

namespace tracers {

    std::vector<Tracer> tracerList;

    bool enabled = false;
    float fadeSpeed = 3.0f;
    float lineThickness = 2.0f;
    ImVec4 color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);

    void AddTracer(Vector3 start, Vector3 end) {
        if (!enabled) return;
        if (start.x == 0.0f && start.y == 0.0f && start.z == 0.0f) return;
        if (end.x == 0.0f && end.y == 0.0f && end.z == 0.0f) return;
        tracerList.push_back(Tracer(start, end, color));
    }

    void UpdateTracers() {
        if (tracerList.empty()) return;

        for (int i = (int)tracerList.size() - 1; i >= 0; i--) {
            tracerList[i].alpha -= fadeSpeed;

            if (tracerList[i].alpha <= 0.0f) {
                tracerList.erase(tracerList.begin() + i);
            }
        }
    }

    void RenderTracers() {
        if (!enabled || tracerList.empty()) return;

        if (!hooks::get_camera || !hooks::get_camera()) return;

        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        if (!draw) return;

        for (const auto& tracer : tracerList) {
            ImVec2 startScreen = hooks::world2screen_i(tracer.start);
            ImVec2 endScreen = hooks::world2screen_i(tracer.end);

            const float w = ImGui::GetIO().DisplaySize.x;
            const float h = ImGui::GetIO().DisplaySize.y;
            bool startValid = startScreen.x > 0 && startScreen.x < w &&
                              startScreen.y > 0 && startScreen.y < h;
            bool endValid = endScreen.x > 0 && endScreen.x < w &&
                            endScreen.y > 0 && endScreen.y < h;

            if (startValid || endValid) {
                ImVec4 col = tracer.color;
                ImU32 c = IM_COL32(
                    (int)(col.x * 255.0f),
                    (int)(col.y * 255.0f),
                    (int)(col.z * 255.0f),
                    (int)tracer.alpha
                );
                draw->AddLine(startScreen, endScreen, c, lineThickness);
            }
        }
    }
}
