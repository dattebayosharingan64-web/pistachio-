#ifndef ESP_H
#define ESP_H

#include "../hooks/structures.hpp"
#include "../hooks/hooks.hpp"
#include "../interface/rendering/imgui/imgui.h"
#import <os/log.h>
#include <vector>

namespace ESP {
    
    // Настройки ESP - расширенная версия из antisocial
    struct Settings {
        bool enabled = true;
        bool showBox = true;
        bool showLine = true;
        bool showDistance = true;
        bool showHealth = true;
        bool showArmor = true;
        bool showName = true;
        bool showSkeleton = true;
        bool showOutline = true;
        bool showOffscreen = true;  // Новое: offscreen indicators из antisocial
        bool teamCheck = true;
        int boxType = 0; // 0 = full box, 1 = corner box
        float maxDistance = 200.0f;
        
        // Цвета
        ImVec4 boxVisibleColor;
        ImVec4 boxInvisibleColor;
        ImVec4 skelVisibleColor;
        ImVec4 skelInvisibleColor;
        ImVec4 healthMinColor;
        ImVec4 healthMaxColor;
        ImVec4 armorMinColor;
        ImVec4 armorMaxColor;
        
        int lineType = 0; // 0 = сверху, 1 = от центра, 2 = снизу
        int lineWidth = 1;
        
        Settings() {
            boxVisibleColor = ImVec4(0, 1, 0, 1);
            boxInvisibleColor = ImVec4(1, 0, 0, 1);
            skelVisibleColor = ImVec4(0, 1, 0, 1);
            skelInvisibleColor = ImVec4(1, 0, 0, 1);
            healthMinColor = ImVec4(1, 0, 0, 1);
            healthMaxColor = ImVec4(0, 1, 0, 1);
            armorMinColor = ImVec4(0.5f, 0.5f, 1, 1);
            armorMaxColor = ImVec4(0, 0.5f, 1, 1);
        }
    };
    
    extern Settings settings;
    
    // Функции
    void Initialize();
    void DrawESP();
    
    // World to Screen - правильная реализация
    ImVec2 WorldToScreen(Vector3 worldPos, bool& isValid);
    
    // Вспомогательные функции
    inline float lerp(float a, float b, float t) {
        return a + t * (b - a);
    }
    
    inline ImVec4 colorLerp(ImVec4 a, ImVec4 b, float t) {
        return ImVec4(
            a.x + t * (b.x - a.x),
            a.y + t * (b.y - a.y),
            a.z + t * (b.z - a.z),
            a.w + t * (b.w - a.w)
        );
    }
}

#endif // ESP_H
