#pragma once

// Ported from wwzavoz (GOVNOPASTA V2) features/hit_logs.
// "[hit] ..." lines near the center of the screen.

#include <string>

namespace HitLogs {
    extern bool enabled;

    void push(const std::string& message);
    void render();
}
