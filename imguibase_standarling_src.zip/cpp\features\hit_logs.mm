#import <Foundation/Foundation.h>
#import "hit_logs.hpp"
#import "../interface/rendering/imgui/imgui.h"
#include <algorithm>
#include <chrono>
#include <deque>

namespace HitLogs {

bool enabled = true;

namespace {
    struct LogEntry {
        std::string text;
        int64_t createdMs = 0;
        int animation = 0;
        int bgAnimation = 0;
        int animPos1 = 20;
        int animPos2 = 0;
    };

    std::deque<LogEntry> g_logs;

    int64_t nowMs() {
        using namespace std::chrono;
        return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
    }

    void drawOutlinedText(const ImVec2& pos, ImU32 color, const char* text) {
        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        if (!draw || !text)
            return;
        const ImU32 shadow = IM_COL32(0, 0, 0, (color >> IM_COL32_A_SHIFT) & 0xFF);
        draw->AddText(ImVec2(pos.x + 1, pos.y + 1), shadow, text);
        draw->AddText(pos, color, text);
    }
}

void push(const std::string& message) {
    if (message.empty())
        return;
    LogEntry entry;
    entry.text = message;
    entry.createdMs = nowMs();
    g_logs.push_back(std::move(entry));
    while (g_logs.size() > 16)
        g_logs.pop_front();
}

void render() {
    if (!enabled || g_logs.empty())
        return;

    ImGuiIO& io = ImGui::GetIO();
    const float screenW = io.DisplaySize.x;
    const float screenH = io.DisplaySize.y;
    const int logHeight = static_cast<int>(18.0f * io.FontGlobalScale);

    g_logs.erase(
        std::remove_if(g_logs.begin(), g_logs.end(),
                       [](const LogEntry& e) { return e.animPos2 >= 20 && e.bgAnimation <= 0; }),
        g_logs.end());

    int count = 0;
    for (auto& log : g_logs) {
        if (count > 15)
            break;

        if (log.animPos1 > 0)
            log.animPos1 -= 1;
        if (log.animPos1 > 0 && log.animation < 385)
            log.animation += 20;
        if (log.animPos1 > 0 && log.bgAnimation < 385)
            log.bgAnimation += 20;
        if (log.animPos1 == 0 && log.animation > 0)
            log.animation -= 1;
        if (log.animPos1 == 0 && log.bgAnimation > 0)
            log.bgAnimation -= 1;
        if (log.bgAnimation <= 60 && log.animPos2 < 600)
            log.animPos2 += 1;

        const std::string prefix = "[hit] ";
        const std::string full = prefix + log.text;
        const ImVec2 textSize = ImGui::CalcTextSize(full.c_str());
        const float y = screenH * 0.5f + 100.0f * io.FontGlobalScale + logHeight * count - log.animPos1 + log.animPos2;

        const ImU32 prefixColor = IM_COL32(255, 80, 80, log.animation);
        const ImU32 textColor = IM_COL32(255, 255, 255, log.animation);

        drawOutlinedText(ImVec2(screenW * 0.5f - textSize.x * 0.5f, y), prefixColor, prefix.c_str());
        const ImVec2 prefixSize = ImGui::CalcTextSize(prefix.c_str());
        drawOutlinedText(ImVec2(screenW * 0.5f - textSize.x * 0.5f + prefixSize.x, y), textColor, log.text.c_str());

        ++count;
    }
}

} // namespace HitLogs
