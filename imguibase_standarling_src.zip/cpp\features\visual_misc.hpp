#pragma once

// Ported from wwzavoz (GOVNOPASTA V2) features/visual_misc.
// Hit markers / damage numbers / hit feed are detected by per-frame health
// diffing of enemies (players_snapshot + GetPlayerHealth / GetPlayerTeam),
// because the WWZ PlayerHit hook class is not reachable in standarling 0.20.2.

#include <vector>
#include <string>
#include "../hooks/structures.hpp"

struct HitMarker {
    Vector3 position;
    int damage;
    int alpha;

    HitMarker() : position(), damage(0), alpha(255) {}
    HitMarker(Vector3 pos, int dmg) : position(pos), damage(dmg), alpha(255) {}
};

struct DamageIndicator {
    Vector2 screen_pos;
    int damage;
    float lifetime;
    float velocity_y;

    DamageIndicator() : screen_pos(), damage(0), lifetime(1.5f), velocity_y(-50.0f) {}
};

class VisualMisc {
public:
    // Hit markers (damage numbers at the hit position)
    static bool show_hit_markers;
    static std::vector<HitMarker> hit_markers;
    static void add_hit_marker(Vector3 pos, int damage);

    // Damage indicators - "-N" floating up from screen center (damage taken)
    static bool show_damage_indicators;
    static std::vector<DamageIndicator> damage_indicators;
    static void add_damage_indicator(int damage);

    // Crosshair info (left of screen center)
    static bool show_crosshair_info;

    // Render everything, call once per frame after NewFrame
    static void update(float delta_time);
    static void render();
};
