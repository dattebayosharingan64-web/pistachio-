#include "visual_misc.hpp"
#include "../hooks/hooks.hpp"
#include "../hooks/player.hpp"
#include "../esp/esp.h"
#include "hit_logs.hpp"
#include "../interface/rendering/imgui/imgui.h"

#include <unordered_map>
#include <cmath>

bool VisualMisc::show_hit_markers = true;
std::vector<HitMarker> VisualMisc::hit_markers;

bool VisualMisc::show_damage_indicators = true;
std::vector<DamageIndicator> VisualMisc::damage_indicators;

bool VisualMisc::show_crosshair_info = true;

namespace {

    // last known health per enemy PlayerController / local player
    std::unordered_map<void*, int> g_last_health;
    int g_last_local_health = -1;

    bool valid_ptr(uintptr_t p) {
        return p > 0x10000ULL;
    }

    std::string player_name(void* photon) {
        try {
            monoString* nm = hooks::GetNickName(photon);
            if (nm) return nm->toString();
        } catch (...) {
        }
        return "";
    }
}

void VisualMisc::add_hit_marker(Vector3 pos, int damage) {
    if (!show_hit_markers) return;
    hit_markers.push_back(HitMarker(pos, damage));
    if (hit_markers.size() > 64) {
        hit_markers.erase(hit_markers.begin());
    }
}

void VisualMisc::add_damage_indicator(int damage) {
    if (!show_damage_indicators) return;

    const float w = ImGui::GetIO().DisplaySize.x;
    const float h = ImGui::GetIO().DisplaySize.y;

    DamageIndicator indicator;
    indicator.screen_pos = {w * 0.5f, h * 0.5f};
    indicator.damage = damage;
    indicator.lifetime = 1.5f;
    indicator.velocity_y = -50.0f;

    damage_indicators.push_back(indicator);
    if (damage_indicators.size() > 16) {
        damage_indicators.erase(damage_indicators.begin());
    }
}

namespace {

    // Re-detects hits/kills by comparing enemy health between frames.
    void health_diff(float delta_time) {
        (void)delta_time;

        // --- local damage taken -> screen-center indicator ---
        if (VisualMisc::show_damage_indicators && hooks::localPlayer) {
            void* photon = hooks::get_photon(hooks::localPlayer);
            if (photon && hooks::GetPlayerHealth) {
                int hp = hooks::GetPlayerHealth(photon);
                if (g_last_local_health >= 0 && hp >= 0 &&
                    hp < g_last_local_health &&
                    g_last_local_health > 0) {
                    VisualMisc::add_damage_indicator(g_last_local_health - hp);
                }
                if (hp > 0) g_last_local_health = hp;
                else if (g_last_local_health > 0) g_last_local_health = hp;
            }
        }

        // --- enemy health diff -> hit markers + logs ---
        if (!hooks::GetPlayerHealth) return;

        const std::vector<void*> list = hooks::players_snapshot();

        for (void* player : list) {
            if (!player) continue;

            void* photon = hooks::get_photon(player);
            if (!photon) continue;

            if (hooks::GetPlayerTeam &&
                hooks::GetPlayerTeam(photon) == hooks::localTeam) continue;

            int hp = hooks::GetPlayerHealth(photon);
            if (hp < 0) continue;

            auto it = g_last_health.find(player);
            if (it == g_last_health.end()) {
                g_last_health[player] = hp;
                continue;
            }

            int last = it->second;
            if (hp < last && last > 0) {
                int dmg = last - hp;

                Vector3 head = Vector3(0, 0, 0);
                if (hooks::GetPlayerHead) head = hooks::GetPlayerHead(player);

                VisualMisc::add_hit_marker(head, dmg);

                if (hp == 0) {
                    std::string name = player_name(photon);
                    if (!name.empty())
                        HitLogs::push("Killed " + name + " [" + std::to_string(dmg) + " dmg]");
                } else {
                    std::string name = player_name(photon);
                    if (!name.empty())
                        HitLogs::push("Hit " + name + " for " + std::to_string(dmg));
                }
            }

            g_last_health[player] = hp;
        }

        // drop entries for players that left the match
        if (g_last_health.size() > list.size() + 64) {
            g_last_health.clear();
        }
        if (g_last_local_health > 0 && !hooks::localPlayer) {
            g_last_local_health = -1;
        }
    }
}

void VisualMisc::update(float delta_time) {
    if (show_hit_markers || show_damage_indicators ||
        hit_markers.size() || damage_indicators.size()) {
        health_diff(delta_time);
    }

    for (auto it = hit_markers.begin(); it != hit_markers.end();) {
        it->alpha -= 1;
        if (it->alpha <= 0) {
            it = hit_markers.erase(it);
        } else {
            ++it;
        }
    }

    for (auto it = damage_indicators.begin(); it != damage_indicators.end();) {
        it->lifetime -= delta_time;
        it->screen_pos.y += it->velocity_y * delta_time;
        if (it->lifetime <= 0) {
            it = damage_indicators.erase(it);
        } else {
            ++it;
        }
    }
}

void VisualMisc::render() {
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    if (show_hit_markers) {
        for (const auto& marker : hit_markers) {
            bool is_valid = false;
            ImVec2 screen = ESP::WorldToScreen(marker.position, is_valid);

            if (!is_valid) continue;

            std::string text = std::to_string(marker.damage);
            ImVec2 text_size = ImGui::CalcTextSize(text.c_str());

            float offset_x = screen.x - text_size.x * 0.5f;
            float offset_y = screen.y - text_size.y * 1.2f;

            draw->AddText(ImVec2(offset_x + 1, offset_y + 1),
                          IM_COL32(0, 0, 0, marker.alpha), text.c_str());
            draw->AddText(ImVec2(offset_x, offset_y),
                          IM_COL32(255, 255, 255, marker.alpha), text.c_str());
        }
    }

    if (show_damage_indicators) {
        for (const auto& indicator : damage_indicators) {
            std::string text = "-" + std::to_string(indicator.damage);
            ImVec2 text_size = ImGui::CalcTextSize(text.c_str());

            int alpha = (int)(255.0f * (indicator.lifetime / 1.5f));
            if (alpha < 0) alpha = 0;

            draw->AddText(ImVec2(indicator.screen_pos.x - text_size.x * 0.5f + 1,
                                 indicator.screen_pos.y + 1),
                          IM_COL32(0, 0, 0, alpha), text.c_str());
            draw->AddText(ImVec2(indicator.screen_pos.x - text_size.x * 0.5f,
                                 indicator.screen_pos.y),
                          IM_COL32(255, 50, 50, alpha), text.c_str());
        }
    }

    if (show_crosshair_info) {
        std::vector<void*> pl = hooks::players_snapshot();

        float y = ImGui::GetIO().DisplaySize.y * 0.5f;
        float x = 20.0f;

        auto text_line = [&](const std::string& line, ImU32 color) {
            draw->AddText(ImVec2(x + 1, y + 1), IM_COL32(0, 0, 0, 200), line.c_str());
            draw->AddText(ImVec2(x, y), color, line.c_str());
            y += ImGui::CalcTextSize(line.c_str()).y + 2.0f;
        };

        text_line("Players: " + std::to_string(pl.size()), IM_COL32(255, 255, 255, 255));

        void* local = hooks::localPlayer;
        if (local) {
            void* photon = hooks::get_photon(local);
            if (photon && hooks::GetPlayerHealth) {
                int hp = hooks::GetPlayerHealth(photon);
                if (hp >= 0) {
                    ImU32 hpColor = hp > 50 ? IM_COL32(80, 255, 80, 255)
                                            : IM_COL32(255, 80, 80, 255);
                    text_line("HP: " + std::to_string(hp), hpColor);
                }
            }
            if (photon) {
                std::string name = player_name(photon);
                if (!name.empty())
                    text_line("Nick: " + name, IM_COL32(200, 200, 200, 255));
            }
        }
    }
}
