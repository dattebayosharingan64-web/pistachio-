#include "aimbot.hpp"
#include "player.hpp"
#include "offsets.hpp"
#import <Foundation/Foundation.h>
#import <cmath>

namespace hooks {

    AimbotSettings Aimbot;

    Vector3 CalculateAimAngles(const Vector3& from, const Vector3& to) {
        Vector3 direction = to - from;
        Quaternion rotation = Quaternion::LookRotation(direction);

        float sqw = rotation.w * rotation.w;
        float sqx = rotation.x * rotation.x;
        float sqy = rotation.y * rotation.y;
        float sqz = rotation.z * rotation.z;
        float unit = sqx + sqy + sqz + sqw;
        float test = rotation.x * rotation.w - rotation.y * rotation.z;

        Vector3 angles;

        if (test > 0.4995f * unit) {
            angles.y = 2.0f * atan2f(rotation.y, rotation.x) * Rad2Deg;
            angles.x = 90.0f;
            angles.z = 0;
        }
        else if (test < -0.4995f * unit) {
            angles.y = -2.0f * atan2f(rotation.y, rotation.x) * Rad2Deg;
            angles.x = -90.0f;
            angles.z = 0;
        }
        else {
            angles.y = atan2f(2.0f * rotation.w * rotation.y + 2.0f * rotation.z * rotation.x,
                             1.0f - 2.0f * (rotation.x * rotation.x + rotation.y * rotation.y)) * Rad2Deg;
            angles.x = asinf(2.0f * (rotation.w * rotation.x - rotation.y * rotation.z)) * Rad2Deg;
            angles.z = atan2f(2.0f * rotation.w * rotation.z + 2.0f * rotation.x * rotation.y,
                             1.0f - 2.0f * (rotation.z * rotation.z + rotation.x * rotation.x)) * Rad2Deg;
        }

        if (angles.x >= 275.0f) angles.x -= 360.0f;
        if (angles.x <= -275.0f) angles.x += 360.0f;

        return angles;
    }

    float CalculateAngleToBone(void* bone, const Vector3& viewPosition) {
        if (!bone || !get_camera()) return 999.0f;

        Vector3 bonePos = get_position(bone);
        void* camTransform = get_transform(get_camera());
        Vector3 camForward = get_forward(camTransform);

        Vector3 direction = (bonePos - viewPosition).Normalize();
        return Vector3::Angle(direction, camForward);
    }

    void* SelectTargetBone(void* player) {
        if (!player) return nullptr;

        void* bipedMap = GetBipedMap(player);
        if (!bipedMap) return nullptr;

        switch (Aimbot.TargetBone) {
            case 0: // Head
                return get_bone(bipedMap, kBoneHead);
            case 1: // Spine2 (upper chest)
                return get_bone(bipedMap, kBoneSpine2);
            case 2: // Spine1 (lower chest)
                return get_bone(bipedMap, kBoneSpine1);
            case 3: // Hip
                return get_bone(bipedMap, kBoneHip);
            case 4: // Hands
            {
                void* leftHand = get_bone(bipedMap, kBoneLHand);
                void* rightHand = get_bone(bipedMap, kBoneRHand);
                if (!leftHand) return rightHand;
                if (!rightHand) return leftHand;
                return leftHand;
            }
            default:
                return get_bone(bipedMap, kBoneHead);
        }
    }

    void ApplyAimAngles(const Vector3& targetAngles, float smooth) {
        if (!localPlayer) return;

        void* aimController = *(void**)((uintptr_t)localPlayer + kOffAimController);
        if (!aimController) return;

        void* aimingData = *(void**)((uintptr_t)aimController + 0x90);
        if (!aimingData) return;

        if (smooth > 0.0f) {
            Vector3* curAimAng = (Vector3*)((uintptr_t)aimingData + 0x18);
            Vector3* curEulerAng = (Vector3*)((uintptr_t)aimingData + 0x24);

            *curAimAng = Vector3::Lerp(*curAimAng, targetAngles, smooth);
            *curEulerAng = Vector3::Lerp(*curEulerAng, targetAngles, smooth);
        } else {
            *(Vector3*)((uintptr_t)aimingData + 0x18) = targetAngles;
            *(Vector3*)((uintptr_t)aimingData + 0x24) = targetAngles;
        }
    }

    void ExecuteAimbot() {
        if (!Aimbot.Enable || !localPlayer || !get_camera()) {
            Aimbot.TargetPlayer = nullptr;
            Aimbot.TargetBonePtr = nullptr;
            Aimbot.CanAim = false;
            return;
        }

        void* camTransform = get_transform(get_camera());
        if (!camTransform) return;
        Vector3 viewPosition = get_position(camTransform);

        void* bestTarget = nullptr;
        void* bestBone = nullptr;
        float bestAngle = 999.0f;

        const std::vector<void*> players_copy = players_snapshot();

        for (void* player : players_copy) {
            if (!player) continue;

            void* photon = get_photon(player);
            if (!photon) continue;

            if (Aimbot.TeamCheck) {
                int playerTeam = GetPlayerTeam(photon);
                if (playerTeam == localTeam) continue;
            }

            int health = GetPlayerHealth(photon);
            if (health <= 0) continue;

            void* bone = SelectTargetBone(player);
            if (!bone) continue;

            if (Aimbot.VisibleCheck) {
                if (!IsPlayerVisible(player)) continue;
            }

            float angle = CalculateAngleToBone(bone, viewPosition);
            if (Aimbot.FOVCheck) {
                float fovLimit = (float)Aimbot.FOV / 10.0f;
                if (angle > fovLimit) continue;
            }

            if (angle < bestAngle) {
                bestAngle = angle;
                bestTarget = player;
                bestBone = bone;
            }
        }

        if (bestTarget && bestBone) {
            Aimbot.TargetPlayer = bestTarget;
            Aimbot.TargetBonePtr = bestBone;
            Aimbot.TargetPosition = get_position(bestBone);
            Aimbot.CanAim = true;

            Vector3 targetAngles = CalculateAimAngles(viewPosition, Aimbot.TargetPosition);
            ApplyAimAngles(targetAngles, Aimbot.Smooth);
        } else {
            Aimbot.TargetPlayer = nullptr;
            Aimbot.TargetBonePtr = nullptr;
            Aimbot.CanAim = false;
        }
    }
}
