#ifndef HOOKS_HPP
#define HOOKS_HPP

#include <atomic>
#include "structures.hpp"
#include "offsets.hpp"
#include "player.hpp"
#include "aimbot.hpp"
#import <os/log.h>

namespace hooks {

    // No code hooks: players are enumerated through UnityEngine.Object.FindObjectsOfType
    extern std::atomic<bool> hooks_ready;

    // Lazily resolves il2cpp api + PlayerController type (call on the render/main thread)
    void initialize();

    // Rebuilds the player list and runs the aimbot. Call once per rendered frame.
    void refresh_players();

    extern void* localPlayer;
    extern int localTeam;
    extern std::vector<void*> players;

    extern void* get_photon(void* player);
    extern ImVec2 world2screen_i(Vector3 pos);
    extern bool IsPlayerVisible(void* player);

    extern AimbotSettings Aimbot;
    extern void ExecuteAimbot();
}

#endif // HOOKS_HPP
