#include "hooks.hpp"
#include "silentaim.hpp"
#import <Foundation/Foundation.h>
#import "../interface/rendering/imgui/imgui.h"
#include "memutils.hpp"
#include <dlfcn.h>
#include <cstdint>
#include <cstring>
#include <vector>

namespace hooks {

    std::atomic<bool> hooks_ready{false};

    namespace {

        // ---- il2cpp api ----
        typedef void*  (*fn_domain_get)();
        typedef void** (*fn_domain_get_assemblies)(void*, size_t*);
        typedef void*  (*fn_assembly_get_image)(void*);
        typedef void*  (*fn_class_from_name)(void*, const char*, const char*);
        typedef void*  (*fn_class_get_type)(void*);
        typedef void*  (*fn_type_get_object)(void*);
        typedef void*  (*fn_thread_attach)(void*);

        fn_domain_get              p_domain_get = nullptr;
        fn_domain_get_assemblies   p_domain_get_assemblies = nullptr;
        fn_assembly_get_image      p_assembly_get_image = nullptr;
        fn_class_from_name         p_class_from_name = nullptr;
        fn_class_get_type          p_class_get_type = nullptr;
        fn_type_get_object         p_type_get_object = nullptr;
        fn_thread_attach           p_thread_attach = nullptr;

        void* g_domain = nullptr;
        void* g_typeObj = nullptr;                 // System.Type for Axlebolt.Standoff.Player.PlayerController
        void* (*g_find_objects)(void*) = nullptr;  // UnityEngine.Object.FindObjectsOfType(Type)
        bool  g_ready = false;
        int   g_retry = 0;

        // Il2CppArray: obj(0x10) + bounds(0x8) + max_length(0x4) + pad -> vector at 0x20
        constexpr uintptr_t kArrayLength = 0x18;
        constexpr uintptr_t kArrayData   = 0x20;

        const char* kNamespace = "Axlebolt.Standoff.Player";
        const char* kClassName = "PlayerController";
    }

    void initialize() {
        if (g_ready) return;

        p_domain_get            = (fn_domain_get)dlsym(RTLD_DEFAULT, "il2cpp_domain_get");
        p_domain_get_assemblies = (fn_domain_get_assemblies)dlsym(RTLD_DEFAULT, "il2cpp_domain_get_assemblies");
        p_assembly_get_image    = (fn_assembly_get_image)dlsym(RTLD_DEFAULT, "il2cpp_assembly_get_image");
        p_class_from_name       = (fn_class_from_name)dlsym(RTLD_DEFAULT, "il2cpp_class_from_name");
        p_class_get_type        = (fn_class_get_type)dlsym(RTLD_DEFAULT, "il2cpp_class_get_type");
        p_type_get_object       = (fn_type_get_object)dlsym(RTLD_DEFAULT, "il2cpp_type_get_object");
        p_thread_attach         = (fn_thread_attach)dlsym(RTLD_DEFAULT, "il2cpp_thread_attach");

        if (!p_domain_get || !p_domain_get_assemblies || !p_assembly_get_image ||
            !p_class_from_name || !p_class_get_type || !p_type_get_object) {
            if (g_retry++ % 120 == 0) {
                NSLog(@"[INIT] il2cpp api not ready yet");
            }
            return;
        }

        g_domain = p_domain_get();
        if (!g_domain) return;

        if (p_thread_attach) {
            p_thread_attach(g_domain);
        }

        size_t count = 0;
        void** assemblies = p_domain_get_assemblies(g_domain, &count);
        if (!assemblies || count == 0) return;

        void* klass = nullptr;
        for (size_t i = 0; i < count; i++) {
            if (!assemblies[i]) continue;
            void* image = p_assembly_get_image(assemblies[i]);
            if (!image) continue;
            klass = p_class_from_name(image, kNamespace, kClassName);
            if (klass) break;
        }

        if (!klass) {
            if (g_retry++ % 120 == 0) {
                NSLog(@"[INIT] %s.%s not found yet (%zu assemblies)", kNamespace, kClassName, count);
            }
            return;
        }

        void* type = p_class_get_type(klass);
        if (!type) return;

        g_typeObj = p_type_get_object(type);
        if (!g_typeObj) return;

        g_find_objects = (void* (*)(void*))getRealOffset(0x293C9AC);
        if (!g_find_objects) return;

        GetNickName     = (monoString* (*)(void*))getRealOffset(0x1C89F34);
        GetPlayerTeam   = (int (*)(void*))getRealOffset(0x1B56708);
        GetPlayerArmor  = (int (*)(void*))getRealOffset(0x1B709B8);
        GetPlayerHealth = (int (*)(void*))getRealOffset(0x1B7089C);
        GetPing         = (int (*)(void*))getRealOffset(0x1B56574);

        get_position     = (Vector3 (*)(void*))getRealOffset(0x2954ECC);
        get_forward      = (Vector3 (*)(void*))getRealOffset(0x2955714);
        get_transform    = (void* (*)(void*))getRealOffset(0x2926B00);
        get_camera       = (void* (*)())getRealOffset(0x2924910);
        WorldToViewpoint = (Vector3 (*)(void*, Vector3, int))getRealOffset(0x2924188);
        Linecast228      = (bool (*)(Vector3, Vector3, int))getRealOffset(0x2989960);
        get_width        = (int (*)())getRealOffset(0x294E3B0);
        get_height       = (int (*)())getRealOffset(0x294E3E4);

        if (!GetPlayerHealth || !get_camera || !WorldToViewpoint || !get_position) {
            NSLog(@"[INIT] game offsets not resolved");
            return;
        }

        g_ready = true;
        hooks_ready.store(true, std::memory_order_release);
        NSLog(@"[INIT] ready: %s.%s type=%p find=%p", kNamespace, kClassName, g_typeObj, (void*)g_find_objects);
    }

    void refresh_players() {
        if (!g_ready) {
            initialize();
            return;
        }

        void* array = nullptr;
        try {
            array = g_find_objects(g_typeObj);
        } catch (...) {
            return;
        }
        if (!array) return;

        uint32_t length = *(uint32_t*)((uintptr_t)array + kArrayLength);
        if (length == 0 || length > 4096) return;

        void** data = (void**)((uintptr_t)array + kArrayData);

        std::vector<void*> found;
        found.reserve(length);

        void* local = nullptr;
        int team = 0;

        for (uint32_t i = 0; i < length; i++) {
            void* pc = data[i];
            if (!pc) continue;

            void* photon = get_photon(pc);
            if (!photon) continue;

            bool isLocal = *(bool*)((uintptr_t)photon + kOffIsLocal);

            if (isLocal) {
                local = pc;
                team = GetPlayerTeam(photon);
                continue;
            }

            found.push_back(pc);
        }

        if (local) {
            localPlayer = local;
            localTeam = team;
        }

        {
            std::lock_guard<std::mutex> lock(players_mutex());
            players.swap(found);
        }

        if (localPlayer) {
            ExecuteAimbot();
            UpdateSilentAim();
        }
    }
}
