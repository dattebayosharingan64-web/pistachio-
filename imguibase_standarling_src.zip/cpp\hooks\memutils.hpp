#ifndef MEMUTILS_HPP
#define MEMUTILS_HPP

#include <mach-o/dyld.h>
#include <cstdint>
#include <cstring>

// Простой getRealOffset без KittyMemory (как в lst)
inline uint64_t getRealOffset(uint64_t address, const char *fileName = "UnityFramework") {
    int imageCount = _dyld_image_count();
    
    for(int i = 0; i < imageCount; i++) {
        const char *name = _dyld_get_image_name(i);
        if(!strstr(name, fileName)) continue;
        
        intptr_t slide = _dyld_get_image_vmaddr_slide(i);
        return (uint64_t)slide + address;
    }
    
    return 0;
}

#endif // MEMUTILS_HPP
