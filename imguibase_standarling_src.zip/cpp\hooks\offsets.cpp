#include "offsets.hpp"

namespace hooks {

    monoString* (*GetNickName)(void*) = nullptr;

    int (*GetPlayerTeam)(void*) = nullptr;
    int (*GetPlayerArmor)(void*) = nullptr;
    int (*GetPlayerHealth)(void*) = nullptr;
    int (*GetPing)(void*) = nullptr;

    Vector3 (*get_position)(void*) = nullptr;
    Vector3 (*get_forward)(void*) = nullptr;
    void* (*get_transform)(void*) = nullptr;
    void* (*get_camera)() = nullptr;
    Vector3 (*WorldToViewpoint)(void*, Vector3, int) = nullptr;
    bool (*Linecast228)(Vector3, Vector3, int) = nullptr;
    int (*get_width)() = nullptr;
    int (*get_height)() = nullptr;
}
