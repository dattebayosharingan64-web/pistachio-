#ifndef OFFSETS_HPP
#define OFFSETS_HPP

#include "structures.hpp"
#include "memutils.hpp"

#define ENCRYPTOFFSET(x) x

namespace hooks {

    // PhotonPlayer
    extern monoString* (*GetNickName)(void*);

    // Photon custom properties
    extern int (*GetPlayerTeam)(void*);
    extern int (*GetPlayerArmor)(void*);
    extern int (*GetPlayerHealth)(void*);
    extern int (*GetPing)(void*);

    // UnityEngine
    extern Vector3 (*get_position)(void*);
    extern Vector3 (*get_forward)(void*);
    extern void* (*get_transform)(void*);
    extern void* (*get_camera)();
    extern Vector3 (*WorldToViewpoint)(void*, Vector3, int);
    extern bool (*Linecast228)(Vector3, Vector3, int);
    extern int (*get_width)();
    extern int (*get_height)();
}

#endif // OFFSETS_HPP
