#ifndef PLAYER_HPP
#define PLAYER_HPP

#include "structures.hpp"
#include "offsets.hpp"
#include <cstdint>
#include <mutex>
#include <vector>

// Forward declaration for ImVec2
struct ImVec2;

namespace hooks {

    // ---- PlayerController field offsets (dump 3.8 / obfuscated build) ----
    static constexpr uint64_t kOffAimController = 0x50;
    static constexpr uint64_t kOffCharacterBiped = 0x30;
    static constexpr uint64_t kOffBipedMap      = 0x98;
    static constexpr uint64_t kOffTransform     = 0xC8;
    static constexpr uint64_t kOffPhotonView    = 0x110;
    static constexpr uint64_t kOffPhotonPlayer  = 0x120;

    // ---- PhotonPlayer offsets ----
    static constexpr uint64_t kOffIsLocal       = 0x28;

    // ---- BipedMap bone offsets ----
    static constexpr uint64_t kBoneHead        = 0x18;
    static constexpr uint64_t kBoneNeck        = 0x20;
    static constexpr uint64_t kBoneSpine1      = 0x28;
    static constexpr uint64_t kBoneSpine2      = 0x30;
    static constexpr uint64_t kBoneLShoulder   = 0x38;
    static constexpr uint64_t kBoneLUpperarm   = 0x40;
    static constexpr uint64_t kBoneLForearm    = 0x48;
    static constexpr uint64_t kBoneLHand       = 0x50;
    static constexpr uint64_t kBoneRShoulder   = 0x58;
    static constexpr uint64_t kBoneRUpperarm   = 0x60;
    static constexpr uint64_t kBoneRForearm    = 0x68;
    static constexpr uint64_t kBoneRHand       = 0x70;
    static constexpr uint64_t kBoneHip         = 0x78;
    static constexpr uint64_t kBoneLThigh      = 0x80;
    static constexpr uint64_t kBoneLCalf       = 0x88;
    static constexpr uint64_t kBoneLFoot       = 0x90;
    static constexpr uint64_t kBoneRThigh      = 0x98;
    static constexpr uint64_t kBoneRCalf       = 0xA0;
    static constexpr uint64_t kBoneRFoot       = 0xA8;

    extern void* localPlayer;
    extern int localTeam;
    extern std::vector<void*> players;

    std::mutex& players_mutex();
    std::vector<void*> players_snapshot();
    size_t players_count_safe();

    void clearPlayers();
    bool playerFind(void* pl);

    void* get_photon(void* player);
    void* get_view(void* player);

    inline void* GetBipedMap(void* player) {
        if (!player) return nullptr;
        void* characterBiped = *(void**)((uintptr_t)player + kOffCharacterBiped);
        if (characterBiped) return characterBiped;
        return *(void**)((uintptr_t)player + kOffBipedMap);
    }

    inline void* get_bone(void* bipedMap, uint64_t offset) {
        if (!bipedMap) return nullptr;
        return *(void**)((uintptr_t)bipedMap + offset);
    }

    float get_frame_delta_time();

    void sync_display_size(float width, float height);
    bool get_overlay_screen_size(int& width, int& height);

    ImVec2 world2screen_i(Vector3 pos);
    ImVec2 world2screen_c(Vector3 pos, bool& checker);

    Vector3 GetPlayerLocation(void* player);

    Vector3 GetPlayerHead(void* player);
    Vector3 GetPlayerNeck(void* player);
    Vector3 GetPlayerHip(void* player);
    Vector3 GetPlayerleftLowerArm(void* player);
    Vector3 GetPlayerLeftHand(void* player);
    Vector3 GetPlayerRightHand(void* player);
    Vector3 GetPlayerleftUpperArm(void* player);
    Vector3 GetPlayerrightLowerArm(void* player);
    Vector3 GetPlayerrightUpperArm(void* player);
    Vector3 GetPlayerleftLowerLeg(void* player);
    Vector3 GetPlayerleftUpperLeg(void* player);
    Vector3 GetPlayerrightLowerLeg(void* player);
    Vector3 GetPlayerrightUpperLeg(void* player);

    bool IsPlayerVisible(void* player);
}

#endif // PLAYER_HPP
