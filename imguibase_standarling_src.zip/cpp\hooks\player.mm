#include "player.hpp"
#import <Foundation/Foundation.h>
#import <os/log.h>
#import <mach/mach_time.h>
#import "../interface/rendering/imgui/imgui.h"

namespace hooks {

    void* localPlayer = nullptr;
    int localTeam = 0;
    std::vector<void*> players;

    std::mutex& players_mutex() {
        static std::mutex mtx;
        return mtx;
    }

    std::vector<void*> players_snapshot() {
        std::lock_guard<std::mutex> lock(players_mutex());
        return players;
    }

    size_t players_count_safe() {
        std::lock_guard<std::mutex> lock(players_mutex());
        return players.size();
    }

    static ImVec2 g_display_size = {0.0f, 0.0f};

    void sync_display_size(float width, float height) {
        g_display_size = ImVec2(width, height);
    }

    static bool read_screen_size(int& width, int& height) {
        if (ImGui::GetCurrentContext()) {
            width = (int)ImGui::GetIO().DisplaySize.x;
            height = (int)ImGui::GetIO().DisplaySize.y;
            if (width > 0 && height > 0) {
                return true;
            }
        }

        width = (int)g_display_size.x;
        height = (int)g_display_size.y;
        if (width > 0 && height > 0) {
            return true;
        }
        if (get_width && get_height) {
            width = get_width();
            height = get_height();
            if (width > 0 && height > 0) {
                return true;
            }
        }
        return false;
    }

    bool get_overlay_screen_size(int& width, int& height) {
        return read_screen_size(width, height);
    }

    float get_frame_delta_time() {
        static mach_timebase_info_data_t timebase = {};
        static bool timebase_ready = false;
        static uint64_t last_ticks = 0;

        if (!timebase_ready) {
            mach_timebase_info(&timebase);
            timebase_ready = true;
        }

        uint64_t now = mach_absolute_time();
        float dt = 1.0f / 60.0f;
        if (last_ticks != 0) {
            uint64_t elapsed = now - last_ticks;
            dt = (float)((double)elapsed * (double)timebase.numer / (double)timebase.denom / 1e9);
            if (dt <= 0.0f || dt > 0.5f) {
                dt = 1.0f / 60.0f;
            }
        }
        last_ticks = now;
        return dt;
    }

    void* get_photon(void* player) {
        if (!player) return nullptr;
        return *(void**)((uintptr_t)player + kOffPhotonPlayer);
    }

    void* get_view(void* player) {
        if (!player) return nullptr;
        return *(void**)((uintptr_t)player + kOffPhotonView);
    }

    ImVec2 world2screen_i(Vector3 pos) {
        auto cam = get_camera();
        if (!cam) return {0, 0};

        Vector3 worldPoint = WorldToViewpoint(cam, pos, 2);
        Vector3 location;

        int ScreenWidth = 0;
        int ScreenHeight = 0;
        if (!read_screen_size(ScreenWidth, ScreenHeight)) {
            return {0, 0};
        }

        location.x = ScreenWidth * worldPoint.x;
        location.y = ScreenHeight - worldPoint.y * ScreenHeight;
        location.z = worldPoint.z;

        return {location.x, location.y};
    }

    ImVec2 world2screen_c(Vector3 pos, bool& checker) {
        auto cam = get_camera();
        if (!cam) return {0, 0};

        Vector3 worldPoint = WorldToViewpoint(cam, pos, 2);
        Vector3 location;

        int ScreenWidth = 0;
        int ScreenHeight = 0;
        if (!read_screen_size(ScreenWidth, ScreenHeight)) {
            checker = false;
            return {0, 0};
        }

        location.x = ScreenWidth * worldPoint.x;
        location.y = ScreenHeight - worldPoint.y * ScreenHeight;
        location.z = worldPoint.z;

        checker = location.z > 1;

        return {location.x, location.y};
    }

    void clearPlayers() {
        std::lock_guard<std::mutex> lock(players_mutex());
        if (players.empty()) {
            return;
        }

        std::vector<void*> alive;
        alive.reserve(players.size());
        for (void* player : players) {
            if (!player) continue;
            void* photon = get_photon(player);
            if (!photon) continue;
            if (GetPlayerHealth(photon) > 0) {
                alive.push_back(player);
            }
        }
        players.swap(alive);
    }

    bool playerFind(void* pl) {
        if (!pl) return false;
        std::lock_guard<std::mutex> lock(players_mutex());
        for (void* player : players) {
            if (pl == player) return true;
        }
        return false;
    }

    Vector3 GetPlayerLocation(void* player) {
        if (!player) return Vector3(0, 0, 0);
        void* transform = *(void**)((uintptr_t)player + kOffTransform);
        if (!transform) return Vector3(0, 0, 0);
        return get_position(transform);
    }

    static Vector3 bone_pos(void* player, uint64_t offset) {
        void* bipedMap = GetBipedMap(player);
        void* bone = get_bone(bipedMap, offset);
        if (!bone) return Vector3(0, 0, 0);
        return get_position(bone);
    }

    Vector3 GetPlayerHead(void* player)        { return bone_pos(player, kBoneHead); }
    Vector3 GetPlayerNeck(void* player)        { return bone_pos(player, kBoneNeck); }
    Vector3 GetPlayerHip(void* player)         { return bone_pos(player, kBoneHip); }
    Vector3 GetPlayerleftLowerArm(void* player){ return bone_pos(player, kBoneLForearm); }
    Vector3 GetPlayerLeftHand(void* player)    { return bone_pos(player, kBoneLHand); }
    Vector3 GetPlayerRightHand(void* player)   { return bone_pos(player, kBoneRHand); }
    Vector3 GetPlayerleftUpperArm(void* player){ return bone_pos(player, kBoneLUpperarm); }
    Vector3 GetPlayerrightLowerArm(void* player){ return bone_pos(player, kBoneRForearm); }
    Vector3 GetPlayerrightUpperArm(void* player){ return bone_pos(player, kBoneRUpperarm); }
    Vector3 GetPlayerleftLowerLeg(void* player){ return bone_pos(player, kBoneLCalf); }
    Vector3 GetPlayerleftUpperLeg(void* player){ return bone_pos(player, kBoneLThigh); }
    Vector3 GetPlayerrightLowerLeg(void* player){ return bone_pos(player, kBoneRCalf); }
    Vector3 GetPlayerrightUpperLeg(void* player){ return bone_pos(player, kBoneRThigh); }

    bool IsPlayerVisible(void* player) {
        if (get_camera()) {
            Vector3 CameraPos = get_position(get_transform(get_camera()));

            bool CanSeeHead          = !Linecast228(CameraPos, GetPlayerHead(player), 16384);
            bool CanSeeHip           = !Linecast228(CameraPos, GetPlayerHip(player), 16384);
            bool CanSeeLeftLowerArm  = !Linecast228(CameraPos, GetPlayerleftLowerArm(player), 16384);
            bool CanSeeRightLowerArm = !Linecast228(CameraPos, GetPlayerrightLowerArm(player), 16384);
            bool CanSeeLeftLowerLeg  = !Linecast228(CameraPos, GetPlayerleftLowerLeg(player), 16384);
            bool CanSeeRightLowerLeg = !Linecast228(CameraPos, GetPlayerrightLowerLeg(player), 16384);

            return CanSeeHead || CanSeeHip || CanSeeLeftLowerArm ||
                   CanSeeRightLowerArm || CanSeeLeftLowerLeg || CanSeeRightLowerLeg;
        }
        return false;
    }
}
