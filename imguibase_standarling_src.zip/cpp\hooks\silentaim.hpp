#ifndef SILENTAIM_HPP
#define SILENTAIM_HPP

#include "structures.hpp"

namespace hooks {

    // Silent aim settings (runtime state lives here too, like in the reference)
    struct SilentSettings {
        bool Enable = false;
        bool VisibleCheck = true;
        bool FOVCheck = true;
        bool UseBulletTP = true;
        int FOV = 100;
        int AimBone = 0; // 0 = Head, 1 = Spine2, 2 = Spine1, 3 = Hip

        // runtime
        bool CanCast = false;
        void* Player = nullptr;
        void* TargetBone = nullptr;
        Vector3 Position;
        Vector3 StartPos;
    };

    extern SilentSettings Silent;

    // Installs the HitCaster hook (call once, after Unity is loaded)
    void InstallSilentAim();

    // True when the Dobby hook was installed successfully
    bool SilentHookReady();

    // Re-evaluates the silent aim target. Call once per rendered frame.
    void UpdateSilentAim();
}

#endif // SILENTAIM_HPP
