#include "silentaim.hpp"
#include "player.hpp"
#include "offsets.hpp"
#include "memutils.hpp"
#include "static_hook.h"
#include "../misc/misc.hpp"
#include "../esp/bullet_tracers.hpp"
#include "../interface/rendering/imgui/imgui.h"

#import <Foundation/Foundation.h>
#include <cmath>
#include <vector>

namespace hooks {

    SilentSettings Silent;

    namespace {

        // Axlebolt.Standoff.Inventory.Hit.HitCaster::MOFHMKANKPP
        // private static EEMFNNGIPKM (Vector3 start, Vector3 direction, float distance,
        //                               EKBLOPHDCPB parameters, int layer, HOMLMCNKAHI extra)
        typedef void* (*cast_bullet_fn)(Vector3, Vector3, float, void*, int, void*);

        cast_bullet_fn orig_cast_bullet = nullptr;
        bool g_installed = false;
        bool g_alerted = false;

        // The 3-arg and 4-arg public overloads both tail-call this core function,
        // so hooking it once covers every bullet cast.
        constexpr uint64_t kHitCasterCoreRVA = 0x1916F38;

        const char* kUnityPath = "Frameworks/UnityFramework.framework/UnityFramework";

        // EKBLOPHDCPB.KNEOCJLJFIL (readonly float) - the bullet's starting
        // penetration power. The core cast subtracts the per-surface loss from
        // this value and keeps going while it stays positive, so raising it
        // makes bullets pass through geometry (wallshot). Damage uses other
        // fields (+0x1C/+0x20), so this does not affect hit damage.
        constexpr uintptr_t kOffPenetrationPower = 0x18;
        constexpr float kWallshotPenetrationPower = 1000000.0f;

        // HKDNKEPCLPE (0.20.2 dump): Vector3 start at +0x20, Vector3 end at +0x2C.
        constexpr uintptr_t kOffResultStart = 0x20;
        constexpr uintptr_t kOffResultEnd   = 0x2C;

        void broadcast_tracer(void* result) {
            if (!result || !tracers::enabled) return;
            try {
                Vector3 s = *reinterpret_cast<Vector3*>(
                    reinterpret_cast<uintptr_t>(result) + kOffResultStart);
                Vector3 e = *reinterpret_cast<Vector3*>(
                    reinterpret_cast<uintptr_t>(result) + kOffResultEnd);
                tracers::AddTracer(s, e);
            } catch (...) {
            }
        }

        void* hook_cast_bullet(Vector3 start, Vector3 direction, float distance,
                               void* parameters, int layer, void* extra) {
            if (Misc::settings.wallshotEnabled && parameters != nullptr) {
                *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(parameters) +
                                          kOffPenetrationPower) = kWallshotPenetrationPower;
            }

            if (Silent.Enable && Silent.CanCast && Silent.Player != nullptr) {
                Vector3 origin = start;
                Vector3 target = Silent.Position;

                if (Silent.UseBulletTP && Silent.TargetBone != nullptr) {
                    origin = Silent.StartPos;
                    target = get_position(Silent.TargetBone);
                }

                Vector3 dir = target - origin;
                float len = sqrtf(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
                if (len > 0.0001f) {
                    dir.x /= len;
                    dir.y /= len;
                    dir.z /= len;
                    start = origin;
                    direction = dir;
                }

                Silent.CanCast = false;
                Silent.Player = nullptr;
                Silent.TargetBone = nullptr;
            }

            void* result = nullptr;
            if (!orig_cast_bullet) return nullptr;
            result = orig_cast_bullet(start, direction, distance, parameters, layer, extra);
            broadcast_tracer(result);
            return result;
        }

        void* bone_ptr(void* player, int bone) {
            void* biped = GetBipedMap(player);
            if (!biped) return nullptr;

            switch (bone) {
                case 1:  return get_bone(biped, kBoneSpine2);
                case 2:  return get_bone(biped, kBoneSpine1);
                case 3:  return get_bone(biped, kBoneHip);
                case 0:
                default: return get_bone(biped, kBoneHead);
            }
        }
    }

    void InstallSilentAim() {
        if (g_installed) return;
        g_installed = true;

        // The hook site is patched into UnityFramework offline (see tools/MachOPatch).
        // At runtime we only write the replacement pointer into __HOOK_DATA, which is
        // a writable segment, so no signed code page is ever touched (jailed devices).
        void* orig = StaticInlineHookFunction(kUnityPath, kHitCasterCoreRVA, (void*)hook_cast_bullet);
        if (orig) {
            orig_cast_bullet = (cast_bullet_fn)orig;
            NSLog(@"[SILENT] static hook installed, orig=%p", orig);
            return;
        }

        NSLog(@"[SILENT] hook block not found - UnityFramework is not patched");
        if (!g_alerted) {
            g_alerted = true;
            static_hook_present_alert(@"Функция не активирована.\n\nВ .app заменён непропатченный UnityFramework.\nНужно заменить Frameworks/UnityFramework.framework/UnityFramework на патченный файл и переподписать IPA.");
        }
    }

    bool SilentHookReady() {
        return orig_cast_bullet != nullptr;
    }

    void UpdateSilentAim() {
        Silent.CanCast = false;

        const bool wantWallshot = Misc::settings.wallshotEnabled;
        if (!Silent.Enable && !wantWallshot && !tracers::enabled) return;
        if (!localPlayer || !get_camera) return;

        // Install the hook lazily: the game stays untouched until a feature
        // that needs the bullet cast hook is enabled.
        if (!g_installed) InstallSilentAim();

        // Wallshot only needs the hook installed; the hook itself applies the
        // penetration power override. Skip target selection in that case.
        if (!Silent.Enable) return;

        int screen_w = 0;
        int screen_h = 0;
        if (!get_overlay_screen_size(screen_w, screen_h)) return;

        const float center_x = screen_w * 0.5f;
        const float center_y = screen_h * 0.5f;
        const float radius = (float)Silent.FOV * ((float)screen_w / 593.0f);
        const float radius_sq = radius * radius;

        void* best_player = nullptr;
        void* best_bone = nullptr;
        Vector3 best_pos;
        float best_dist_sq = 1.0e18f;

        const std::vector<void*> list = players_snapshot();
        for (void* player : list) {
            if (!player) continue;

            void* photon = get_photon(player);
            if (!photon) continue;
            if (GetPlayerTeam(photon) == localTeam) continue;
            if (GetPlayerHealth(photon) <= 0) continue;

            void* bone = bone_ptr(player, Silent.AimBone);
            if (!bone) continue;

            Vector3 pos = get_position(bone);
            if (pos.x == 0.0f && pos.y == 0.0f && pos.z == 0.0f) continue;

            ImVec2 screen = world2screen_i(pos);
            float dx = screen.x - center_x;
            float dy = screen.y - center_y;
            float dist_sq = dx * dx + dy * dy;

            if (Silent.FOVCheck && dist_sq > radius_sq) continue;
            if (dist_sq >= best_dist_sq) continue;

            if (Silent.VisibleCheck && !IsPlayerVisible(player)) continue;

            best_dist_sq = dist_sq;
            best_player = player;
            best_bone = bone;
            best_pos = pos;
        }

        if (!best_player || !best_bone) return;

        Silent.Player = best_player;
        Silent.TargetBone = best_bone;
        Silent.Position = best_pos;

        // Bullet TP start position: camera position (third person distance is 0 here)
        void* cam = get_camera();
        if (cam) {
            void* cam_transform = get_transform(cam);
            if (cam_transform) {
                Silent.StartPos = get_position(cam_transform);
            }
        }

        Silent.CanCast = true;
    }
}
