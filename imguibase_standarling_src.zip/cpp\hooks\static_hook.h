#ifndef STATIC_HOOK_H
#define STATIC_HOOK_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <mach-o/dyld.h>
#include "../../dobby_defines.h"

// Static Inline Hook Patch - создаёт пропатченный бинарник
NSString* StaticInlineHookPatch(const char* machoPath, uint64_t vaddr, char* patch);

// Static Inline Hook Function - устанавливает хук в runtime
void* StaticInlineHookFunction(const char* machoPath, uint64_t vaddr, void* replace);

// Active/Deactive Code Patch
BOOL ActiveCodePatch(const char* machoPath, uint64_t vaddr, char* patch);
BOOL DeactiveCodePatch(const char* machoPath, uint64_t vaddr, char* patch);

// Helper functions
void* find_module_by_path(const char* machoPath);
StaticInlineHookBlock* find_hook_block(void* base, uint64_t vaddr);

static inline void static_hook_present_alert(NSString* message) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Static Hook Patch"
                                                                       message:message
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                  style:UIAlertActionStyleDefault
                                                handler:nil]];
        UIViewController* rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
        if (rootVC) {
            [rootVC presentViewController:alert animated:YES completion:nil];
        } else {
            NSLog(@"[HOOK] Alert (no root VC): %@", message);
        }
    });
}

// Макрос: патч UnityFramework на диск + runtime hook (как GOVNO1488PASTA)
#define HOOK(x, y, z) \
do { \
    NSString* result_##y = StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework", x, nullptr); \
    if (result_##y) { \
        NSLog(@"[HOOK] Patch result for %s: %@", #y, result_##y); \
        if ([result_##y containsString:@"Патч создан"] || [result_##y containsString:@"переподпиши"]) { \
            static_hook_present_alert(result_##y); \
        } \
        void* orig_##y = StaticInlineHookFunction("Frameworks/UnityFramework.framework/UnityFramework", x, (void*)(y)); \
        NSLog(@"[HOOK] Function hook %s: orig=%p", #y, orig_##y); \
        if (orig_##y) { \
            *(void**)(&z) = orig_##y; \
        } else { \
            NSLog(@"[HOOK] %s — нет __HOOK_DATA в загруженном UnityFramework (замени бинарник из Documents/static-inline-hook/)", #y); \
        } \
    } \
} while (0)

#endif // STATIC_HOOK_H
