#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <os/log.h>

#include <mach-o/dyld.h>
#include <dlfcn.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

#include <vector>
#include <map>
#include <deque>
#include <thread>

// Dobby hooking library
#include "dobby_defines.h"

// Static Hook
#include "hooks/static_hook.h"

// SDK
#include "sdk/base/c_base.hpp"
#include "sdk/framework/c_framework.hpp"

// Hooks
#include "hooks/structures.hpp"
#include "hooks/offsets.hpp"
#include "hooks/player.hpp"
#include "hooks/aimbot.hpp"
#include "hooks/hooks.hpp"

// ESP
#include "esp/esp.h"

// ImGui
#import "interface/rendering/imgui/imgui.h"
#import "interface/rendering/imgui/imgui_internal.h"
#import "interface/rendering/imgui/imgui_impl_metal.h"
#import "interface/rendering/imgui/Honkai.h"

// ImGui Load
#import "interface/rendering/objective/ImGuiDrawView.h"
