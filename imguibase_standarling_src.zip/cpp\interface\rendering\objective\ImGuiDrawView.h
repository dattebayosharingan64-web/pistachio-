//
//  ImGuiDrawView.h
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface ImGuiDrawView : UIViewController

+ (void)showChange:(BOOL)open;
+ (void)syncOverlayInteraction;

@end

NS_ASSUME_NONNULL_END
