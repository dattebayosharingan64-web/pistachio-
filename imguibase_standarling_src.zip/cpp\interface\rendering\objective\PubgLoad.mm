//
//  PubgLoad.m
//  pubg
//
//  Created by 李良林 on 2021/2/14.
//

#import "PubgLoad.h"
#import <UIKit/UIKit.h>

#import "ImGuiLoad.h"
#import "ImGuiDrawView.h"
#import "bx_overlay.h"
#import "../../../auth/AuthManager.h"

@interface PubgLoad()
@property (nonatomic, strong) ImGuiDrawView *vna;
@end

@implementation PubgLoad

static PubgLoad *extraInfo;

UIWindow *mainWindow;

static UIView *PubgLoadHostView(void) {
    UIApplication *app = [UIApplication sharedApplication];
    UIWindow *window = app.keyWindow;
    if (!window && app.windows.count > 0) {
        window = app.windows.firstObject;
    }
    return window.rootViewController.view;
}

static void PubgLoadTryBootstrap(void) {
    if (!PubgLoadHostView()) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            PubgLoadTryBootstrap();
        });
        return;
    }

    if (!extraInfo) {
        mainWindow = [UIApplication sharedApplication].keyWindow;
        extraInfo = [PubgLoad new];
        [extraInfo initTapGes];
        [extraInfo initTapGes2];
    }
}

+ (void)bootstrapOverlayAndAuthorization {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!PubgLoadHostView()) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                [PubgLoad bootstrapOverlayAndAuthorization];
            });
            return;
        }

        if (!extraInfo) {
            mainWindow = [UIApplication sharedApplication].keyWindow;
            extraInfo = [PubgLoad new];
            [extraInfo initTapGes];
            [extraInfo initTapGes2];
        }

        static BOOL authObserverInstalled = NO;
        if (!authObserverInstalled) {
            authObserverInstalled = YES;
            [[NSNotificationCenter defaultCenter] addObserverForName:AuthSessionRevokedNotification
                                                              object:nil
                                                               queue:[NSOperationQueue mainQueue]
                                                          usingBlock:^(NSNotification *note) {
                UIViewController *vc = PubgLoadHostView().window.rootViewController;
                if (vc) {
                    [[AuthManager sharedInstance] showAccessRevokedAlert:vc];
                }
            }];
        }

        AuthManager *auth = [AuthManager sharedInstance];

        void (^attach)(void) = ^{
            [extraInfo attachOverlayShowMenu:NO];
        };

        __block void (^poll)(void) = nil;
        __block int attempts = 0;
        poll = ^{
            if ([auth isAuthorized]) {
                attach();
                return;
            }

            if ([auth getSavedKey].length > 0 && attempts < 8) {
                attempts++;
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), poll);
                return;
            }

            UIViewController *hostVC = PubgLoadHostView().window.rootViewController;
            [auth showAuthAlert:hostVC completion:^(BOOL success) {
                if (success) {
                    attach();
                }
            }];
        };
        poll();
    });
}

+ (void)load
{
    [super load];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        PubgLoadTryBootstrap();
    });
}

-(void)initTapGes
{
    UIView *host = PubgLoadHostView();
    if (!host) {
        NSLog(@"[PubgLoad] initTapGes skipped — no host view");
        return;
    }

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2;
    tap.numberOfTouchesRequired = 3;
    [host addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView)];
}

-(void)initTapGes2
{
    UIView *host = PubgLoadHostView();
    if (!host) {
        NSLog(@"[PubgLoad] initTapGes2 skipped — no host view");
        return;
    }

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2;
    tap.numberOfTouchesRequired = 2;
    [host addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView2)];
}

-(void)attachOverlayShowMenu:(BOOL)showMenu
{
    UIView *host = PubgLoadHostView();
    if (!host) {
        NSLog(@"[PubgLoad] attachOverlay skipped — no host view");
        return;
    }

    if (!_vna) {
        _vna = [[ImGuiDrawView alloc] init];
    }

    UIViewController *hostVC = host.window.rootViewController;
    if (hostVC && _vna.parentViewController != hostVC) {
        [_vna willMoveToParentViewController:nil];
        [_vna.view removeFromSuperview];
        [_vna removeFromParentViewController];

        [hostVC addChildViewController:_vna];
        _vna.view.frame = host.bounds;
        _vna.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [host addSubview:_vna.view];
        [_vna didMoveToParentViewController:hostVC];
    } else if (_vna.view.superview != host) {
        _vna.view.frame = host.bounds;
        _vna.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [host addSubview:_vna.view];
    }

    g_overlayView = (MTKView *)_vna.view;
    _vna.view.hidden = NO;
    _vna.view.alpha = 1.0;
    [host bringSubviewToFront:_vna.view];

    [ImGuiDrawView showChange:showMenu];
    [ImGuiDrawView syncOverlayInteraction];
}

-(void)tapIconView2
{
    [self attachOverlayShowMenu:NO];
}

-(void)tapIconView
{
    [self attachOverlayShowMenu:YES];
}

@end
