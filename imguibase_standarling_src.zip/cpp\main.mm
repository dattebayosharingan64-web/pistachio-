#include "includes.hpp"
#import "interface/rendering/objective/PubgLoad.h"
#include "menu/cheat_menu.hpp"
#include "misc/misc.hpp"
#include "esp/bullet_tracers.hpp"
#include "features/visual_misc.hpp"
#include "features/hit_logs.hpp"

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView

static bool MenDeal = false;
static ImGuiDrawView *g_activeDrawView = nil;
static std::atomic<bool> g_init_done{false};

- (instancetype)init
{
    return [self initWithNibName:nil bundle:nil];
}

+ (void)syncOverlayInteraction
{
    ImGuiDrawView *vc = g_activeDrawView;
    if (!vc || !vc.view) return;

    vc.view.userInteractionEnabled = MenDeal ? YES : NO;
    vc.view.multipleTouchEnabled = YES;
    if (vc.view.superview) {
        vc.view.superview.userInteractionEnabled = YES;
        [vc.view.superview bringSubviewToFront:vc.view];
    }
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 5.0f;
    style.FrameRounding = 3.0f;
    style.ScrollbarRounding = 3.0f;
    style.GrabRounding = 2.0f;
    style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style.FramePadding = ImVec2(8, 4);
    style.ItemSpacing = ImVec2(8, 6);

    ImVec4* colors = style.Colors;
    colors[ImGuiCol_WindowBg] = ImVec4(0.13f, 0.14f, 0.15f, 0.95f);
    colors[ImGuiCol_Border] = ImVec4(0.25f, 0.25f, 0.27f, 0.50f);
    colors[ImGuiCol_FrameBg] = ImVec4(0.20f, 0.21f, 0.22f, 1.00f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.25f, 0.26f, 0.27f, 1.00f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.29f, 0.30f, 1.00f);
    colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.10f, 0.11f, 1.00f);
    colors[ImGuiCol_TitleBgActive] = ImVec4(0.15f, 0.15f, 0.16f, 1.00f);
    colors[ImGuiCol_CheckMark] = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
    colors[ImGuiCol_SliderGrab] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    colors[ImGuiCol_SliderGrabActive] = ImVec4(0.70f, 0.70f, 0.70f, 1.00f);
    colors[ImGuiCol_Button] = ImVec4(0.25f, 0.25f, 0.27f, 1.00f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.35f, 0.35f, 0.37f, 1.00f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.40f, 0.40f, 0.42f, 1.00f);
    colors[ImGuiCol_Header] = ImVec4(0.25f, 0.25f, 0.27f, 1.00f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(0.35f, 0.35f, 0.37f, 1.00f);
    colors[ImGuiCol_HeaderActive] = ImVec4(0.40f, 0.40f, 0.42f, 1.00f);
    colors[ImGuiCol_Separator] = ImVec4(0.25f, 0.25f, 0.27f, 0.50f);
    colors[ImGuiCol_Tab] = ImVec4(0.20f, 0.20f, 0.22f, 1.00f);
    colors[ImGuiCol_TabHovered] = ImVec4(0.35f, 0.35f, 0.37f, 1.00f);
    colors[ImGuiCol_TabActive] = ImVec4(0.28f, 0.28f, 0.30f, 1.00f);
    colors[ImGuiCol_Text] = ImVec4(0.90f, 0.90f, 0.90f, 1.00f);
    colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);

    ImFontConfig font_cfg;
    font_cfg.OversampleH = 2;
    font_cfg.OversampleV = 2;
    const float kMenuFontPx = 20.0f;
    ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF(
        (void*)Honkai_compressed_data, Honkai_compressed_size,
        kMenuFontPx, &font_cfg, io.Fonts->GetGlyphRangesCyrillic());
    if (!font) {
        font = io.Fonts->AddFontDefault();
    }
    io.FontDefault = font;
    io.FontGlobalScale = 1.0f;
    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
    [ImGuiDrawView syncOverlayInteraction];
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

static CGRect PubgLoadSafeBounds(void) {
    UIApplication *app = [UIApplication sharedApplication];
    UIWindow *window = app.keyWindow;
    if (!window && app.windows.count > 0) {
        window = app.windows.firstObject;
    }

    UIView *host = window.rootViewController.view;
    if (host) {
        return host.bounds;
    }

    CGRect screen = UIScreen.mainScreen.bounds;
    return screen;
}

- (void)loadView
{
    CGRect bounds = PubgLoadSafeBounds();
    self.view = [[MTKView alloc] initWithFrame:bounds];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    g_activeDrawView = self;
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
}

#pragma mark - Interaction
- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    if (!anyTouch) return;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
    @autoreleasepool {

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    hooks::sync_display_size(view.bounds.size.width, view.bounds.size.height);

    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 120);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    if (!commandBuffer) return;

    [self.view setUserInteractionEnabled:(MenDeal ? YES : NO)];

        id<CAMetalDrawable> currentDrawable = view.currentDrawable;
        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil && currentDrawable != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            if (!renderEncoder) {
                [commandBuffer commit];
                return;
            }
            [renderEncoder pushDebugGroup:@"imgui base"];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();

            ImFont* font = ImGui::GetFont();
            if (font) {
                font->Scale = 15.0f / font->FontSize;
            }

            if (MenDeal) {
                CheatMenu::Draw(MenDeal);
            }

            if (g_init_done.load()) {
                Misc::Tick();
                ESP::DrawESP();

                // wwzavoz ports
                tracers::UpdateTracers();
                tracers::RenderTracers();

                VisualMisc::update(ImGui::GetIO().DeltaTime);
                VisualMisc::render();

                HitLogs::render();
            }

            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);

            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:currentDrawable];
        }

        [commandBuffer commit];
    }
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
}

void start_thread()
{
    try {
        NSLog(@"[INIT] start_thread called");

        sleep(5);

        NSLog(@"[INIT] Creating c_base...");
        base = new c_base();
        NSLog(@"[INIT] c_base created, unity_base: %p", (void*)base->unity_base);

        if (base->unity_base == 0) {
            NSLog(@"[INIT] ERROR: Unity not loaded! Aborting hook installation.");
            return;
        }

        NSLog(@"[INIT] Unity base ready, arming overlay");
        ESP::Initialize();
        Misc::Init();

        g_init_done = true;
        [PubgLoad bootstrapOverlayAndAuthorization];
        NSLog(@"[INIT] Initialization complete");
    } catch (const std::exception& e) {
        NSLog(@"[INIT] EXCEPTION in start_thread: %s", e.what());
    } catch (...) {
        NSLog(@"[INIT] UNKNOWN EXCEPTION in start_thread");
    }
}

void __attribute__((constructor)) initialize() {
    try {
        NSLog(@"[INIT] Constructor called, starting thread...");
        std::thread(start_thread).detach();
    } catch (...) {
        NSLog(@"[INIT] EXCEPTION in constructor");
    }
}

@end
