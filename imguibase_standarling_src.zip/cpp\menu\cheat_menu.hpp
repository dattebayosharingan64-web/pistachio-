#ifndef CHEAT_MENU_HPP
#define CHEAT_MENU_HPP

namespace CheatMenu {
    void Draw(bool& open);
}

#endif // CHEAT_MENU_HPP
