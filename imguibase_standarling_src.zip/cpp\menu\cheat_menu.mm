#include "cheat_menu.hpp"
#include "../esp/esp.h"
#include "../hooks/aimbot.hpp"
#include "../hooks/silentaim.hpp"
#include "../config/config.hpp"
#include "../misc/misc.hpp"
#include "../esp/bullet_tracers.hpp"
#include "../features/visual_misc.hpp"
#include "../features/hit_logs.hpp"
#import "../auth/AuthManager.h"
#import "../interface/rendering/imgui/imgui.h"
#import <UIKit/UIKit.h>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>

namespace CheatMenu {

    static void DrawEspTab() {
        ESP::Settings& s = ESP::settings;

        ImGui::Spacing();
        ImGui::Checkbox("Enable ESP", &s.enabled);

        ImGui::Separator();
        ImGui::Text("Visual Elements:");
        ImGui::Checkbox("Box", &s.showBox);
        if (s.showBox) {
            ImGui::SameLine();
            const char* boxTypes[] = { "Full", "Corner" };
            ImGui::SetNextItemWidth(100);
            ImGui::Combo("##BoxType", &s.boxType, boxTypes, IM_ARRAYSIZE(boxTypes));
        }
        ImGui::Checkbox("Skeleton", &s.showSkeleton);
        ImGui::Checkbox("Snapline", &s.showLine);
        ImGui::Checkbox("Distance", &s.showDistance);
        ImGui::Checkbox("Name", &s.showName);
        ImGui::Checkbox("Health Bar", &s.showHealth);
        ImGui::Checkbox("Armor Bar", &s.showArmor);
        ImGui::Checkbox("Offscreen Arrows", &s.showOffscreen);

        ImGui::Separator();
        ImGui::Text("Bullet Tracers:");
        ImGui::Checkbox("Enable Tracers", &tracers::enabled);
        if (tracers::enabled) {
            ImGui::SliderFloat("Thickness", &tracers::lineThickness, 1.0f, 5.0f, "%.1f");
            ImGui::SliderFloat("Fade Speed", &tracers::fadeSpeed, 0.5f, 10.0f, "%.1f");
            ImGui::ColorEdit4("Tracer##Color", (float*)&tracers::color);
        }

        ImGui::Separator();
        ImGui::Text("Filters:");
        ImGui::Checkbox("Team Check", &s.teamCheck);
        ImGui::SliderFloat("Max Distance", &s.maxDistance, 50.0f, 500.0f, "%.0fm");

        if (s.showLine) {
            ImGui::Separator();
            ImGui::Text("Snapline:");
            const char* lineTypes[] = { "Top", "Center", "Bottom" };
            ImGui::Combo("Position", &s.lineType, lineTypes, IM_ARRAYSIZE(lineTypes));
            ImGui::SliderInt("Width", &s.lineWidth, 1, 5);
        }
    }

    static void DrawColorsTab() {
        ESP::Settings& s = ESP::settings;

        ImGui::Spacing();
        ImGui::Text("Box Colors:");
        ImGui::ColorEdit4("Visible##Box", (float*)&s.boxVisibleColor);
        ImGui::ColorEdit4("Invisible##Box", (float*)&s.boxInvisibleColor);

        ImGui::Separator();
        ImGui::Text("Skeleton Colors:");
        ImGui::ColorEdit4("Visible##Skel", (float*)&s.skelVisibleColor);
        ImGui::ColorEdit4("Invisible##Skel", (float*)&s.skelInvisibleColor);

        ImGui::Separator();
        ImGui::Text("Health Bar:");
        ImGui::ColorEdit4("Low HP", (float*)&s.healthMinColor);
        ImGui::ColorEdit4("Full HP", (float*)&s.healthMaxColor);

        ImGui::Separator();
        ImGui::Text("Armor Bar:");
        ImGui::ColorEdit4("Low Armor", (float*)&s.armorMinColor);
        ImGui::ColorEdit4("Full Armor", (float*)&s.armorMaxColor);
    }

    static void DrawAimbotTab() {
        hooks::AimbotSettings& a = hooks::Aimbot;

        ImGui::Spacing();
        ImGui::Checkbox("Enable Aimbot", &a.Enable);

        ImGui::Separator();
        ImGui::Checkbox("Visible check", &a.VisibleCheck);
        ImGui::Checkbox("Team check", &a.TeamCheck);
        ImGui::Checkbox("FOV check", &a.FOVCheck);

        ImGui::SliderInt("FOV", &a.FOV, 5, 300);
        ImGui::SliderFloat("Smooth", &a.Smooth, 0.0f, 0.95f, "%.2f");

        const char* bones[] = { "Head", "Spine2", "Spine1", "Hip", "Hands" };
        ImGui::Combo("Target bone", &a.TargetBone, bones, IM_ARRAYSIZE(bones));

        ImGui::Separator();
        ImGui::Text("FOV / target color");
        ImGui::ColorEdit4("##aimcolor", &a.ColorR,
                          ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
    }

    static void DrawSilentTab() {
        hooks::SilentSettings& s = hooks::Silent;

        ImGui::Spacing();
        ImGui::Checkbox("Enable Silent Aim", &s.Enable);

        ImGui::Separator();
        ImGui::Checkbox("Visible check", &s.VisibleCheck);
        ImGui::Checkbox("FOV check", &s.FOVCheck);
        ImGui::Checkbox("Bullet TP", &s.UseBulletTP);

        ImGui::SliderInt("FOV", &s.FOV, 5, 300);

        const char* bones[] = { "Head", "Spine2", "Spine1", "Hip" };
        ImGui::Combo("Target bone", &s.AimBone, bones, IM_ARRAYSIZE(bones));

        ImGui::Separator();
        if (hooks::Silent.CanCast) {
            ImGui::TextColored(ImVec4(0.3f, 1.0f, 0.4f, 1.0f), "Target locked");
        } else {
            ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "No target");
        }
        ImGui::Text("Hook: %s", hooks::SilentHookReady() ? "installed" : "not installed");
    }

    static void DrawMiscTab() {
        std::vector<void*> pl = hooks::players_snapshot();
        ImGui::Spacing();
        ImGui::Text("Players: %zu", pl.size());
        ImGui::Text("Team: %d", hooks::localTeam);
        ImGui::Text("Local player: %p", hooks::localPlayer);
        ImGui::Text("Camera: %p", hooks::get_camera ? hooks::get_camera() : nullptr);

        if (!pl.empty()) {
            void* p = pl[0];
            void* biped = hooks::GetBipedMap(p);
            Vector3 pos = hooks::GetPlayerLocation(p);

            Vector3 head = Vector3(0, 0, 0);
            void* headBone = hooks::get_bone(biped, hooks::kBoneHead);
            if (headBone && hooks::get_position) {
                head = hooks::get_position(headBone);
            }

            float dx = head.x - pos.x;
            float dy = head.y - pos.y;
            float dz = head.z - pos.z;
            float delta = sqrtf(dx * dx + dy * dy + dz * dz);

            ImGui::Separator();
            ImGui::Text("Player0: %p", p);
            ImGui::Text("Biped: %p", biped);
            ImGui::Text("Self: %.1f %.1f %.1f", pos.x, pos.y, pos.z);
            ImGui::Text("Head: %.1f %.1f %.1f", head.x, head.y, head.z);
            ImGui::Text("Delta: %.2f", delta);
        }

        ImGui::Separator();
        ImGui::Text("Exploits:");
        ImGui::Checkbox("FOV Changer", &Misc::settings.fovEnabled);
        if (Misc::settings.fovEnabled) {
            ImGui::SliderFloat("FOV", &Misc::settings.fovValue, 60.0f, 120.0f, "%.0f");
        }

        ImGui::Checkbox("Speed Hack", &Misc::settings.speedEnabled);
        if (Misc::settings.speedEnabled) {
            ImGui::SliderFloat("Speed", &Misc::settings.speedMultiplier, 1.0f, 5.0f, "x%.2f");
        }

        ImGui::Checkbox("Fake Lag", &Misc::settings.fakeLagEnabled);
        if (Misc::settings.fakeLagEnabled) {
            ImGui::SliderFloat("Lag time", &Misc::settings.fakeLagLock, 0.05f, 2.0f, "%.2fs");
            ImGui::SliderFloat("Release", &Misc::settings.fakeLagRelease, 0.05f, 2.0f, "%.2fs");
        }

        ImGui::Checkbox("Infinite Ammo", &Misc::settings.infinityAmmoEnabled);
        ImGui::Checkbox("Wallshot", &Misc::settings.wallshotEnabled);
        if (Misc::settings.wallshotEnabled) {
            ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "Hook: %s",
                               hooks::SilentHookReady() ? "installed" : "waiting");
        }

        ImGui::Checkbox("No Recoil", &Misc::settings.noRecoilEnabled);

        ImGui::Separator();
        ImGui::Text("Bunny Hop:");
        ImGui::Checkbox("Enable Bhop", &Misc::settings.bhopEnabled);
        if (Misc::settings.bhopEnabled) {
            ImGui::SliderFloat("Jump Force", &Misc::settings.bhopJumpForceMult, 0.5f, 20.0f, "x%.2f");
            ImGui::SliderFloat("Bhop Speed", &Misc::settings.bhopSpeedMult, 0.1f, 20.0f, "x%.2f");
            ImGui::SliderFloat("Air Speed", &Misc::settings.bhopAirSpeedMult, 0.1f, 20.0f, "x%.2f");
        }

        ImGui::Checkbox("Fire Rate", &Misc::settings.fireRateEnabled);
        if (Misc::settings.fireRateEnabled) {
            ImGui::SliderFloat("Rate", &Misc::settings.fireRateMult, 1.0f, 50.0f, "x%.1f");
        }

        ImGui::Separator();
        ImGui::Text("Hit feedback (wwzavoz):");
        ImGui::Checkbox("Hit Markers", &VisualMisc::show_hit_markers);
        ImGui::Checkbox("Damage Numbers", &VisualMisc::show_damage_indicators);
        ImGui::Checkbox("Crosshair Info", &VisualMisc::show_crosshair_info);
        ImGui::Checkbox("Hit Logs", &HitLogs::enabled);

        ImGui::Separator();
        if (ImGui::Button("Change key", ImVec2(140, 28))) {
            UIViewController* vc = [UIApplication sharedApplication].keyWindow.rootViewController;
            if (vc) {
                [[AuthManager sharedInstance] showAuthAlert:vc completion:^(BOOL success) {}];
            }
        }

        ImGui::Separator();
        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "@la1trexxcc");
    }

    static void DrawConfigTab() {
        static int selected_slot = 0;
        static char rename_buf[33] = "";
        static int rename_slot = -1;

        ImGui::Spacing();
        ImGui::SetNextItemWidth(200);
        ImGui::SliderInt("Slot", &selected_slot, 0, Config::kSlotCount - 1);

        std::string name = Config::SlotName(selected_slot);
        if (rename_slot != selected_slot) {
            rename_slot = selected_slot;
            std::strncpy(rename_buf, name.c_str(), sizeof(rename_buf) - 1);
            rename_buf[sizeof(rename_buf) - 1] = '\0';
        }

        ImGui::Text("Name: %s", name.c_str());
        ImGui::SetNextItemWidth(200);
        ImGui::InputText("Rename", rename_buf, sizeof(rename_buf));
        if (ImGui::Button("Apply name", ImVec2(120, 28))) {
            Config::SetSlotName(selected_slot, std::string(rename_buf));
        }

        ImGui::Spacing();
        if (Config::SlotHasData(selected_slot)) {
            ImGui::TextColored(ImVec4(0.3f, 1.0f, 0.4f, 1.0f), "Status: saved");
        } else {
            ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Status: empty");
        }

        if (ImGui::Button("Save", ImVec2(90, 30))) {
            Config::Save(selected_slot);
        }
        ImGui::SameLine();
        if (ImGui::Button("Load", ImVec2(90, 30))) {
            Config::Load(selected_slot);
        }
        ImGui::SameLine();
        if (ImGui::Button("Delete", ImVec2(90, 30))) {
            Config::Delete(selected_slot);
        }

        ImGui::Spacing();
        if (ImGui::Button("Reset defaults", ImVec2(160, 30))) {
            Config::ResetDefaults();
        }
    }

    void Draw(bool& open) {
        if (!open) return;

        ImVec2 ds = ImGui::GetIO().DisplaySize;

        float w = ds.x - 32.0f;
        if (w > 500.0f) w = 500.0f;
        if (w < 280.0f) w = ds.x - 16.0f;

        float h = ds.y - 32.0f;
        if (h > 430.0f) h = 430.0f;
        if (h < 220.0f) h = ds.y - 16.0f;

        ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);
        ImGui::SetNextWindowPos(ImVec2((ds.x - w) * 0.5f, (ds.y - h) * 0.5f),
                                ImGuiCond_Always);

        if (ImGui::Begin("@la1trexxcc free standarling 0.20.2", &open,
                         ImGuiWindowFlags_NoCollapse)) {
            if (ImGui::BeginTabBar("MainTabs", ImGuiTabBarFlags_None)) {
                if (ImGui::BeginTabItem("ESP")) {
                    DrawEspTab();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Colors")) {
                    DrawColorsTab();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Aimbot")) {
                    DrawAimbotTab();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Silent")) {
                    DrawSilentTab();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Config")) {
                    DrawConfigTab();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Misc")) {
                    DrawMiscTab();
                    ImGui::EndTabItem();
                }
                ImGui::EndTabBar();
            }
        }
        ImGui::End();
    }
}
