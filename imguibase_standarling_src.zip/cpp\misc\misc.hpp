#ifndef MISC_HPP
#define MISC_HPP

namespace Misc {

    struct Settings {
        // FOV changer
        bool fovEnabled = false;
        float fovValue = 90.0f;

        // Fake lag (PhotonView.synchronization)
        bool fakeLagEnabled = false;
        float fakeLagLock = 0.5f;
        float fakeLagRelease = 0.5f;

        // Speed hack
        bool speedEnabled = false;
        float speedMultiplier = 1.0f;

        // Infinite ammo
        bool infinityAmmoEnabled = false;

        // Wallshot (bullets keep their penetration power through geometry)
        bool wallshotEnabled = false;

        // No recoil (zeroes GunParameters recoil fields, ported from wwzavoz)
        bool noRecoilEnabled = false;

        // Bunny hop (JumpParameters boost, ported from wwzavoz; 0.20.2 layout)
        bool bhopEnabled = false;
        float bhopJumpForceMult  = 1.2f;  // upwardSpeedDefualt multiplier
        float bhopSpeedMult      = 1.0f;  // jumpCurve(CurvedValue) multiplier boost
        float bhopAirSpeedMult   = 1.0f;  // JumpMoveSpeed multiplier

        // Fire rate (GunParameters._fireRate boost, ported from wwzavoz rapid fire)
        bool fireRateEnabled = false;
        float fireRateMult = 3.0f;        // RPM multiplier
    };

    extern Settings settings;

    void Init();
    void Tick();
}

#endif // MISC_HPP
