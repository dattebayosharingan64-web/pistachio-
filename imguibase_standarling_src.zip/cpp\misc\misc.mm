#include "misc.hpp"
#include "../hooks/player.hpp"
#include "../hooks/hooks.hpp"
#include "../hooks/offsets.hpp"
#include "../hooks/memutils.hpp"
#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <cstring>
#include <unordered_map>

namespace Misc {

    Settings settings;

    static void (*set_field_of_view)(void*, float) = nullptr;

    namespace {

        // PlayerController -> MovementController -> PlayerTranslationParameters
        constexpr uintptr_t kOffMovementController     = 0x68;
        constexpr uintptr_t kOffTranslationParameters  = 0xA0;
        constexpr uintptr_t kOffWalkParameters         = 0x30;
        constexpr uintptr_t kOffWalkSpeedMultiplier    = 0x10;

        // PhotonView.synchronization (ViewSynchronization enum)
        constexpr uintptr_t kOffViewSynchronization    = 0x48;

        // PlayerTranslationParameters.WalkParameters.EHMJIJMPFAF() - rebuilds the
        // encrypted "safe" copy of walkSpeedMultiplier from the plain field at +0x10.
        constexpr uint64_t kRvaRefreshWalkSpeed        = 0x1AAAD9C;

        void (*refresh_walk_speed)(void*) = nullptr;
        bool speed_was_on = false;

        // ---- infinite ammo ----
        // PlayerController -> WeaponryController -> WeaponController (GunController)
        constexpr uintptr_t kOffWeaponryController = 0x58;
        constexpr uintptr_t kOffCurrentWeapon      = 0x90;
        // GunController
        constexpr uintptr_t kOffGunParameters      = 0x118;
        constexpr uintptr_t kOffMagazineCounter    = 0xE8;   // live magazine counter
        constexpr uintptr_t kOffReserveCounter     = 0xE0;   // live reserve counter
        constexpr uintptr_t kOffAmmoState          = 0x130;  // HDHCKOPBLLF (serialized ammo)
        constexpr uintptr_t kOffAmmoStateMag       = 0x28;   // short
        constexpr uintptr_t kOffAmmoStateReserve   = 0x2A;   // short
        // GunParameters -> Ammunition
        constexpr uintptr_t kOffAmmunition         = 0x90;
        constexpr uintptr_t kOffSafeAmmunition     = 0x130;  // BPAGIELACGE (lazy wrapper)
        constexpr uintptr_t kOffAmmunitionMagCap   = 0x10;   // short
        constexpr uintptr_t kOffAmmunitionResCap   = 0x12;   // short
        constexpr uintptr_t kOffSafeMagCounter     = 0x10;   // BPAGIELACGE magazine counter
        constexpr uintptr_t kOffSafeResCounter     = 0x18;   // BPAGIELACGE reserve counter
        // HBACMCNGFLP: current value = DCIHPBIMBBB(+0x14) - MGHOPILMIKI(+0x10)
        constexpr uintptr_t kOffAmmoBase           = 0x10;
        constexpr uintptr_t kOffAmmoTotal          = 0x14;

        typedef void* (*fn_object_get_class)(void*);
        typedef const char* (*fn_class_get_name)(void*);
        fn_object_get_class p_object_get_class = nullptr;
        fn_class_get_name   p_class_get_name   = nullptr;

        bool valid_ptr(uintptr_t p) {
            return p > 0x10000ULL;
        }

        float lag_timer_lock = 0.0f;
        float lag_timer_release = 0.0f;
        bool  lagging = false;

        void ApplyFov() {
            if (!settings.fovEnabled) return;
            if (!set_field_of_view || !hooks::get_camera) return;

            void* camera = hooks::get_camera();
            if (!camera) return;

            float fov = settings.fovValue;
            if (fov < 30.0f) fov = 30.0f;
            if (fov > 140.0f) fov = 140.0f;

            set_field_of_view(camera, fov);
        }

        void ApplyFakeLag() {
            void* local = hooks::localPlayer;
            if (!local) return;

            void* view = hooks::get_view(local);
            if (!view) return;

            if (!settings.fakeLagEnabled) {
                *(int*)((uintptr_t)view + kOffViewSynchronization) = 3;
                lag_timer_lock = 0.0f;
                lag_timer_release = 0.0f;
                lagging = false;
                return;
            }

            if (hooks::players_count_safe() == 0) {
                *(int*)((uintptr_t)view + kOffViewSynchronization) = 3;
                return;
            }

            float dt = hooks::get_frame_delta_time();
            if (dt <= 0.0f || dt > 0.5f) dt = 1.0f / 60.0f;

            if (lagging) {
                *(int*)((uintptr_t)view + kOffViewSynchronization) = 0;
                lag_timer_lock += dt;
                if (lag_timer_lock >= settings.fakeLagLock) {
                    lagging = false;
                    lag_timer_lock = 0.0f;
                    lag_timer_release = 0.0f;
                    *(int*)((uintptr_t)view + kOffViewSynchronization) = 3;
                }
            } else {
                *(int*)((uintptr_t)view + kOffViewSynchronization) = 3;
                lag_timer_release += dt;
                if (lag_timer_release >= settings.fakeLagRelease) {
                    lagging = true;
                    lag_timer_lock = 0.0f;
                    lag_timer_release = 0.0f;
                }
            }
        }

        void ApplySpeed() {
            if (!settings.speedEnabled && !speed_was_on) return;

            uintptr_t player = (uintptr_t)hooks::localPlayer;
            if (!valid_ptr(player)) return;

            uintptr_t movement = *(uintptr_t*)(player + kOffMovementController);
            if (!valid_ptr(movement)) return;

            uintptr_t translation = *(uintptr_t*)(movement + kOffTranslationParameters);
            if (!valid_ptr(translation)) return;

            uintptr_t walk = *(uintptr_t*)(translation + kOffWalkParameters);
            if (!valid_ptr(walk)) return;

            float mult = 1.0f;
            if (settings.speedEnabled) {
                mult = settings.speedMultiplier;
                if (mult < 1.0f) mult = 1.0f;
                if (mult > 5.0f) mult = 5.0f;
            }
            speed_was_on = settings.speedEnabled;

            *(float*)(walk + kOffWalkSpeedMultiplier) = mult;

            // 0.20.2 keeps an encrypted copy of walkSpeedMultiplier at +0x18 and the
            // getter reads that copy, so writing +0x10 alone has no effect. Rebuild
            // the encrypted copy from the value we just wrote.
            if (refresh_walk_speed) refresh_walk_speed((void*)walk);
        }

        bool is_class_named(void* obj, const char* expected) {
            if (!obj) return false;
            if (!p_object_get_class || !p_class_get_name) return false;
            void* klass = p_object_get_class(obj);
            if (!klass) return false;
            const char* name = p_class_get_name(klass);
            return name && strcmp(name, expected) == 0;
        }

        bool is_gun_controller(void* weapon) {
            return is_class_named(weapon, "GunController");
        }

        // HBACMCNGFLP setter is "current = value"; it is stored as base + value.
        void refill_counter(uintptr_t counter, int value) {
            if (!valid_ptr(counter) || value <= 0) return;
            int base  = *(int*)(counter + kOffAmmoBase);
            int total = *(int*)(counter + kOffAmmoTotal);
            if (total - base < value) {
                *(int*)(counter + kOffAmmoTotal) = base + value;
            }
        }

        void ApplyInfinityAmmo() {
            if (!settings.infinityAmmoEnabled) return;

            uintptr_t player = (uintptr_t)hooks::localPlayer;
            if (!valid_ptr(player)) return;
            if (!is_class_named((void*)player, "PlayerController")) return;

            uintptr_t weaponry = *(uintptr_t*)(player + kOffWeaponryController);
            if (!valid_ptr(weaponry)) return;

            uintptr_t weapon = *(uintptr_t*)(weaponry + kOffCurrentWeapon);
            if (!valid_ptr(weapon)) return;
            if (!is_gun_controller((void*)weapon)) return;

            uintptr_t gun_params = *(uintptr_t*)(weapon + kOffGunParameters);
            if (!valid_ptr(gun_params)) return;

            uintptr_t ammunition = *(uintptr_t*)(gun_params + kOffAmmunition);
            if (!valid_ptr(ammunition)) return;

            int mag_cap = (int)*(int16_t*)(ammunition + kOffAmmunitionMagCap);
            int res_cap = (int)*(int16_t*)(ammunition + kOffAmmunitionResCap);
            if (mag_cap <= 0 || mag_cap > 4096) return;
            if (res_cap < 0 || res_cap > 65535) res_cap = 0;

            // Live counters used by the firing code.
            refill_counter(*(uintptr_t*)(weapon + kOffMagazineCounter), mag_cap);
            refill_counter(*(uintptr_t*)(weapon + kOffReserveCounter), res_cap);

            // Serialized per-weapon ammo state (Photon message).
            uintptr_t ammo_state = *(uintptr_t*)(weapon + kOffAmmoState);
            if (valid_ptr(ammo_state)) {
                *(int16_t*)(ammo_state + kOffAmmoStateMag) = (int16_t)mag_cap;
                *(int16_t*)(ammo_state + kOffAmmoStateReserve) = (int16_t)res_cap;
            }

            // Parameter-side ammo pool (used when GunController.JEFGPHEBGKJ is set).
            uintptr_t safe_ammo = *(uintptr_t*)(gun_params + kOffSafeAmmunition);
            if (valid_ptr(safe_ammo)) {
                refill_counter(*(uintptr_t*)(safe_ammo + kOffSafeMagCounter), mag_cap);
                refill_counter(*(uintptr_t*)(safe_ammo + kOffSafeResCounter), res_cap);
            }
        }
    }

    void Init() {
        set_field_of_view = (void (*)(void*, float))getRealOffset(0x29235EC);
        refresh_walk_speed = (void (*)(void*))getRealOffset(kRvaRefreshWalkSpeed);
        p_object_get_class = (fn_object_get_class)dlsym(RTLD_DEFAULT, "il2cpp_object_get_class");
        p_class_get_name   = (fn_class_get_name)dlsym(RTLD_DEFAULT, "il2cpp_class_get_name");
        NSLog(@"[MISC] fov=%p walkRefresh=%p getClass=%p className=%p",
              (void*)set_field_of_view, (void*)refresh_walk_speed,
              (void*)p_object_get_class, (void*)p_class_get_name);
    }

    // BunnyHop: PlayerTranslationParameters.JumpParameters boost.
    // 0.20.2 dump: PlayerController +0x68 MovementController,
    // +0xA0 translationParameters, +0x48 jumpParameters (pointer).
    // JumpParameters: upwardSpeedDefualt +0x10, jumpCurve(CurvedValue) +0x18
    // (CurvedValue.multiplier at +0x18), JumpMoveSpeed +0x60.
    // WWZ-основа (bhopSpeedMultiplier/maxBhopSpeed/bhop-флаг) в 0.20.2 отсутствует,
    // эквивалент - множители силы прыжка, дуги прыжка и скорости в воздухе.
    void ApplyBunnyHop() {
        struct BhopBackup {
            float jumpForce = 0.0f;
            float curveMult = 0.0f;
            float airSpeed  = 0.0f;
            bool  valid = false;
        };
        static std::unordered_map<uintptr_t, BhopBackup> originals;

        constexpr uintptr_t kOffJumpParameters  = 0x48;  // in PlayerTranslationParameters
        constexpr uintptr_t kOffUpwardSpeed     = 0x10;  // JumpParameters
        constexpr uintptr_t kOffJumpCurve       = 0x18;  // JumpParameters -> CurvedValue*
        constexpr uintptr_t kOffCurveMultiplier = 0x18;  // CurvedValue
        constexpr uintptr_t kOffJumpMoveSpeed   = 0x60;  // JumpParameters

        if (settings.bhopEnabled) {
            uintptr_t player = (uintptr_t)hooks::localPlayer;
            if (!valid_ptr(player)) return;
            if (!is_class_named((void*)player, "PlayerController")) return;

            uintptr_t movement = *(uintptr_t*)(player + kOffMovementController);
            if (!valid_ptr(movement)) return;

            uintptr_t translation = *(uintptr_t*)(movement + kOffTranslationParameters);
            if (!valid_ptr(translation)) return;

            uintptr_t jump = *(uintptr_t*)(translation + kOffJumpParameters);
            if (!valid_ptr(jump)) return;

            auto& slot = originals[jump];
            if (!slot.valid) {
                slot.jumpForce = *(float*)(jump + kOffUpwardSpeed);
                slot.airSpeed  = *(float*)(jump + kOffJumpMoveSpeed);
                slot.valid = true;

                uintptr_t cv = *(uintptr_t*)(jump + kOffJumpCurve);
                if (valid_ptr(cv)) {
                    slot.curveMult = *(float*)(cv + kOffCurveMultiplier);
                }
            }

            float jfMult = settings.bhopJumpForceMult;
            if (jfMult < 0.2f) jfMult = 0.2f;
            if (jfMult > 20.0f) jfMult = 20.0f;
            *(float*)(jump + kOffUpwardSpeed) = slot.jumpForce * jfMult;

            float asMult = settings.bhopAirSpeedMult;
            if (asMult < 0.1f) asMult = 0.1f;
            if (asMult > 20.0f) asMult = 20.0f;
            *(float*)(jump + kOffJumpMoveSpeed) = slot.airSpeed * asMult;

            uintptr_t cv = *(uintptr_t*)(jump + kOffJumpCurve);
            if (valid_ptr(cv)) {
                float spMult = settings.bhopSpeedMult;
                if (spMult < 0.1f) spMult = 0.1f;
                if (spMult > 20.0f) spMult = 20.0f;
                *(float*)(cv + kOffCurveMultiplier) = slot.curveMult * spMult;
            }
        } else if (!originals.empty()) {
            for (const auto& kv : originals) {
                const uintptr_t jump = kv.first;
                const BhopBackup& b = kv.second;
                if (!valid_ptr(jump) || !b.valid) continue;

                *(float*)(jump + kOffUpwardSpeed)   = b.jumpForce;
                *(float*)(jump + kOffJumpMoveSpeed) = b.airSpeed;

                uintptr_t cv = *(uintptr_t*)(jump + kOffJumpCurve);
                if (valid_ptr(cv)) {
                    *(float*)(cv + kOffCurveMultiplier) = b.curveMult;
                }
            }
            originals.clear();
        }
    }

    void ApplyNoRecoil() {
        // GunParameters (extends WeaponParameters) recoil fields, from dump.cs 0.20.2:
        //   private int _recoilControl;               // 0xA8
        //   private RecoilParameters _recoilParameters; // 0xB0
        //     public float horizontalRange;           // 0x10
        //     public float verticalRange;             // 0x14
        //   private float _recoilMultOnCrouch;        // 0xD0
        //   private float _recoilAimMult;             // 0xD8
        //   private float _recoilAimMultOnCrouch;     // 0xE0
        constexpr uintptr_t kOffRecoilControl   = 0xA8;
        constexpr uintptr_t kOffRecoilParams    = 0xB0;
        constexpr uintptr_t kOffHorizontalRange = 0x10;
        constexpr uintptr_t kOffVerticalRange   = 0x14;
        constexpr uintptr_t kOffMultOnCrouch    = 0xD0;
        constexpr uintptr_t kOffAimMult         = 0xD8;
        constexpr uintptr_t kOffAimMultCrouch   = 0xE0;

        struct RecoilBackup {
            int   recoilControl = 0;
            float horizontalRange = 0.0f;
            float verticalRange   = 0.0f;
            float multOnCrouch    = 0.0f;
            float aimMult         = 0.0f;
            float aimMultCrouch   = 0.0f;
            bool  valid = false;
        };

        // originals captured on first enable, restored when the feature is off
        static std::unordered_map<uintptr_t, RecoilBackup> originals;

        uintptr_t gun_params = 0;

        if (settings.noRecoilEnabled) {
            uintptr_t player = (uintptr_t)hooks::localPlayer;
            if (!valid_ptr(player)) return;
            if (!is_class_named((void*)player, "PlayerController")) return;

            uintptr_t weaponry = *(uintptr_t*)(player + kOffWeaponryController);
            if (!valid_ptr(weaponry)) return;

            uintptr_t weapon = *(uintptr_t*)(weaponry + kOffCurrentWeapon);
            if (!valid_ptr(weapon)) return;
            if (!is_gun_controller((void*)weapon)) return;

            gun_params = *(uintptr_t*)(weapon + kOffGunParameters);
            if (!valid_ptr(gun_params)) return;

            auto& slot = originals[gun_params];
            if (!slot.valid) {
                slot.recoilControl    = *(int*)(gun_params + kOffRecoilControl);
                slot.multOnCrouch     = *(float*)(gun_params + kOffMultOnCrouch);
                slot.aimMult          = *(float*)(gun_params + kOffAimMult);
                slot.aimMultCrouch    = *(float*)(gun_params + kOffAimMultCrouch);
                slot.valid = true;

                uintptr_t rp = *(uintptr_t*)(gun_params + kOffRecoilParams);
                if (valid_ptr(rp)) {
                    slot.horizontalRange = *(float*)(rp + kOffHorizontalRange);
                    slot.verticalRange   = *(float*)(rp + kOffVerticalRange);
                }
            }

            *(int*)(gun_params + kOffRecoilControl)  = 0;
            *(float*)(gun_params + kOffMultOnCrouch)  = 0.0f;
            *(float*)(gun_params + kOffAimMult)       = 0.0f;
            *(float*)(gun_params + kOffAimMultCrouch) = 0.0f;

            uintptr_t rp = *(uintptr_t*)(gun_params + kOffRecoilParams);
            if (valid_ptr(rp)) {
                *(float*)(rp + kOffHorizontalRange) = 0.0f;
                *(float*)(rp + kOffVerticalRange)   = 0.0f;
            }
        } else if (!originals.empty()) {
            // restore whatever we zeroed out
            for (const auto& kv : originals) {
                const uintptr_t gp = kv.first;
                const RecoilBackup& b = kv.second;
                if (!valid_ptr(gp) || !b.valid) continue;

                *(int*)(gp + kOffRecoilControl)   = b.recoilControl;
                *(float*)(gp + kOffMultOnCrouch)  = b.multOnCrouch;
                *(float*)(gp + kOffAimMult)       = b.aimMult;
                *(float*)(gp + kOffAimMultCrouch) = b.aimMultCrouch;

                uintptr_t rp = *(uintptr_t*)(gp + kOffRecoilParams);
                if (valid_ptr(rp)) {
                    *(float*)(rp + kOffHorizontalRange) = b.horizontalRange;
                    *(float*)(rp + kOffVerticalRange)   = b.verticalRange;
                }
            }
            originals.clear();
        }
    }

    // FireRate: GunParameters._fireRate (RPM) int +0xA4 multiplied,
    // plus the "safe" encrypted copy FAPAIEBIIJO (pointer at +0x138):
    //   +0x10 readonly original value, +0x14 current value used by getters.
    // Writing both ints keeps get_FireRate() consistent with the plain field.
    void ApplyFireRate() {
        struct FireRateBackup {
            int  fireRate = 0;
            int  safeCurrent = 0;
            bool valid = false;
        };
        static std::unordered_map<uintptr_t, FireRateBackup> originals;

        constexpr uintptr_t kOffFireRate      = 0xA4;   // GunParameters._fireRate (int, rpm)
        constexpr uintptr_t kOffSafeFireRate  = 0x138;  // GunParameters._safeFireRate
        constexpr uintptr_t kOffSafeCurrent   = 0x14;   // FAPAIEBIIJO current int

        if (settings.fireRateEnabled) {
            uintptr_t player = (uintptr_t)hooks::localPlayer;
            if (!valid_ptr(player)) return;
            if (!is_class_named((void*)player, "PlayerController")) return;

            uintptr_t weaponry = *(uintptr_t*)(player + kOffWeaponryController);
            if (!valid_ptr(weaponry)) return;

            uintptr_t weapon = *(uintptr_t*)(weaponry + kOffCurrentWeapon);
            if (!valid_ptr(weapon)) return;
            if (!is_gun_controller((void*)weapon)) return;

            uintptr_t params = *(uintptr_t*)(weapon + kOffGunParameters);
            if (!valid_ptr(params)) return;

            int orig = *(int*)(params + kOffFireRate);
            if (orig <= 0 || orig > 100000) return;

            auto& slot = originals[params];
            if (!slot.valid) {
                slot.fireRate = orig;
                uintptr_t safe = *(uintptr_t*)(params + kOffSafeFireRate);
                if (valid_ptr(safe)) {
                    slot.safeCurrent = *(int*)(safe + kOffSafeCurrent);
                }
                slot.valid = true;
            }

            float mult = settings.fireRateMult;
            if (mult < 1.0f) mult = 1.0f;
            if (mult > 50.0f) mult = 50.0f;

            int value = (int)((float)orig * mult);
            if (value < orig) value = orig;

            *(int*)(params + kOffFireRate) = value;

            uintptr_t safe = *(uintptr_t*)(params + kOffSafeFireRate);
            if (valid_ptr(safe)) {
                *(int*)(safe + kOffSafeCurrent) = value;
            }
        } else if (!originals.empty()) {
            for (const auto& kv : originals) {
                const uintptr_t params = kv.first;
                const FireRateBackup& b = kv.second;
                if (!valid_ptr(params) || !b.valid) continue;

                *(int*)(params + kOffFireRate) = b.fireRate;

                uintptr_t safe = *(uintptr_t*)(params + kOffSafeFireRate);
                if (valid_ptr(safe)) {
                    *(int*)(safe + kOffSafeCurrent) = b.safeCurrent;
                }
            }
            originals.clear();
        }
    }

    void Tick() {
        ApplyFov();
        ApplyFakeLag();
        ApplySpeed();
        ApplyInfinityAmmo();
        ApplyNoRecoil();
        ApplyBunnyHop();
        ApplyFireRate();
    }
}
