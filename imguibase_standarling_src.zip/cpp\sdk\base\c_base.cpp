//
// Created by Максим on 22.06.2025.
//

#include "c_base.hpp"


uintptr_t c_base::il2cpp_icall(const char* name)
{
    static auto ret = (uintptr_t(*)(const char*))(dlsym(RTLD_NEXT, "il2cpp_resolve_icall"));
    return ret(name);
}

c_base::c_base()
{
    for (int attempt = 0; attempt < 45 && !unity_base; attempt++) {
        c_framework* unity_framework = c_framework::find("UnityFramework");
        if (unity_framework) {
            unity_base = unity_framework->addr;
            delete unity_framework;
            break;
        }
        sleep(1);
    }
}